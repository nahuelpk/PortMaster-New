
dialogId("sp-v-no0", "font_big", "Lo and behold!")

dialogId("sp-m-no1", "font_small", "Just imagine!")

dialogId("sp-v-kdoby", "font_big", "Who could have guessed?!")

dialogId("sp-m-neopatrnost", "font_small", "Such carelessness.")

dialogId("sp-v-zahynuli", "font_big", "Thousands perished - the whole city disappeared in the waves because of such ineptness.")

dialogId("sp-m-vytazeny", "font_small", "Unplugged plug.")

dialogId("sp-v-trapne", "font_big", "An embarrassing blunder.")

dialogId("sp-m-costim", "font_small", "What are we to do with it?")

dialogId("sp-v-vratit0", "font_big", "We can try to put it back in place.")

dialogId("sp-m-vratit0", "font_small", "And then? Shall we drink the water that poured in, or what?")

dialogId("sp-v-vratit1", "font_big", "We can put it back in place as a token of our esteem of the citizens’ heroic effort to keep it afloat. As a memorial to their industrious, adroit and... persistent nature.")

dialogId("sp-m-vratit1", "font_small", "Of what? ‘Where are you running? I need to order eight swords.’ The Providence itself unplugged that hole. Just imagine you’d hear such things at home. Day by day.")

dialogId("sp-m-kalet", "font_small", "And moreover: is it likely that anybody would ever come here? Only sepias will nibble it occasionally.")

dialogId("sp-v-pocit", "font_big", "We are going to feel good about it.")

dialogId("sp-m-potize", "font_small", "We are going to feel down about it. Do you think the boss is going to believe it? A giant unplugged plug? And what have you done with it? We plugged it again. He, he, he.")

dialogId("sp-v-vzit", "font_big", "You might be right. Maybe it would be better to take it along.")

dialogId("sp-m-taky", "font_small", "I think so, too.")

dialogId("sp-v-dotoho", "font_big", "Let ’s get to work.")

dialogId("sp-m-nechat", "font_small", "What if we just leave that plug here?")

dialogId("sp-v-centrala", "font_big", "What would the Agency say?")

dialogId("sp-v-jedno", "font_big", "I don’t think I mind what the boss is going to think about me.")

dialogId("sp-m-vydrz", "font_small", "Hold on. We are sure to solve it.")

dialogId("sp-m-spunt", "font_small", "The darned plug. What if we just make up something.")

dialogId("sp-v-co", "font_big", "Like what, for example?")

dialogId("sp-m-vymluva0", "font_small", "Well, we could say that the city in fact never existed.")

dialogId("sp-m-vymluva1", "font_small", "Well, we could say that the city sank because the Arctic ice had melted.")

dialogId("sp-m-vymluva2", "font_small", "An earthquake could have sunk the city, for example.")

dialogId("sp-m-vymluva3", "font_small", "A tsunami might have sunk the city, for example.")

dialogId("sp-m-vymluva4", "font_small", "We could try to say that a volcano erupted in the center of the city.")

dialogId("sp-v-nesmysl", "font_big", "That is just nonsense.")

dialogId("sp-v-ven", "font_big", "This time our goal is to get that plug out.")
