
dialogId("sp-v-no0", "font_big", "Lo and behold!")
dialogStr("No tohle!")


dialogId("sp-m-no1", "font_small", "Just imagine!")
dialogStr("No teda!")


dialogId("sp-v-kdoby", "font_big", "Who could have guessed?!")
dialogStr("Kdo by to řekl?!")


dialogId("sp-m-neopatrnost", "font_small", "Such carelessness.")
dialogStr("Taková neopatrnost.")


dialogId("sp-v-zahynuli", "font_big", "Thousands perished - the whole city disappeared in the waves because of such ineptness.")
dialogStr("Tisíce lidí zahynuly, celé město zmizelo v rozbouřených vlnách kvůli takové hlouposti.")


dialogId("sp-m-vytazeny", "font_small", "Unplugged plug.")
dialogStr("Vytažený špunt.")


dialogId("sp-v-trapne", "font_big", "An embarrassing blunder.")
dialogStr("Trapné přehlédnutí.")


dialogId("sp-m-costim", "font_small", "What are we to do with it?")
dialogStr("Co s ním teď uděláme?")


dialogId("sp-v-vratit0", "font_big", "We can try to put it back in place.")
dialogStr("Můžem ho zkusit vrátit na místo.")


dialogId("sp-m-vratit0", "font_small", "And then? Shall we drink the water that poured in, or what?")
dialogStr("A co potom? Myslíš, že tu vodu, co sem natekla, vypijem?")


dialogId("sp-v-vratit1", "font_big", "We can put it back in place as a token of our esteem of the citizens’ heroic effort to keep it afloat. As a memorial to their industrious, adroit and... persistent nature.")
dialogStr("Můžem ho vrátit na místo jako vyjádření našeho obdivu k hrdinskému úsilí obyvatel města udržet ho nad hladinou. Jako pomník jejich důmyslu, zručnosti a ... vytrvalosti.")


dialogId("sp-m-vratit1", "font_small", "Of what? ‘Where are you running? I need to order eight swords.’ The Providence itself unplugged that hole. Just imagine you’d hear such things at home. Day by day.")
dialogStr("Čeho že? 'Kam běžíš? Pro sedm mečů!’ Ten špunt podle mě vytáhla sama prozřetelnost. Představ si, že bys takové věci slýchal doma. Den co den.")


dialogId("sp-m-kalet", "font_small", "And moreover: is it likely that anybody would ever come here? Only sepias will nibble it occasionally.")
dialogStr("A navíc: copak sem ještě někdo někdy přijde? Tady budou na ten špunt akorát kálet sépie.")


dialogId("sp-v-pocit", "font_big", "We are going to feel good about it.")
dialogStr("Budem z toho mít dobrý pocit.")


dialogId("sp-m-potize", "font_small", "We are going to feel down about it. Do you think the boss is going to believe it? A giant unplugged plug? And what have you done with it? We plugged it again. He, he, he.")
dialogStr("Budem z toho mít potíže. Myslíš, že nám to šéf uvěří? Obří vytažený špunt. A co jste s ním udělali? Ucpali jsme s ním díru. Ha, ha, ha.")


dialogId("sp-v-vzit", "font_big", "You might be right. Maybe it would be better to take it along.")
dialogStr("Na tom něco je. Možná by bylo lepší ho vzít s sebou.")


dialogId("sp-m-taky", "font_small", "I think so, too.")
dialogStr("To si taky myslím.")


dialogId("sp-v-dotoho", "font_big", "Let ’s get to work.")
dialogStr("Dáme se do toho.")


dialogId("sp-m-nechat", "font_small", "What if we just leave that plug here?")
dialogStr("Co kdybychom tady ten špunt prostě nechali?")


dialogId("sp-v-centrala", "font_big", "What would the Agency say?")
dialogStr("Co by tomu řekla centrála?")


dialogId("sp-v-jedno", "font_big", "I don’t think I mind what the boss is going to think about me.")
dialogStr("Už mi začíná být jedno, co si o mně šéf pomyslí.")


dialogId("sp-m-vydrz", "font_small", "Hold on. We are sure to solve it.")
dialogStr("Vydrž. Určitě na to přijdem.")


dialogId("sp-m-spunt", "font_small", "The darned plug. What if we just make up something.")
dialogStr("Zatracený špunt. Co kdybychom si něco vymysleli?")


dialogId("sp-v-co", "font_big", "Like what, for example?")
dialogStr("Jako třeba co?")


dialogId("sp-m-vymluva0", "font_small", "Well, we could say that the city in fact never existed.")
dialogStr("No třeba, že to město nikdy neexistovalo.")


dialogId("sp-m-vymluva1", "font_small", "Well, we could say that the city sank because the Arctic ice had melted.")
dialogStr("Třeba, že se to město potopilo, protože roztály ledovce.")


dialogId("sp-m-vymluva2", "font_small", "An earthquake could have sunk the city, for example.")
dialogStr("Například ho mohlo potopit zemětřesení.")


dialogId("sp-m-vymluva3", "font_small", "A tsunami might have sunk the city, for example.")
dialogStr("Třeba, že ho smetla tsunami.")


dialogId("sp-m-vymluva4", "font_small", "We could try to say that a volcano erupted in the center of the city.")
dialogStr("Můžem říkat, že na ostrově vybuchla sopka.")


dialogId("sp-v-nesmysl", "font_big", "That is just nonsense.")
dialogStr("To je pěkný nesmysl.")


dialogId("sp-v-ven", "font_big", "This time our goal is to get that plug out.")
dialogStr("Naším úkolem tentokrát bude dostat ven z místnosti ten špunt!")

