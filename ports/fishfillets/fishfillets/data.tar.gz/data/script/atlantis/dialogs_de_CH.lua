
dialogId("sp-m-kalet", "font_small", "And moreover: is it likely that anybody would ever come here? Only sepias will nibble it occasionally.")
dialogStr("Und ausserdem: Wird hier je irgendwer herkommen? Nur Tintenfische werden ihn ab und zu anknabbern.")

