-- FIXME. spell
dialogId("dlg-x-poster1", "font_poster", "We succeeded in discovering the right cause of sinking the city. It was a well known artifact called atlantic relief, up to now considered by mistake to be a depiction of extraterrestrial visit, that gave us a hint. At the same time, we recommend increasing the surveillance of the plugs on all continents and bigger islands in order not to repeat similar awkward catastrophe again.")
dialogStr("Мы успешно раскрыли причину подводного города. Мы имеем очень ценную информацию о атлантических рельефах, теперь мы считаем ошибкой идею о внеземном визите инопланетян, у нас теперь появилась идея. Некоторое время, мы рекомендуем увеличить наблюдение за заглушками на всех материках и больших островах, что бы больше не допустить катастроф.")

