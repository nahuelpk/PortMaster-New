dialogId("m-zvlastni", "font_small", "This is a very strange room.")
dialogStr("Das ist ein sehr seltsamer Raum.")

dialogId("v-zadne", "font_big", "There are no squares of walls here.")
dialogStr("Hier gibt es gar keine Wände.")

dialogId("m-zeme", "font_small", "Or rather squares of the Earth.")
dialogStr("Und kein Stück Erde.")

dialogId("m-uvedomit", "font_small",
"You need to realize that the steel cylinder surrounding us")
dialogStr("Du musst verstehen, dass der Stahlzylinder um uns herum")

dialogId("v-nad", "font_big", "... rather above me ...")
dialogStr("... um genau zu sein - über mir ...")

dialogId("m-predmet", "font_small", "is only an object.")
dialogStr("nur ein Objekt ist.")

dialogId("v-krehci", "font_big",
"Therefore I am more tender then usualy.")
dialogStr("Deswegen bin ich vorsichtiger als sonst.")

dialogId("m-otazka0", "font_small", "Am I in UFO?")
dialogStr("Bin ich in einem UFO?")

dialogId("m-otazka1", "font_small", "So why is starlit sky on the background?")
dialogStr("Warum ist Sternenhimmel im Hintergrund?")

dialogId("m-otazka2", "font_small", "And why are the stars moving?")
dialogStr("Und warum bewegen sich die Sterne?")

dialogId("m-otazka3", "font_small", "It is rotating very quick.")
dialogStr("Es dreht sich sehr schnell.")

dialogId("m-otazka4", "font_small", "I thought we are in the space.")
dialogStr("Ich dachte, wir sind im Weltall.")

dialogId("v-odpoved0", "font_big", "You can’t be there, it is just another elevator.")
dialogStr("Das kann nicht sein, das ist nur ein weiterer Fahrstuhl.")

dialogId("v-odpoved1", "font_big", "Because it’s night now.")
dialogStr("Weil jetzt Nacht ist.")

dialogId("v-odpoved2", "font_big",
"Because the globe is rotating around its axis.")
dialogStr("Weil die Erde sich um ihre Achse dreht.")

dialogId("v-odpoved3", "font_big",
"It does not matter to us. We are in the water.")
dialogStr("Das kann uns egal sein. Wir sind im Wasser.")
