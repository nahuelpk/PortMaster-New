dialogId("m-zvlastni", "font_small", "This is a very strange room.")
dialogStr("To je ale zvláštní místnost.")

dialogId("v-zadne", "font_big", "There are no squares of walls here.")
dialogStr("Není v ní žádné políčko zdi.")

dialogId("m-zeme", "font_small", "Or rather squares of the Earth.")
dialogStr("Nebo spíš Země.")

dialogId("m-uvedomit", "font_small",
"You need to realize that the steel cylinder surrounding us")
dialogStr("Je dobré si uvědomit, že ta trubka kolem.")

dialogId("v-nad", "font_big", "... rather above me ...")
dialogStr("... nebo spíš nad ...")

dialogId("m-predmet", "font_small", "is only an object.")
dialogStr("je jen předmět.")

dialogId("v-krehci", "font_big",
"Therefore I am more tender then usualy.")
dialogStr("A já jsem tak křehčí než obvykle.")

dialogId("m-otazka0", "font_small", "Am I in UFO?")
dialogStr("To už letím v UFU?")
dialogId("m-otazka1", "font_small", "So why is starlit sky on the background?")
dialogStr("Tak proč je kolem ta hvězdná obloha?")
dialogId("m-otazka2", "font_small", "And why are the stars moving?")
dialogStr("A proč se ty hvězdy hýbou?.")
dialogId("m-otazka3", "font_small", "It is rotating very quick.")
dialogStr("Netočí se to nějak moc rychle?")
dialogId("m-otazka4", "font_small", "I thought we are in the space.")
dialogStr("Já myslela, že jsme ve vesmíru.")

dialogId("v-odpoved0", "font_big", "You can’t be there, it is just another elevator.")
dialogStr("Jak by ses tam dostala, to je jenom další výtah.")
dialogId("v-odpoved1", "font_big", "Because it’s night now.")
dialogStr("Protože je noc.")
dialogId("v-odpoved2", "font_big",
"Because the globe is rotating around its axis.")
dialogStr("Protože se Země otáčí kolem své osy.")
dialogId("v-odpoved3", "font_big",
"It does not matter to us. We are in the water.")
dialogStr("To nám nemusí vadit. My jsme pod vodou.")
