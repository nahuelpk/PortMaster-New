dialogId("m-zvlastni", "font_small", "This is a very strange room.")
dialogStr("Dit is een raar veld.")

dialogId("v-zadne", "font_big", "There are no squares of walls here.")
dialogStr("Er zijn hier helemaal geen stukjes muur.")

dialogId("m-zeme", "font_small", "Or rather squares of the Earth.")
dialogStr("Of liever, geen stukjes Aarde.")

dialogId("m-uvedomit", "font_small", "You need to realize that the steel cylinder surrounding us")
dialogStr("Je moet je realiseren dat de stalen cylinder om ons heen")

dialogId("v-nad", "font_big", "... rather above me ...")
dialogStr("... of liever ... boven mij ...")

dialogId("m-predmet", "font_small", "is only an object.")
dialogStr("alleen maar een ding is.")

dialogId("v-krehci", "font_big", "Therefore I am more tender then usualy.")
dialogStr("Daarom ben ik nu wat kwetsbaarder dan normaal.")

dialogId("m-otazka0", "font_small", "Am I in UFO?")
dialogStr("Ben ik in een vliegende schotel?")

dialogId("m-otazka1", "font_small", "So why is starlit sky on the background?")
dialogStr("Waarom is de achtergrond een sterrenhemel?")

dialogId("m-otazka2", "font_small", "And why are the stars moving?")
dialogStr("En waarom bewegen de sterren?")

dialogId("m-otazka3", "font_small", "It is rotating very quick.")
dialogStr("Hij roteert heel snel.")

dialogId("m-otazka4", "font_small", "I thought we are in the space.")
dialogStr("Ik dacht dat we in de ruimte waren.")

dialogId("v-odpoved0", "font_big", "You can’t be there, it is just another elevator.")
dialogStr("Dat kan niet, het is gewoon een lift.")

dialogId("v-odpoved1", "font_big", "Because it’s night now.")
dialogStr("Omdat het nu nacht is.")

dialogId("v-odpoved2", "font_big", "Because the globe is rotating around its axis.")
dialogStr("Omdat de wereldbol om zijn as draait.")

dialogId("v-odpoved3", "font_big", "It does not matter to us. We are in the water.")
dialogStr("Het maakt voor ons toch niet uit. Wij zijn onderwater.")
