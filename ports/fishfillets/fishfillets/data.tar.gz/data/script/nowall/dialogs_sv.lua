dialogId("m-zvlastni", "font_small", "This is a very strange room.")
dialogStr("Det här är ett mycket konstigt rum.")

dialogId("v-zadne", "font_big", "There are no squares of walls here.")
dialogStr("Det finns inga väggbitar alls.")

dialogId("m-zeme", "font_small", "Or rather squares of the Earth.")
dialogStr("Eller snarare jordbitar.")

dialogId("m-uvedomit", "font_small",
"You need to realize that the steel cylinder surrounding us")
dialogStr("Du måste förstå att stålcylindrar som omger oss")

dialogId("v-nad", "font_big", "... rather above me ...")
dialogStr("... precis över mig ...")

dialogId("m-predmet", "font_small", "is only an object.")
dialogStr("är ett enda objekt.")

dialogId("v-krehci", "font_big",
"Therefore I am more tender then usualy.")
dialogStr("Därför är jag försiktigare än vanligt.")

dialogId("m-otazka0", "font_small", "Am I in UFO?")
dialogStr("Är jag i rymden?")
dialogId("m-otazka1", "font_small", "So why is starlit sky on the background?")
dialogStr("Så varför är det en stjärnhimmel som bakgrund?")
dialogId("m-otazka2", "font_small", "And why are the stars moving?")
dialogStr("Och varför rör stjärnorna på sig?.")
dialogId("m-otazka3", "font_small", "It is rotating very quick.")
dialogStr("Den snurrar mycket snabbt.")
dialogId("m-otazka4", "font_small", "I thought we are in the space.")
dialogStr("Jag tror att vi är i rymden.")

dialogId("v-odpoved0", "font_big", "You can’t be there, it is just another elevator.")
dialogStr("Du kan inte vara där, det är bara en till hiss.")
dialogId("v-odpoved1", "font_big", "Because it’s night now.")
dialogStr("För att det är natt nu.")
dialogId("v-odpoved2", "font_big",
"Because the globe is rotating around its axis.")
dialogStr("För att jorden snurrar runt sin axel.")
dialogId("v-odpoved3", "font_big",
"It does not matter to us. We are in the water.")
dialogStr("Det påverkar inte oss. Vi är under vattenytan.")
