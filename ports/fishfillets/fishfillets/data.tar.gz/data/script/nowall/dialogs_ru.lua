-- FIXME adascor
dialogId("m-zvlastni", "font_small", "This is a very strange room.")
dialogStr("Это очень странная комната.")

dialogId("v-zadne", "font_big", "There are no squares of walls here.")
dialogStr("Здесь стены без границ.")     --??

dialogId("m-zeme", "font_small", "Or rather squares of the Earth.")
dialogStr("Или, скорее, нет горизонта.") --??

dialogId("m-uvedomit", "font_small",
"You need to realize that the steel cylinder surrounding us")
dialogStr("Тебе надо понять, что стальной цилиндр, окружающий нас,")

dialogId("v-nad", "font_big", "... rather above me ...")
dialogStr("... скорее выше меня ...")

dialogId("m-predmet", "font_small", "is only an object.")
dialogStr("является только предметом.")

dialogId("v-krehci", "font_big",
"Therefore I am more tender then usualy.")
dialogStr("Поэтому я особо осторожен, чем обычно.")

dialogId("m-otazka0", "font_small", "Am I in UFO?")
dialogStr("Я нахожусь в НЛО?")

dialogId("m-otazka1", "font_small", "So why is starlit sky on the background?")
dialogStr("Так вот почему звездное небо вокруг?")

dialogId("m-otazka2", "font_small", "And why are the stars moving?")
dialogStr("И почему звезды движутся?")

dialogId("m-otazka3", "font_small", "It is rotating very quick.")
dialogStr("Они вращаются очень быстро.")

dialogId("m-otazka4", "font_small", "I thought we are in the space.")
dialogStr("Я думаю, мы в космосе.")

dialogId("v-odpoved0", "font_big", "You can’t be there, it is just another elevator.")
dialogStr("Ты не можешь быть здесь, это только другой лифт.")

dialogId("v-odpoved1", "font_big", "Because it’s night now.")
dialogStr("Потому что сейчас ночь.")

dialogId("v-odpoved2", "font_big",
"Because the globe is rotating around its axis.")
dialogStr("Потому что земной шар вертится вокруг своей оси.")

dialogId("v-odpoved3", "font_big",
"It does not matter to us. We are in the water.")
dialogStr("Это не имеет для нас значения. Мы находимся в воде.")
