dialogId("m-zvlastni", "font_small", "This is a very strange room.")
dialogStr("Тази стая е много странна.")

dialogId("v-zadne", "font_big", "There are no squares of walls here.")
dialogStr("Няма стени.")

dialogId("m-zeme", "font_small", "Or rather squares of the Earth.")
dialogStr("Или пък изрезки от Земята.")

dialogId("m-uvedomit", "font_small",
"You need to realize that the steel cylinder surrounding us")
dialogStr("Разбери, че стоманеният цилиндър, който е около нас")

dialogId("v-nad", "font_big", "... rather above me ...")
dialogStr("... по-скоро над мен ...")

dialogId("m-predmet", "font_small", "is only an object.")
dialogStr("е просто обект.")

dialogId("v-krehci", "font_big",
"Therefore I am more tender then usualy.")
dialogStr("Точно затова съм по-внимателен от обикновено.")

dialogId("m-otazka0", "font_small", "Am I in UFO?")
dialogStr("В НЛО ли съм?")
dialogId("m-otazka1", "font_small", "So why is starlit sky on the background?")
dialogStr("Защо фонът е звездно небе?")
dialogId("m-otazka2", "font_small", "And why are the stars moving?")
dialogStr("А защо звездите се местят?")
dialogId("m-otazka3", "font_small", "It is rotating very quick.")
dialogStr("Доста бързо се върти.")
dialogId("m-otazka4", "font_small", "I thought we are in the space.")
dialogStr("Мислех, че сме в космоса.")

dialogId("v-odpoved0", "font_big", "You can’t be there, it is just another elevator.")
dialogStr("Не, това е просто още един асансьор.")
dialogId("v-odpoved1", "font_big", "Because it’s night now.")
dialogStr("Защото е нощ.")
dialogId("v-odpoved2", "font_big",
"Because the globe is rotating around its axis.")
dialogStr("Защото земята се върти около оста си.")
dialogId("v-odpoved3", "font_big",
"It does not matter to us. We are in the water.")
dialogStr("За нас няма значение. Във водата сме.")
