dialogId("m-zvlastni", "font_small", "This is a very strange room.")

dialogId("v-zadne", "font_big", "There are no squares of walls here.")

dialogId("m-zeme", "font_small", "Or rather squares of the Earth.")

dialogId("m-uvedomit", "font_small",
"You need to realize that the steel cylinder surrounding us")

dialogId("v-nad", "font_big", "... rather above me ...")

dialogId("m-predmet", "font_small", "is only an object.")

dialogId("v-krehci", "font_big",
"Therefore I am more tender then usualy.")

dialogId("m-otazka0", "font_small", "Am I in UFO?")
dialogId("m-otazka1", "font_small", "So why is starlit sky on the background?")
dialogId("m-otazka2", "font_small", "And why are the stars moving?")
dialogId("m-otazka3", "font_small", "It is rotating very quick.")
dialogId("m-otazka4", "font_small", "I thought we are in the space.")

dialogId("v-odpoved0", "font_big", "You can’t be there, it is just another elevator.")
dialogId("v-odpoved1", "font_big", "Because it’s night now.")
dialogId("v-odpoved2", "font_big",
"Because the globe is rotating around its axis.")
dialogId("v-odpoved3", "font_big",
"It does not matter to us. We are in the water.")
