dialogId("tr-m-chlad1", "font_small", "I’m kind of cold.")
dialogStr("Нещо ми е хладно.")

dialogId("tr-v-jid1", "font_big", "No wonder. This is the Winter Mess Hall.")
dialogStr("Не се учудвам. Това е Зимна бъркотия.")

dialogId("tr-m-chlad2", "font_small", "I’m cold.")
dialogStr("Студено ми е.")

dialogId("tr-v-jid2", "font_big", "Well that’s what you would expect in a Winter Mess Hall, right?")
dialogStr("Ами това се очаква когато се намираш в Зимната Зала, нали?")

dialogId("tr-v-prezil", "font_big", "At least the snowman has survived.")
dialogStr("Поне снежният човек оцеля.")

dialogId("tr-m-cvicit", "font_small", "Maybe you should start thinking about how to manipulate the tables.")
dialogStr("Може би трябва да започнеш да мислиш как да използваш масите.")

dialogId("tr-m-ztuhl", "font_small", "Everything is so frozen here...")
dialogStr("Тук всичко е толкова замръзнало...")

dialogId("tr-m-au1", "font_small", "Ow!")
dialogStr("Ох!")

dialogId("tr-m-au2", "font_small", "Ouch!")
dialogStr("Боли!")

dialogId("tr-v-agres", "font_big", "I’ve never seen such an aggressive snowman.")
dialogStr("Никога не съм виждал толкова агресивен снежен човек.")

dialogId("tr-x-koste", "", "")
dialogStr("")

