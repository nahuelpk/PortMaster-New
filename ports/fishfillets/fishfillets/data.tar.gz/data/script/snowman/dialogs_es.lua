
dialogId("tr-m-chlad1", "font_small", "I’m kind of cold.")
dialogStr("Tengo un poco de frío.")


dialogId("tr-v-jid1", "font_big", "No wonder. This is the Winter Mess Hall.")
dialogStr("No te preocupes. Este es el Salón del Invierno.")


dialogId("tr-m-chlad2", "font_small", "I’m cold.")
dialogStr("Tengo frío.")


dialogId("tr-v-jid2", "font_big", "Well that’s what you would expect in a Winter Mess Hall, right?")
dialogStr("Bueno, eso esperarías de un Salón del Invierno, ¿Cierto?")


dialogId("tr-v-prezil", "font_big", "At least the snowman has survived.")
dialogStr("Al menos el mono de nieve sobrevivió.")


dialogId("tr-m-cvicit", "font_small", "Maybe you should start thinking about how to manipulate the tables.")
dialogStr("Quizás deberías comenzar pensando en como mover las tablas.")


dialogId("tr-m-ztuhl", "font_small", "Everything is so frozen here...")
dialogStr("Todo está tan congelado aquí...")


dialogId("tr-m-au1", "font_small", "Ow!")
dialogStr("¡Oh!")


dialogId("tr-m-au2", "font_small", "Ouch!")
dialogStr("¡Auch!")


dialogId("tr-v-agres", "font_big", "I’ve never seen such an aggressive snowman.")
dialogStr("Nunca he visto a un mono de nieve tan agresivo.")

