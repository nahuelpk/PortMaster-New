
dialogId("tr-m-chlad1", "font_small", "I’m kind of cold.")
dialogStr("Je mi nějak chladno.")


dialogId("tr-v-jid1", "font_big", "No wonder. This is the Winter Mess Hall.")
dialogStr("Není divu, vždyť tohle je Zimní jídelna.")


dialogId("tr-m-chlad2", "font_small", "I’m cold.")
dialogStr("Je mi zima.")


dialogId("tr-v-jid2", "font_big", "Well that’s what you would expect in a Winter Mess Hall, right?")
dialogStr("To je snad v Zimní jídelně normální, ne?")


dialogId("tr-v-prezil", "font_big", "At least the snowman has survived.")
dialogStr("Aspoň že to přežil ten sněhulák.")


dialogId("tr-m-cvicit", "font_small", "Maybe you should start thinking about how to manipulate the tables.")
dialogStr("Měl by sis cvičit manipulaci se stoly.")


dialogId("tr-m-ztuhl", "font_small", "Everything is so frozen here...")
dialogStr("Všechno je tu tak ztuhlé...")


dialogId("tr-m-au1", "font_small", "Ow!")
dialogStr("Au!")


dialogId("tr-m-au2", "font_small", "Ouch!")
dialogStr("Auvajs.")


dialogId("tr-v-agres", "font_big", "I’ve never seen such an aggressive snowman.")
dialogStr("Tak agresívního sněhuláka jsem ještě neviděl.")

