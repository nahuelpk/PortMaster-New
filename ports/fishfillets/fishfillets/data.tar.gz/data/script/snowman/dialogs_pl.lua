
dialogId("tr-m-chlad1", "font_small", "I’m kind of cold.")
dialogStr("Jakoś mi zimno.")


dialogId("tr-v-jid1", "font_big", "No wonder. This is the Winter Mess Hall.")
dialogStr("Nic dziwnego, w końcu to zimowa mesa.")


dialogId("tr-m-chlad2", "font_small", "I’m cold.")
dialogStr("Zimno mi.")


dialogId("tr-v-jid2", "font_big", "Well that’s what you would expect in a Winter Mess Hall, right?")
dialogStr("A czego się spodziewałaś po zimowej jadalni?")


dialogId("tr-v-prezil", "font_big", "At least the snowman has survived.")
dialogStr("Przynajmniej bałwan przetrwał.")


dialogId("tr-m-cvicit", "font_small", "Maybe you should start thinking about how to manipulate the tables.")
dialogStr("Może byś zaczął myśleć, co zrobić ze stołami?")


dialogId("tr-m-ztuhl", "font_small", "Everything is so frozen here...")
dialogStr("Wszystko to takie... zamarznięte.")


dialogId("tr-m-au1", "font_small", "Ow!")
dialogStr("Au!")


dialogId("tr-m-au2", "font_small", "Ouch!")
dialogStr("Ała!")


dialogId("tr-v-agres", "font_big", "I’ve never seen such an aggressive snowman.")
dialogStr("Nigdy nie widziałem takiego agresywnego bałwana.")

