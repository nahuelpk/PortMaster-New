
dialogId("tr-m-chlad1", "font_small", "I’m kind of cold.")

dialogId("tr-v-jid1", "font_big", "No wonder. This is the Winter Mess Hall.")

dialogId("tr-m-chlad2", "font_small", "I’m cold.")

dialogId("tr-v-jid2", "font_big", "Well that’s what you would expect in a Winter Mess Hall, right?")

dialogId("tr-v-prezil", "font_big", "At least the snowman has survived.")

dialogId("tr-m-cvicit", "font_small", "Maybe you should start thinking about how to manipulate the tables.")

dialogId("tr-m-ztuhl", "font_small", "Everything is so frozen here...")

dialogId("tr-m-au1", "font_small", "Ow!")

dialogId("tr-m-au2", "font_small", "Ouch!")

dialogId("tr-v-agres", "font_big", "I’ve never seen such an aggressive snowman.")

dialogId("tr-x-koste", "", "")
