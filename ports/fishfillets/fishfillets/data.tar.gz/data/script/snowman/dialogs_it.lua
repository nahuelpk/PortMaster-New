
dialogId("tr-m-chlad1", "font_small", "I’m kind of cold.")
dialogStr("Fa un po' fresco.")


dialogId("tr-v-jid1", "font_big", "No wonder. This is the Winter Mess Hall.")
dialogStr("Strano. Questa è la mensa invernale...")


dialogId("tr-m-chlad2", "font_small", "I’m cold.")
dialogStr("Ho freddo.")


dialogId("tr-v-jid2", "font_big", "Well that’s what you would expect in a Winter Mess Hall, right?")
dialogStr("Beh, è proprio quello che ci si aspetta in una mensa invernale, no?")


dialogId("tr-v-prezil", "font_big", "At least the snowman has survived.")
dialogStr("Alemano l'uomo di neve è sopravvissuto.")


dialogId("tr-m-cvicit", "font_small", "Maybe you should start thinking about how to manipulate the tables.")
dialogStr("Forse dovresti pensare un po' a come usare quei tavoli.")


dialogId("tr-m-ztuhl", "font_small", "Everything is so frozen here...")
dialogStr("E’ tutto congelato qui...")


dialogId("tr-m-au1", "font_small", "Ow!")
dialogStr("Aio!")


dialogId("tr-m-au2", "font_small", "Ouch!")
dialogStr("Ohi!")


dialogId("tr-v-agres", "font_big", "I’ve never seen such an aggressive snowman.")
dialogStr("Non ho mai visto un pupazzo di neve così aggressivo.")

