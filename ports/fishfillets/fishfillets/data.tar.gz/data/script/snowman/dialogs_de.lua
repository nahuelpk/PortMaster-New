
dialogId("tr-m-chlad1", "font_small", "I’m kind of cold.")
dialogStr("Mir ist etwas kalt.")


dialogId("tr-v-jid1", "font_big", "No wonder. This is the Winter Mess Hall.")
dialogStr("Kein Wunder. Das ist die Wintermesse.")


dialogId("tr-m-chlad2", "font_small", "I’m cold.")
dialogStr("Mir ist kalt.")


dialogId("tr-v-jid2", "font_big", "Well that’s what you would expect in a Winter Mess Hall, right?")
dialogStr("Das erwartet man doch in einer Wintermesse, oder?")


dialogId("tr-v-prezil", "font_big", "At least the snowman has survived.")
dialogStr("Wenigstens hat der Schneemann überlebt.")


dialogId("tr-m-cvicit", "font_small", "Maybe you should start thinking about how to manipulate the tables.")
dialogStr("Vielleicht solltest du darüber nachdenken, wie man mit Tischen umgeht.")


dialogId("tr-m-ztuhl", "font_small", "Everything is so frozen here...")
dialogStr("Hier ist alles so gefroren...")


dialogId("tr-m-au1", "font_small", "Ow!")
dialogStr("Au!")


dialogId("tr-m-au2", "font_small", "Ouch!")
dialogStr("Aua!")


dialogId("tr-v-agres", "font_big", "I’ve never seen such an aggressive snowman.")
dialogStr("Ich habe noch nie einen so aggressiven Schneemann gesehen.")

