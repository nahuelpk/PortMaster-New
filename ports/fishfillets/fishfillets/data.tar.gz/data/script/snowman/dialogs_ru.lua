-- FIXME. spell
dialogId("tr-m-chlad1", "font_small", "I’m kind of cold.")
dialogStr("Мне так холодно.")

dialogId("tr-v-jid1", "font_big", "No wonder. This is the Winter Mess Hall.")
dialogStr("Неудивительно. Это Большой Зимний Зал.")

dialogId("tr-m-chlad2", "font_small", "I’m cold.")
dialogStr("Мне холодно.")

dialogId("tr-v-jid2", "font_big", "Well that’s what you would expect in a Winter Mess Hall, right?")
dialogStr("А что ты должна ощущать в Большом Зимним Зале?")

dialogId("tr-v-prezil", "font_big", "At least the snowman has survived.")
dialogStr("И только маленький снеговик её бережет.")

dialogId("tr-m-cvicit", "font_small", "Maybe you should start thinking about how to manipulate the tables.")
dialogStr("Может быть ты начнешь думать, как использовать эти столы?")

dialogId("tr-m-ztuhl", "font_small", "Everything is so frozen here...")
dialogStr("Все тут замороженное...")

dialogId("tr-m-au1", "font_small", "Ow!")
dialogStr("Уф!")

dialogId("tr-m-au2", "font_small", "Ouch!")
dialogStr("Ох!")

dialogId("tr-v-agres", "font_big", "I’ve never seen such an aggressive snowman.")
dialogStr("Я никогда не видел столь агрессивно настроеннового снеговика.")

dialogId("tr-x-koste", "", "")
dialogStr("")

