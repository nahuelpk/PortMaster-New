
dialogId("tr-m-chlad1", "font_small", "I’m kind of cold.")
dialogStr("Ik heb het een beetje koud.")


dialogId("tr-v-jid1", "font_big", "No wonder. This is the Winter Mess Hall.")
dialogStr("Geen wonder, dit is de winterkajuit.")


dialogId("tr-m-chlad2", "font_small", "I’m cold.")
dialogStr("Ik heb het koud.")


dialogId("tr-v-jid2", "font_big", "Well that’s what you would expect in a Winter Mess Hall, right?")
dialogStr("Dat verwacht je toch ook van de winterkajuit, toch?")


dialogId("tr-v-prezil", "font_big", "At least the snowman has survived.")
dialogStr("In ieder geval is de sneeuwpop nog heel.")


dialogId("tr-m-cvicit", "font_small", "Maybe you should start thinking about how to manipulate the tables.")
dialogStr("Misschien moet je eens nadenken over hoe je die tafels moet verplaatsen.")


dialogId("tr-m-ztuhl", "font_small", "Everything is so frozen here...")
dialogStr("Alles ziet er hier zo bevroren uit...")


dialogId("tr-m-au1", "font_small", "Ow!")
dialogStr("Ai!")


dialogId("tr-m-au2", "font_small", "Ouch!")
dialogStr("Auw!")


dialogId("tr-v-agres", "font_big", "I’ve never seen such an aggressive snowman.")
dialogStr("Ik heb nog nooit zo'n gemene sneeuwpop gezien.")

