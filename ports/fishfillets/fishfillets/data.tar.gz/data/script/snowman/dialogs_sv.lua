
dialogId("tr-m-chlad1", "font_small", "I’m kind of cold.")
dialogStr("Här är det kallt.")


dialogId("tr-v-jid1", "font_big", "No wonder. This is the Winter Mess Hall.")
dialogStr("Inte konstigt. Det är vintermässen.")


dialogId("tr-m-chlad2", "font_small", "I’m cold.")
dialogStr("Jag fryser.")


dialogId("tr-v-jid2", "font_big", "Well that’s what you would expect in a Winter Mess Hall, right?")
dialogStr("Det är vad du kan förvänta dig i vintermässen, eller hur?")


dialogId("tr-v-prezil", "font_big", "At least the snowman has survived.")
dialogStr("Snögubben har i alla fall överlevt.")


dialogId("tr-m-cvicit", "font_small", "Maybe you should start thinking about how to manipulate the tables.")
dialogStr("Du kanske skulle fundera på hur du ska flytta på borden.")


dialogId("tr-m-ztuhl", "font_small", "Everything is so frozen here...")
dialogStr("Allt är fruset här...")


dialogId("tr-m-au1", "font_small", "Ow!")
dialogStr("Aj!")


dialogId("tr-m-au2", "font_small", "Ouch!")
dialogStr("Oj!")


dialogId("tr-v-agres", "font_big", "I’ve never seen such an aggressive snowman.")
dialogStr("Jag har aldrig sett en så aggressiv snögubbe.")

