dialogId("map-v-mapa", "font_big", "Oh well. So that map really exists after all!")
dialogStr("Ох хорошо. Значит карта все-таки существует на самом деле.")

dialogId("map-m-mapa", "font_small", "Okay. Here is the map.")
dialogStr("Отлично. Вот и карта.")

dialogId("map-m-ukol", "font_small", "So it’s clear now that our goal is to get that map out somehow.")
dialogStr("Теперь ясно, что наша цель состоит в том, чтобы выйти по карте как-нибудь.")

dialogId("map-v-jasne", "font_big", "Of course. It would be too easy, if we should just swim away.")
dialogStr("Конечно. Это должно быть легко, если мы только выплывем отсюда.")

dialogId("map-m-neplacej", "font_small", "Don’t talk nonsense and try to think instead.")
dialogStr("Не говори глупости и попыйся вместо этого подумать.")

dialogId("map-v-ukol", "font_big", "Our goal is to get out that map somehow.")
dialogStr("Наша цель - выбраться отсюда по карте.")

dialogId("map-v-cojetam", "font_big", "What can be on that map?")
dialogStr("Что может быть не этой карте?")

dialogId("map-v-poklady", "font_big", "Do you think that it really shows Silver’s treasure?")
dialogStr("Ты думаешь, что карта действительно показывает сокровища Силвера?")

dialogId("map-m-uvidime", "font_small", "We shall see when we manage to get the darned map out.")
dialogStr("Мы увидим, когда выйдем по этой проклятой карте.")

dialogId("map-m-sneci", "font_small", "We’d need more of these snails.")
dialogStr("Нам надо больше таких улиток.")

dialogId("map-x-hlemyzdi", "font_yellow", "You mean Escargots, don’t you?")
dialogStr("Ты имеешь ввиду Эскарготов, не так ли?")

dialogId("map-v-oci", "font_big", "We’d need more glass eyes.")
dialogStr("Нам надо больше стеклянных глаз.")

dialogId("map-v-restart", "font_big", "The easiest way to do it would be to get to the upper part of this level. Let’s try to restart it, maybe we will appear there.")
dialogStr("Самый легкий способ сделать это - это добраться до верхней части этого уровня. Давай попробуем перезагрузиться, может быть мы появимся там.")

dialogId("map-m-pravidla", "font_small", "Don’t pretend that you didn’t understand the rules after so many solved levels.")
dialogStr("Не притворяйся, что ты не знаешь правил после того, как было пройдено много уровней.")

dialogId("map-m-pohnout", "font_small", "So we managed to move it.")
dialogStr("Мы можем двигать это.")

dialogId("map-v-dal", "font_big", "Let’s keep up the good work.")
dialogStr("Давай, уже почти все сделано.")

