
dialogId("map-v-mapa", "font_big", "Oh well. So that map really exists after all!")
dialogStr("Also gibt es diese Karte wirklich!")


dialogId("map-m-mapa", "font_small", "Okay. Here is the map.")
dialogStr("Gut. Die Karte ist hier.")


dialogId("map-m-ukol", "font_small", "So it’s clear now that our goal is to get that map out somehow.")
dialogStr("Unser Ziel ist mit Sicherheit, diese Karte hier herauszubekommen..")


dialogId("map-v-jasne", "font_big", "Of course. It would be too easy, if we should just swim away.")
dialogStr("Klar. Es wäre ja auch zu einfach, wenn wir nur rausschwimmen müssten.")


dialogId("map-m-neplacej", "font_small", "Don’t talk nonsense and try to think instead.")
dialogStr("Rede keinen Unsinn und versuche nachzudenken!")


dialogId("map-v-ukol", "font_big", "Our goal is to get out that map somehow.")
dialogStr("Unser Ziel ist, diese Karte irgendwie rauszubekommen.")


dialogId("map-v-cojetam", "font_big", "What can be on that map?")
dialogStr("Was könnte auf der Karte sein?")


dialogId("map-v-poklady", "font_big", "Do you think that it really shows Silver’s treasure?")
dialogStr("Denkst Du, sie führt wirklich zu Silvers Schatz?")


dialogId("map-m-uvidime", "font_small", "We shall see when we manage to get the darned map out.")
dialogStr("Das werden wir sehen, wenn wir diese verflixte Karte hier herausbekommen haben.")


dialogId("map-m-sneci", "font_small", "We’d need more of these snails.")
dialogStr("Wir werden mehr von diesen Schnecken brauchen.")


dialogId("map-x-hlemyzdi", "font_yellow", "You mean Escargots, don’t you?")
dialogStr("Du meinst Escargots, oder?")


dialogId("map-v-oci", "font_big", "We’d need more glass eyes.")
dialogStr("Wir werden mehr von diesen Glasaugen brauchen.")


dialogId("map-v-restart", "font_big", "The easiest way to do it would be to get to the upper part of this level. Let’s try to restart it, maybe we will appear there.")
dialogStr("Am einfachsten wäre es, wenn wir in den oberen Teil der Ebene kommen würden. Lass uns neustarten, vielleicht erscheinen wir dann dort.")


dialogId("map-m-pravidla", "font_small", "Don’t pretend that you didn’t understand the rules after so many solved levels.")
dialogStr("Tu nicht so, als ob du die Regeln nach so vielen Ebenen noch nicht verstanden hast.")


dialogId("map-m-pohnout", "font_small", "So we managed to move it.")
dialogStr("Wir haben sie bewegt!.")


dialogId("map-v-dal", "font_big", "Let’s keep up the good work.")
dialogStr("Weiter so!")


dialogId("map-m-uz", "font_small", "Yes, it’s almost done.")
dialogStr("Ja, fast fertig.")

