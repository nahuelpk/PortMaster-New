
dialogId("dlg-x-poster1", "font_poster", "After much hardship we succeeded in finding captain Silver’s map. Initial enthusiasm afterwards changed into bitter disappointment, when we found out that the above mentioned map does not indicate the location of the treasure, but the place of residence of the last surviving Silver’s parrot that, unfortunately, suffers from sclerosis and cannot remember, where the treasure is.")
dialogStr("Po wielu trudnościach, udało nam się w końcu odnaleźć mapę kapitana Silvera. Początkowy entuzjazm ustąpił miejsca rozczarowaniu, kiedy zorientowaliśmy się, że rzeczona mapa nie ukazuje miejsca ukrycia skarbu, ale miejsce rezydowania ostatniej żyjącej papugi Silvera, która niestety cierpi na sklerozę i nie pamięta, gdzie ukryty został skarb.")

