
dialogId("map-v-mapa", "font_big", "Oh well. So that map really exists after all!")
dialogStr("Oh bene. Allora dopo tutto quella mappa esiste!")

dialogId("map-m-mapa", "font_small", "Okay. Here is the map.")
dialogStr("Bene. Ecco la mappa.")

dialogId("map-m-ukol", "font_small", "So it’s clear now that our goal is to get that map out somehow.")
dialogStr("Qundi ora è ovvio che il nostro compito è portar fuori quella mappa in qualche modo.")

dialogId("map-v-jasne", "font_big", "Of course. It would be too easy, if we should just swim away.")
dialogStr("Certo. Sarebbe troppo facile se potessimo semplicemente nuotarcene via.")

dialogId("map-m-neplacej", "font_small", "Don’t talk nonsense and try to think instead.")
dialogStr("Non dire fesserie e prova a pensare, invece.")

dialogId("map-v-ukol", "font_big", "Our goal is to get out that map somehow.")
dialogStr("Il nostro scopo ora è di portar fuori la mappa in qualche modo.")

dialogId("map-v-cojetam", "font_big", "What can be on that map?")
dialogStr("Cosa può esserci mai su quella mappa?")

dialogId("map-v-poklady", "font_big", "Do you think that it really shows Silver’s treasure?")
dialogStr("Pensi che indichi veramente il tesoro di Silver?")

dialogId("map-m-uvidime", "font_small", "We shall see when we manage to get the darned map out.")
dialogStr("Lo vedremo quando riusciremo a tirar fuori la dannata mappa.")

dialogId("map-m-sneci", "font_small", "We’d need more of these snails.")
dialogStr("Ce ne servirebbero di più di queste lumache.")

dialogId("map-x-hlemyzdi", "font_yellow", "You mean Escargots, don’t you?")
dialogStr("Vorrai dire Escargots, vero?")

dialogId("map-v-oci", "font_big", "We’d need more glass eyes.")
dialogStr("Ci servirebbero più occhi di vetro.")

dialogId("map-v-restart", "font_big", "The easiest way to do it would be to get to the upper part of this level. Let’s try to restart it, maybe we will appear there.")
dialogStr("La maniera più facile sarebbe di arrivare nella parte alta di questo livello. Proviamo a riavviarlo e forse compariremo là.")

dialogId("map-m-pravidla", "font_small", "Don’t pretend that you didn’t understand the rules after so many solved levels.")
dialogStr("Non far finta di non aver capito le regole del gioco dopo così tanti livelli risolti.")

dialogId("map-m-pohnout", "font_small", "So we managed to move it.")
dialogStr("E siamo riusciti a muoverla.")

dialogId("map-v-dal", "font_big", "Let’s keep up the good work.")
dialogStr("Avanti così.")

dialogId("map-m-uz", "font_small", "Yes, it’s almost done.")
dialogStr("Sì, ce l'abbiamo quasi fatta.")
