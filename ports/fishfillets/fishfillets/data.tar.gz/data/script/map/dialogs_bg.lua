dialogId("map-v-mapa", "font_big", "Oh well. So that map really exists after all!")
dialogStr("Най-сетне. Значи картата все пак съществува!")

dialogId("map-m-mapa", "font_small", "Okay. Here is the map.")
dialogStr("Добре. Ето я и картата.")

dialogId("map-m-ukol", "font_small", "So it’s clear now that our goal is to get that map out somehow.")
dialogStr("Сега поне е ясно, че целта ни е някак да извадим картата.")

dialogId("map-v-jasne", "font_big", "Of course. It would be too easy, if we should just swim away.")
dialogStr("Разбира се. Щеше да е твърде лесно ако просто трябваше да отплуваме.")

dialogId("map-m-neplacej", "font_small", "Don’t talk nonsense and try to think instead.")
dialogStr("Стига си говорил глупости и се опитай да помислиш.")

dialogId("map-v-ukol", "font_big", "Our goal is to get out that map somehow.")
dialogStr("Целта ни е някак да измъкнем картата.")

dialogId("map-v-cojetam", "font_big", "What can be on that map?")
dialogStr("Какво ли има на тази карта?")

dialogId("map-v-poklady", "font_big", "Do you think that it really shows Silver’s treasure?")
dialogStr("Мислиш ли, че наистина показва къде е съкровището на Силвър?")

dialogId("map-m-uvidime", "font_small", "We shall see when we manage to get the darned map out.")
dialogStr("Ще видим когато успеем да я извадим.")

dialogId("map-m-sneci", "font_small", "We’d need more of these snails.")
dialogStr("Ще ни трябват повече от тези охлюви.")

dialogId("map-x-hlemyzdi", "font_yellow", "You mean Escargots, don’t you?")
dialogStr("Имате предвид Ескарготи, нали?")

dialogId("map-v-oci", "font_big", "We’d need more glass eyes.")
dialogStr("Ще ни трябват повече стъклени очи.")

dialogId("map-v-restart", "font_big", "The easiest way to do it would be to get to the upper part of this level. Let’s try to restart it, maybe we will appear there.")
dialogStr("Най лесният начин е да се доберем до горната част на нивото. Да опитаме да рестартираме — може би ще се появим направо там.")

dialogId("map-m-pravidla", "font_small", "Don’t pretend that you didn’t understand the rules after so many solved levels.")
dialogStr("Не се преструвай, че след толкова преминати нива още не разбираш правилата на играта.")

dialogId("map-m-pohnout", "font_small", "So we managed to move it.")
dialogStr("Е, успяхме да го преместим.")

dialogId("map-v-dal", "font_big", "Let’s keep up the good work.")
dialogStr("Да продължаваме в същия дух.")

dialogId("map-m-uz", "font_small", "Yes, it’s almost done.")
dialogStr("Да, почти сме готови.")

