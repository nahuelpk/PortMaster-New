
dialogId("pyr-m-kam", "font_small", "Where are we now?")
dialogStr("Wo sind wir jetzt?")


dialogId("pyr-v-vsim", "font_big", "The Pyramids... Notice how the classical motifs mix in this city.")
dialogStr("Die Pyramiden... Sieh nur, wie sich die klassischen Motive in dieser Stadt vermischen.")


dialogId("pyr-m-plaz", "font_small", "What is that crawling around over there?")
dialogStr("Was krabbelt dort drüben?")


dialogId("pyr-v-druha", "font_big", "You can’t see it from here. It’s on the other side of wall.")
dialogStr("Kannst du es von da aus nicht sehen? Es ist auf der anderen Seite der Mauer.")


dialogId("pyr-m-nudi", "font_small", "Look, the woman is bored!")
dialogStr("Schau, die Frau ist gelangweilt!")


dialogId("pyr-v-sark", "font_big", "Do you think that this is taking us too long?")
dialogStr("Denkst du, wir brauchen hierfür zu lange?")


dialogId("pyr-m-zkus", "font_small", "Try it yourself, if you’re so clever.")
dialogStr("Versuch es selbst, wenn du so schlau bist!")


dialogId("pyr-m-comy", "font_small", "What should we say?")
dialogStr("Was sollen wir sagen?")


dialogId("pyr-m-nic", "font_small", "You don’t have to carry anything.")
dialogStr("Du musst nichts tragen.")


dialogId("pyr-v-sfing", "font_big", "Don’t be afraid.")
dialogStr("Hab keine Angst.")


dialogId("pyr-m-dest", "font_small", "What is it written on these tablets?")
dialogStr("Was steht auf diesen Täfelchen?")


dialogId("pyr-v-sbohem", "font_big", "So long and thanks for all the fish.")
dialogStr("Macht’s gut und danke für den Fisch.")

