
dialogId("pyr-m-kam", "font_small", "Where are we now?")
dialogStr("Waar zijn we nu beland?")


dialogId("pyr-v-vsim", "font_big", "The Pyramids... Notice how the classical motifs mix in this city.")
dialogStr("De pyramiden... Zie je hoe de klassieke motieven vermengen in deze stad?")


dialogId("pyr-m-plaz", "font_small", "What is that crawling around over there?")
dialogStr("Wat kruipt daar?")


dialogId("pyr-v-druha", "font_big", "You can’t see it from here. It’s on the other side of wall.")
dialogStr("Je kunt het van daaraf niet zien. Het zit aan de andere kant van de muur.")


dialogId("pyr-m-nudi", "font_small", "Look, the woman is bored!")
dialogStr("Moet je zien, die vrouw verveelt zich!")


dialogId("pyr-v-sark", "font_big", "Do you think that this is taking us too long?")
dialogStr("Denk je dat dit te lang duurt?")


dialogId("pyr-m-zkus", "font_small", "Try it yourself, if you’re so clever.")
dialogStr("Probeer jij het maar, als je zo slim bent.")


dialogId("pyr-m-comy", "font_small", "What should we say?")
dialogStr("Wat zullen we zeggen?")


dialogId("pyr-m-nic", "font_small", "You don’t have to carry anything.")
dialogStr("Je hoeft niks te dragen.")


dialogId("pyr-v-sfing", "font_big", "Don’t be afraid.")
dialogStr("Wees maar niet bang.")


dialogId("pyr-m-dest", "font_small", "What is it written on these tablets?")
dialogStr("Wat staat er op deze tabletten?")


dialogId("pyr-v-sbohem", "font_big", "So long and thanks for all the fish.")
dialogStr("Tot ziens en bedankt voor de vis.")

