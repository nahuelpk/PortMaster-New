
dialogId("pyr-m-kam", "font_small", "Where are we now?")
dialogStr("E ora dove siamo?")


dialogId("pyr-v-vsim", "font_big", "The Pyramids... Notice how the classical motifs mix in this city.")
dialogStr("Le Piramidi... Osserva come i motivi classici si mescolino in questa città.")


dialogId("pyr-m-plaz", "font_small", "What is that crawling around over there?")
dialogStr("Cos'è quel coso strisciante là?")


dialogId("pyr-v-druha", "font_big", "You can’t see it from here. It’s on the other side of wall.")
dialogStr("Ma se non puoi vederlo da qui! È dall'altra parte del muro.")


dialogId("pyr-m-nudi", "font_small", "Look, the woman is bored!")
dialogStr("Guarda, la signora è annoiata!")


dialogId("pyr-v-sark", "font_big", "Do you think that this is taking us too long?")
dialogStr("Pensi che ci stiamo mettendo troppo?")


dialogId("pyr-m-comy", "font_small", "What should we say?")
dialogStr("Cosa dovremmo dire?")


dialogId("pyr-m-nic", "font_small", "You don’t have to carry anything.")
dialogStr("Lei non deve portare niente.")


dialogId("pyr-v-sfing", "font_big", "Don’t be afraid.")
dialogStr("Non essere dispiaciuta.")


dialogId("pyr-m-dest", "font_small", "What is it written on these tablets?")
dialogStr("Che c'è scritto su queste tavolette?")


dialogId("pyr-v-sbohem", "font_big", "So long and thanks for all the fish.")
dialogStr("Così e così, e grazie per tutto il pesce.")

