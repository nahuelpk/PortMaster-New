
dialogId("pyr-m-kam", "font_small", "Where are we now?")
dialogStr("Où sommes-nous maintenant ?")


dialogId("pyr-v-vsim", "font_big", "The Pyramids... Notice how the classical motifs mix in this city.")
dialogStr("Les pyramides... Regarde comme les motifs classiques se mélangent dans la cité.")


dialogId("pyr-m-plaz", "font_small", "What is that crawling around over there?")
dialogStr("Qu'est-ce qui rampe là-bas ?")


dialogId("pyr-v-druha", "font_big", "You can’t see it from here. It’s on the other side of wall.")
dialogStr("Tu ne peux pas le voir d'ici. C'est de l'autre côté du mur.")


dialogId("pyr-m-nudi", "font_small", "Look, the woman is bored!")
dialogStr("Regarde, la femme s'ennuie.")


dialogId("pyr-v-sark", "font_big", "Do you think that this is taking us too long?")
dialogStr("Tu penses que ça nous prend trop de temps ?")


dialogId("pyr-m-zkus", "font_small", "Try it yourself, if you’re so clever.")
dialogStr("Essaie toi même, si tu es si malin.")


dialogId("pyr-m-comy", "font_small", "What should we say?")
dialogStr("Que devons-nous dire ?")


dialogId("pyr-m-nic", "font_small", "You don’t have to carry anything.")
dialogStr("Tu n'es pas obligé de porter quoi que ce soit.")


dialogId("pyr-v-sfing", "font_big", "Don’t be afraid.")
dialogStr("N'aie pas peur.")


dialogId("pyr-m-dest", "font_small", "What is it written on these tablets?")
dialogStr("Qu'est ce qu'il y a d'écrit sur ces tablettes ?")


dialogId("pyr-v-sbohem", "font_big", "So long and thanks for all the fish.")
dialogStr("Au revoir et merci pour tous les poissons.")

