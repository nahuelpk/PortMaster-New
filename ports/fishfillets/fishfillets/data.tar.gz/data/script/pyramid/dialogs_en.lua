
dialogId("pyr-m-kam", "font_small", "Where are we now?")

dialogId("pyr-v-vsim", "font_big", "The Pyramids... Notice how the classical motifs mix in this city.")

dialogId("pyr-m-plaz", "font_small", "What is that crawling around over there?")

dialogId("pyr-v-druha", "font_big", "You can’t see it from here. It’s on the other side of wall.")

dialogId("pyr-m-nudi", "font_small", "Look, the woman is bored!")

dialogId("pyr-v-sark", "font_big", "Do you think that this is taking us too long?")

dialogId("pyr-m-zkus", "font_small", "Try it yourself, if you’re so clever.")

dialogId("pyr-m-comy", "font_small", "What should we say?")

dialogId("pyr-m-nic", "font_small", "You don’t have to carry anything.")

dialogId("pyr-v-sfing", "font_big", "Don’t be afraid.")

dialogId("pyr-m-dest", "font_small", "What is it written on these tablets?")

dialogId("pyr-v-sbohem", "font_big", "So long and thanks for all the fish.")
