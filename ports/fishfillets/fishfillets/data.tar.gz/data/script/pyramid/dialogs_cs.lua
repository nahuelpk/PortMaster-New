
dialogId("pyr-m-kam", "font_small", "Where are we now?")
dialogStr("Kam jsme se to dostali?")


dialogId("pyr-v-vsim", "font_big", "The Pyramids... Notice how the classical motifs mix in this city.")
dialogStr("Pyramidy... Povšimni si, jak se v tomto městě mísí antické motivy.")


dialogId("pyr-m-plaz", "font_small", "What is that crawling around over there?")
dialogStr("Co se to tam plazí?")


dialogId("pyr-v-druha", "font_big", "You can’t see it from here. It’s on the other side of wall.")
dialogStr("To přece nevidíš. Vždyť je to na druhé straně zdi.")


dialogId("pyr-m-nudi", "font_small", "Look, the woman is bored!")
dialogStr("Podívej, ta ženská se snad nudí!")


dialogId("pyr-v-sark", "font_big", "Do you think that this is taking us too long?")
dialogStr("Tak tobě se zdá, že to trvá dlouho?")


dialogId("pyr-m-zkus", "font_small", "Try it yourself, if you’re so clever.")
dialogStr("Zkus si to sama, když jsi tak chytrá.")


dialogId("pyr-m-comy", "font_small", "What should we say?")
dialogStr("A co máme říkat my?")


dialogId("pyr-m-nic", "font_small", "You don’t have to carry anything.")
dialogStr("Ty tu nic nosit nemusíš.")


dialogId("pyr-v-sfing", "font_big", "Don’t be afraid.")
dialogStr("Neboj se.")


dialogId("pyr-m-dest", "font_small", "What is it written on these tablets?")
dialogStr("Co je asi napsáno na těch destičkách?")


dialogId("pyr-v-sbohem", "font_big", "So long and thanks for all the fish.")
dialogStr("Sbohem a dík za všechny ty ryby.")

