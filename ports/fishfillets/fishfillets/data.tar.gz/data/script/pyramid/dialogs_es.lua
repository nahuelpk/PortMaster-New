
dialogId("pyr-m-kam", "font_small", "Where are we now?")
dialogStr("¿Donde estamos ahora?")


dialogId("pyr-v-vsim", "font_big", "The Pyramids... Notice how the classical motifs mix in this city.")
dialogStr("Las pirámides... Nota como los adornos clásicos se mezclan en esta ciudad.")


dialogId("pyr-m-plaz", "font_small", "What is that crawling around over there?")
dialogStr("¿Qué es eso que se arrastra por ahí?")


dialogId("pyr-v-druha", "font_big", "You can’t see it from here. It’s on the other side of wall.")
dialogStr("No puedes verlo desde aquí. Está en el otro lado de la pared.")


dialogId("pyr-m-nudi", "font_small", "Look, the woman is bored!")
dialogStr("¡Mira, la mujer está aburrida!")


dialogId("pyr-v-sark", "font_big", "Do you think that this is taking us too long?")
dialogStr("¿Crees que esto nos está tomando demasiado?")


dialogId("pyr-m-zkus", "font_small", "Try it yourself, if you’re so clever.")
dialogStr("Inténtalo tu mismo, si eres tan listo.")


dialogId("pyr-m-comy", "font_small", "What should we say?")
dialogStr("¿Qué deberíamos decir?")


dialogId("pyr-m-nic", "font_small", "You don’t have to carry anything.")
dialogStr("Tu no tienes que llevar nada.")


dialogId("pyr-v-sfing", "font_big", "Don’t be afraid.")
dialogStr("No tengas miedo.")


dialogId("pyr-m-dest", "font_small", "What is it written on these tablets?")
dialogStr("¿Qué está escrito en esas tablas?")


dialogId("pyr-v-sbohem", "font_big", "So long and thanks for all the fish.")
dialogStr("Gracias por todos los peces.")

