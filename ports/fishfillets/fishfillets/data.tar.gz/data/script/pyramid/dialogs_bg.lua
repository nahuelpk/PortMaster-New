dialogId("pyr-m-kam", "font_small", "Where are we now?")
dialogStr("Къде сме?")

dialogId("pyr-v-vsim", "font_big", "The Pyramids... Notice how the classical motifs mix in this city.")
dialogStr("Пирамидите... Забележи как се преливат класическите мотиви в града.")

dialogId("pyr-m-plaz", "font_small", "What is that crawling around over there?")
dialogStr("Какво е онова гъмжило там?")

dialogId("pyr-v-druha", "font_big", "You can’t see it from here. It’s on the other side of wall.")
dialogStr("Не можеш да го видиш оттук. От другата страна на стената е.")

dialogId("pyr-m-nudi", "font_small", "Look, the woman is bored!")
dialogStr("Виж, жената е отегчена!")

dialogId("pyr-v-sark", "font_big", "Do you think that this is taking us too long?")
dialogStr("Мислиш ли, че се бавим твърде много тук?")

dialogId("pyr-m-zkus", "font_small", "Try it yourself, if you’re so clever.")
dialogStr("Опитай ти щом се имаш за много умен.")

dialogId("pyr-m-comy", "font_small", "What should we say?")
dialogStr("Как да ти кажа...")

dialogId("pyr-m-nic", "font_small", "You don’t have to carry anything.")
dialogStr("Няма нужда да носиш нищо.")

dialogId("pyr-v-sfing", "font_big", "Don’t be afraid.")
dialogStr("Не се плаши.")

dialogId("pyr-m-dest", "font_small", "What is it written on these tablets?")
dialogStr("Какво пише на тези табелки?")

dialogId("pyr-v-sbohem", "font_big", "So long and thanks for all the fish.")
dialogStr("Сбогом и благодаря за рибата.")

