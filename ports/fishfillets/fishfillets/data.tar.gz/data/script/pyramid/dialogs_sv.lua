
dialogId("pyr-m-kam", "font_small", "Where are we now?")
dialogStr("Var är vi nu?")


dialogId("pyr-v-vsim", "font_big", "The Pyramids... Notice how the classical motifs mix in this city.")
dialogStr("Pyramiderna... Notera hur bra de klassiska motiven gör sig i staden.")


dialogId("pyr-m-plaz", "font_small", "What is that crawling around over there?")
dialogStr("Vad är det för krälande där borta?")


dialogId("pyr-v-druha", "font_big", "You can’t see it from here. It’s on the other side of wall.")
dialogStr("Du kan inte se det härifrån. Det är på andra sidan väggen.")


dialogId("pyr-m-nudi", "font_small", "Look, the woman is bored!")
dialogStr("Titta, kvinnan är uttråkad!")


dialogId("pyr-v-sark", "font_big", "Do you think that this is taking us too long?")
dialogStr("Tror du att det här tar för lång tid?")


dialogId("pyr-m-zkus", "font_small", "Try it yourself, if you’re so clever.")
dialogStr("Försök själv om du nu är så smart!")


dialogId("pyr-m-comy", "font_small", "What should we say?")
dialogStr("Vad ska vi säga?")


dialogId("pyr-m-nic", "font_small", "You don’t have to carry anything.")
dialogStr("Du behöver inte bär omkring på något.")


dialogId("pyr-v-sfing", "font_big", "Don’t be afraid.")
dialogStr("Var inte rädd.")


dialogId("pyr-m-dest", "font_small", "What is it written on these tablets?")
dialogStr("Vad står det på tavlorna?")


dialogId("pyr-v-sbohem", "font_big", "So long and thanks for all the fish.")
dialogStr("Ajöss och tack för fisken.")

