--FIXME
dialogId("pyr-m-kam", "font_small", "Where are we now?")
dialogStr("Где мы?")

dialogId("pyr-v-vsim", "font_big", "The Pyramids... Notice how the classical motifs mix in this city.")
dialogStr("Пирамиды... Заметь, как классические мотивы смешиваются в этом городе.")

dialogId("pyr-m-plaz", "font_small", "What is that crawling around over there?")
dialogStr("Что это там ползает вокруг?")

dialogId("pyr-v-druha", "font_big", "You can’t see it from here. It’s on the other side of wall.")
dialogStr("Ты не можешь увидеть это отсюда. Это по другую сторону стены.")

dialogId("pyr-m-nudi", "font_small", "Look, the woman is bored!")
dialogStr("Смотри, женщина скучает!")

dialogId("pyr-v-sark", "font_big", "Do you think that this is taking us too long?")
dialogStr("Ты думаешь, это займет много времени?")

dialogId("pyr-m-zkus", "font_small", "Try it yourself, if you’re so clever.")
dialogStr("Попробуй сам, если ты такой умный.")

dialogId("pyr-m-comy", "font_small", "What should we say?")
dialogStr("Что мы скажем?")

dialogId("pyr-m-nic", "font_small", "You don’t have to carry anything.")
dialogStr("Тебе не надо ничего нести ")

dialogId("pyr-v-sfing", "font_big", "Don’t be afraid.")
dialogStr("Не бойся.")

dialogId("pyr-m-dest", "font_small", "What is it written on these tablets?")
dialogStr("Что написано на этих табличках?")

dialogId("pyr-v-sbohem", "font_big", "So long and thanks for all the fish.")
dialogStr("Так долго и спасибо за все, рыбы.")

