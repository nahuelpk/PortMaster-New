
dialogId("dlg-x-poster1", "font_poster", "Good morning, fish!")
dialogStr("Goede morgen, vissen!")


dialogId("dlg-x-poster2", "font_poster", "Again, you didn’t disappoint us. General Committee decided to decorate you with the highest orders. They are made of milk chocolate. Due to confidentiality, eat them immediately.")
dialogStr("Jullie hebben ons weer niet teleurgesteld. De Commissie heeft besloten jullie met de hoogste eer te bekleden. Die bestaat uit melkchocolade. Gezien de noodzaak voor geheimhouding moeten jullie het gelijk opeten.")


dialogId("dlg-x-boss", "font_poster", "BOSS")
dialogStr("BAAS")


dialogId("dlg-x-poster3", "font_poster", "PS: I understand this little pld issue, but next time please tell me in advance, so that we can provide an adoption permission.")
dialogStr("PS: Ik heb begrip voor het gedoe met het kleine roze monstertje, maar vertel het volgende keer wat eerder, zodat we de adoptiepapieren op tijd klaar hebben.")


dialogId("dlg-x-poster4", "font_poster", "PPS: Tell me, where did you find such a good player that he managed it all? I wish he won the computer or at least some of the other prizes.")
dialogStr("PPS: Vertel eens, waar heb je zo'n goeie speler vandaan gehaald die alles heeft weten op te lossen? Ik wou dat hij of zij de computer had gewonnen, of in ieder geval één van de andere prijzen.")

