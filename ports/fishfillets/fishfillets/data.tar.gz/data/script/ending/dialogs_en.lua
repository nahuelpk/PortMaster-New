
dialogId("z-v-doma", "font_big", "I am glad to be home again.")

dialogId("z-m-pocit", "font_small", "I have such a good feeling of the work well done.")

dialogId("z-v-sef", "font_big", "The boss called a moment ago. He was very satisfied with our performance.")

dialogId("z-m-nemluv", "font_small", "Don’t mention the boss to me. He sits somewhere in his cozy office and we have to do all the dirty work.")

dialogId("z-v-slyset", "font_big", "Shhh, he could hear us.")

dialogId("z-m-netusi", "font_small", "How could he? He surely doesn’t even know how long it took us.")

dialogId("z-m-dlouho", "font_small", "Really? It didn’t seem that long to me.")

dialogId("z-v-pozdrav", "font_big", "Dear player. We would like to communicate to you the high regards of the authors of this game. If you didn’t solve it by some cheat, you are really very, very good. It’s a pity we cannot see you from here, but...")

dialogId("z-m-oblicej", "font_small", "Could you please put your face in front of the hard disk LED? You might not know it but it is a kind of computer’s eye through which...")

dialogId("z-v-forky", "font_big", "Stop this jokes of yours. This is a very special moment. So:")

dialogId("z-o-blahoprejeme", "font_both", "CONGRATULATIONS!!!")

dialogId("z-c-1", "", "")

dialogId("z-c-2", "", "")

dialogId("z-c-3", "", "")

dialogId("z-c-4", "", "")

dialogId("z-c-5", "", "")

dialogId("z-c-6", "", "")

dialogId("z-c-7", "", "")

dialogId("z-c-8", "", "")

dialogId("z-c-9", "", "")

dialogId("z-c-10", "", "")

dialogId("z-c-11", "", "")

dialogId("z-c-12", "", "")

dialogId("z-c-13", "", "")

dialogId("z-c-14", "", "")

dialogId("z-c-15", "", "")

dialogId("z-c-16", "", "")

dialogId("z-c-17", "", "")

dialogId("z-c-18", "", "")

dialogId("z-c-19", "", "")

dialogId("z-c-20", "", "")

dialogId("z-c-30", "", "")

dialogId("z-c-40", "", "")

dialogId("z-c-50", "", "")

dialogId("z-c-60", "", "")

dialogId("z-c-70", "", "")

dialogId("z-c-80", "", "")

dialogId("z-c-90", "", "")

dialogId("z-c-100", "", "")

dialogId("z-c-200", "", "")

dialogId("z-c-sta", "", "")

dialogId("z-c-set", "", "")

dialogId("z-c-tisic", "", "")

dialogId("z-c-tisice", "", "")

dialogId("z-c-hodin", "font_white", "To be specific, it took you %1 hours!")

dialogId("z-c-konkretne", "", "")

dialogId("bar-x-suck0", "", "")

dialogId("bar-x-suck1", "", "")

dialogId("bar-x-suck2", "", "")

dialogId("bar-x-suck3", "", "")

dialogId("bar-x-suckano", "", "")
