
dialogId("z-v-doma", "font_big", "I am glad to be home again.")
dialogStr("Jsem rád, že jsme zase doma.")


dialogId("z-m-pocit", "font_small", "I have such a good feeling of the work well done.")
dialogStr("Mám takový pěkný pocit dobře odvedené práce.")


dialogId("z-v-sef", "font_big", "The boss called a moment ago. He was very satisfied with our performance.")
dialogStr("Před chvílí volal šéf. Byl s námi moc spokojen.")


dialogId("z-m-nemluv", "font_small", "Don’t mention the boss to me. He sits somewhere in his cozy office and we have to do all the dirty work.")
dialogStr("O šéfovi mi ani nemluv. On si sedí někde v teploučku, zatím co my jsme se dřely.")


dialogId("z-v-slyset", "font_big", "Shhh, he could hear us.")
dialogStr("Pssst, může nás slyšet.")


dialogId("z-m-netusi", "font_small", "How could he? He surely doesn’t even know how long it took us.")
dialogStr("Jak by nás mohl slyšet. Určitě ani netuší, jak dlouho nám to trvalo.")


dialogId("z-m-dlouho", "font_small", "Really? It didn’t seem that long to me.")
dialogStr("Jé, tak dlouho mi to ani nepřipadlo.")


dialogId("z-v-pozdrav", "font_big", "Dear player. We would like to communicate to you the high regards of the authors of this game. If you didn’t solve it by some cheat, you are really very, very good. It’s a pity we cannot see you from here, but...")
dialogStr("Hráči, máme ti vyřídit pozdrav a uznání od autorů hry. Jestli jsi to neřešil nějakým podvodem, tak jsi opravdu dobrej. Nebo dokonce dobrá? My tě tady odsud moc nevidíme.")


dialogId("z-m-oblicej", "font_small", "Could you please put your face in front of the hard disk LED? You might not know it but it is a kind of computer’s eye through which...")
dialogStr("Mohl bys dát obličej před kontrolku harddisku? Možná to nevíš, ale to je takové oko počítače, kterým tě...")


dialogId("z-v-forky", "font_big", "Stop this jokes of yours. This is a very special moment. So:")
dialogStr("Nech už těch fórků. Teď je slavnostní chvíle. Takže:")


dialogId("z-o-blahoprejeme", "font_both", "CONGRATULATIONS!!!")
dialogStr("BLAHOPŘEJEME!!!")


dialogId("z-c-1", "", "")
dialogStr("")


dialogId("z-c-2", "", "")
dialogStr("")


dialogId("z-c-3", "", "")
dialogStr("")


dialogId("z-c-4", "", "")
dialogStr("")


dialogId("z-c-5", "", "")
dialogStr("")


dialogId("z-c-6", "", "")
dialogStr("")


dialogId("z-c-7", "", "")
dialogStr("")


dialogId("z-c-8", "", "")
dialogStr("")


dialogId("z-c-9", "", "")
dialogStr("")


dialogId("z-c-10", "", "")
dialogStr("")


dialogId("z-c-11", "", "")
dialogStr("")


dialogId("z-c-12", "", "")
dialogStr("")


dialogId("z-c-13", "", "")
dialogStr("")


dialogId("z-c-14", "", "")
dialogStr("")


dialogId("z-c-15", "", "")
dialogStr("")


dialogId("z-c-16", "", "")
dialogStr("")


dialogId("z-c-17", "", "")
dialogStr("")


dialogId("z-c-18", "", "")
dialogStr("")


dialogId("z-c-19", "", "")
dialogStr("")


dialogId("z-c-20", "", "")
dialogStr("")


dialogId("z-c-30", "", "")
dialogStr("")


dialogId("z-c-40", "", "")
dialogStr("")


dialogId("z-c-50", "", "")
dialogStr("")


dialogId("z-c-60", "", "")
dialogStr("")


dialogId("z-c-70", "", "")
dialogStr("")


dialogId("z-c-80", "", "")
dialogStr("")


dialogId("z-c-90", "", "")
dialogStr("")


dialogId("z-c-100", "", "")
dialogStr("")


dialogId("z-c-200", "", "")
dialogStr("")


dialogId("z-c-sta", "", "")
dialogStr("")


dialogId("z-c-set", "", "")
dialogStr("")


dialogId("z-c-tisic", "", "")
dialogStr("")


dialogId("z-c-tisice", "", "")
dialogStr("")


dialogId("z-c-hodin", "font_white", "To be specific, it took you %1 hours!")
dialogStr("Konkrétně %1 hodin!")


dialogId("z-c-konkretne", "", "")
dialogStr("")

