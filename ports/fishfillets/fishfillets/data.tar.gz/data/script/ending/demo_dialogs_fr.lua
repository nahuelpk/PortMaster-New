
dialogId("dlg-x-poster1", "font_poster", "Good morning, fish!")
dialogStr("Bonjour, poissons !")


dialogId("dlg-x-poster2", "font_poster", "Again, you didn’t disappoint us. General Committee decided to decorate you with the highest orders. They are made of milk chocolate. Due to confidentiality, eat them immediately.")
dialogStr("À nouveau, vous ne nous avez pas déçu. Le Comité Général a décidé de vous décorer de la plus haute distinction. Les médailles sont en chocolat. Pour cause de confidentialité, mangez-les immédiatement.")


dialogId("dlg-x-boss", "font_poster", "BOSS")
dialogStr("PATRON")


dialogId("dlg-x-poster3", "font_poster", "PS: I understand this little pld issue, but next time please tell me in advance, so that we can provide an adoption permission.")
dialogStr("PS: Je comprends le problème avec la chose nommée pld, mais la prochaine fois prévenez moi, ainsi je pourrais demander une autorisation d'adoption.")


dialogId("dlg-x-poster4", "font_poster", "PPS: Tell me, where did you find such a good player that he managed it all? I wish he won the computer or at least some of the other prizes.")
dialogStr("PPS: Dites moi, où est-ce que vous avez trouvé un(e) si bon(ne) joueur(se) qui a tout résolu ? J'espère qu'il a gagné l'ordinateur ou au moins un des prix.")

