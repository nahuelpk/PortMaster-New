
dialogId("z-v-doma", "font_big", "I am glad to be home again.")
dialogStr("Wszędzie dobrze, ale w domu najlepiej.")


dialogId("z-m-pocit", "font_small", "I have such a good feeling of the work well done.")
dialogStr("Czuję wielką satysfakcję z dobrze wykonanej roboty.")


dialogId("z-v-sef", "font_big", "The boss called a moment ago. He was very satisfied with our performance.")
dialogStr("Szef dzwonił przed chwilą. Bardzo był z nas zadowolony.")


dialogId("z-m-nemluv", "font_small", "Don’t mention the boss to me. He sits somewhere in his cozy office and we have to do all the dirty work.")
dialogStr("Nic mi nie mów o szefie. On sobie siedzi w przytulnym pokoiku, a my musimy odwalać czarną robotę.")


dialogId("z-v-slyset", "font_big", "Shhh, he could hear us.")
dialogStr("Pssst, może nas usłyszeć.")


dialogId("z-m-netusi", "font_small", "How could he? He surely doesn’t even know how long it took us.")
dialogStr("Niby jak? Pewnie nawet nie wie, ile nam to wszystko zajęło.")


dialogId("z-m-dlouho", "font_small", "Really? It didn’t seem that long to me.")
dialogStr("Mnie się nie wydaje, żeby to było strasznie długo.")


dialogId("z-v-pozdrav", "font_big", "Dear player. We would like to communicate to you the high regards of the authors of this game. If you didn’t solve it by some cheat, you are really very, very good. It’s a pity we cannot see you from here, but...")
dialogStr("Graczu, serdecznie ci gratulujemy w imieniu autorów tej gry. Jeśli nie oszukiwałeś przy jej przechodzeniu, jesteś naprawdę, naprawdę dobry. Szkoda, że nie możemy cię zobaczyć, ale...")


dialogId("z-m-oblicej", "font_small", "Could you please put your face in front of the hard disk LED? You might not know it but it is a kind of computer’s eye through which...")
dialogStr("Mógłbyś może przystawić twarz do którejś diody? Może o tym nie wiesz, ale dioda to coś w rodzaju oka, przez które możemy...")


dialogId("z-v-forky", "font_big", "Stop this jokes of yours. This is a very special moment. So:")
dialogStr("Wystarczy tych żartów. To bardzo wyjątkowa chwila, więc...")


dialogId("z-o-blahoprejeme", "font_both", "CONGRATULATIONS!!!")
dialogStr("GRATULACJE!!!")


dialogId("z-c-1", "", "")
dialogStr("")


dialogId("z-c-2", "", "")
dialogStr("")


dialogId("z-c-3", "", "")
dialogStr("")


dialogId("z-c-4", "", "")
dialogStr("")


dialogId("z-c-5", "", "")
dialogStr("")


dialogId("z-c-6", "", "")
dialogStr("")


dialogId("z-c-7", "", "")
dialogStr("")


dialogId("z-c-8", "", "")
dialogStr("")


dialogId("z-c-9", "", "")
dialogStr("")


dialogId("z-c-10", "", "")
dialogStr("")


dialogId("z-c-11", "", "")
dialogStr("")


dialogId("z-c-12", "", "")
dialogStr("")


dialogId("z-c-13", "", "")
dialogStr("")


dialogId("z-c-14", "", "")
dialogStr("")


dialogId("z-c-15", "", "")
dialogStr("")


dialogId("z-c-16", "", "")
dialogStr("")


dialogId("z-c-17", "", "")
dialogStr("")


dialogId("z-c-18", "", "")
dialogStr("")


dialogId("z-c-19", "", "")
dialogStr("")


dialogId("z-c-20", "", "")
dialogStr("")


dialogId("z-c-30", "", "")
dialogStr("")


dialogId("z-c-40", "", "")
dialogStr("")


dialogId("z-c-50", "", "")
dialogStr("")


dialogId("z-c-60", "", "")
dialogStr("")


dialogId("z-c-70", "", "")
dialogStr("")


dialogId("z-c-80", "", "")
dialogStr("")


dialogId("z-c-90", "", "")
dialogStr("")


dialogId("z-c-100", "", "")
dialogStr("")


dialogId("z-c-200", "", "")
dialogStr("")


dialogId("z-c-sta", "", "")
dialogStr("")


dialogId("z-c-set", "", "")
dialogStr("")


dialogId("z-c-tisic", "", "")
dialogStr("")


dialogId("z-c-tisice", "", "")
dialogStr("")


dialogId("z-c-hodin", "font_white", "To be specific, it took you %1 hours!")
dialogStr("Konkretnie, zajęło ci to %1 godzin!")


dialogId("z-c-konkretne", "", "")
dialogStr("")

