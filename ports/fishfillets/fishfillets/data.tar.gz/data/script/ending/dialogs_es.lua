
dialogId("z-v-doma", "font_big", "I am glad to be home again.")
dialogStr("Estoy feliz de estar en casa de nuevo.")


dialogId("z-m-pocit", "font_small", "I have such a good feeling of the work well done.")
dialogStr("Me siento tan bien por el trabajo bien hecho.")


dialogId("z-v-sef", "font_big", "The boss called a moment ago. He was very satisfied with our performance.")
dialogStr("El jefe llamó hace un momento. Estuvo muy satisfecho con nuestro desempeño.")


dialogId("z-m-nemluv", "font_small", "Don’t mention the boss to me. He sits somewhere in his cozy office and we have to do all the dirty work.")
dialogStr("No me menciones al jefe. El se sienta por ahí en su cómoda oficina y nosotros tenemos que hacer todo el trabajo sucio.")


dialogId("z-v-slyset", "font_big", "Shhh, he could hear us.")
dialogStr("Shht, nos podría escuchar.")


dialogId("z-m-netusi", "font_small", "How could he? He surely doesn’t even know how long it took us.")
dialogStr("¿Cómo podría? Seguro que además no sabe cuanto nos tomó.")


dialogId("z-m-dlouho", "font_small", "Really? It didn’t seem that long to me.")
dialogStr("¿Tu crees? No me pareció tanto a mi.")


dialogId("z-v-pozdrav", "font_big", "Dear player. We would like to communicate to you the high regards of the authors of this game. If you didn’t solve it by some cheat, you are really very, very good. It’s a pity we cannot see you from here, but...")
dialogStr("Querido jugador. Nos gustaría comunicarte los grandes saludos de los autores de este juego. Si no lo haz resuelto con algún truco, eres verdaderamente muy, muy bueno. Es una pena que no podamos verte desde aquí, pero...")


dialogId("z-m-oblicej", "font_small", "Could you please put your face in front of the hard disk LED? You might not know it but it is a kind of computer’s eye through which...")
dialogStr("¿Puedes por favor poner tu rostro al frente del LED del disco duro? Quizás no lo sepas pero es un tipo de ojo del computador con el cual...")


dialogId("z-v-forky", "font_big", "Stop this jokes of yours. This is a very special moment. So:")
dialogStr("Basta de tus bromas. Este es un momento muy especial. Así que:")


dialogId("z-o-blahoprejeme", "font_both", "CONGRATULATIONS!!!")
dialogStr("¡¡¡FELICITACIONES!!!")


dialogId("z-c-hodin", "font_white", "To be specific, it took you %1 hours!")
dialogStr("Para ser exactos, ¡Te tomó %1 horas!")

