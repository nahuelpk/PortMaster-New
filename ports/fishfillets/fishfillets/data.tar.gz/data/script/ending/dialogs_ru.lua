-- FIXME. asm
dialogId("z-v-doma", "font_big", "I am glad to be home again.")
dialogStr("Я рад снова быть дома.")

dialogId("z-m-pocit", "font_small", "I have such a good feeling of the work well done.")
dialogStr("У меня есть хорошее предчувствие того, что работа закончена.")

dialogId("z-v-sef", "font_big", "The boss called a moment ago. He was very satisfied with our performance.")
dialogStr("Главный звонил совсем недавно. Он очень доволен нашей работой.")

dialogId("z-m-nemluv", "font_small", "Don’t mention the boss to me. He sits somewhere in his cozy office and we have to do all the dirty work.")
dialogStr("Не говори за главного. Он сидит где нибудь в уютном офисе, а мы должны делать всю грязную работу.")

dialogId("z-v-slyset", "font_big", "Shhh, he could hear us.")
dialogStr("Шшшш, он может нас услышать.")

dialogId("z-m-netusi", "font_small", "How could he? He surely doesn’t even know how long it took us.")
dialogStr("С чего бы? Он едва ли знает сколько отняла эта работа.") --FIXME

dialogId("z-m-dlouho", "font_small", "Really? It didn’t seem that long to me.")
dialogStr("Действительно? Это не так долго для меня.")

dialogId("z-v-pozdrav", "font_big", "Dear player. We would like to communicate to you the high regards of the authors of this game. If you didn’t solve it by some cheat, you are really very, very good. It’s a pity we cannot see you from here, but...")
dialogStr("Дорогой игрок. Мы должны сообщить тебе об уважаемых авторах это игры. Если ты решил это, ты действительно очень очень хорош. К сожалению мы не можем увидеть тебя отсюда, но...")

dialogId("z-m-oblicej", "font_small", "Could you please put your face in front of the hard disk LED? You might not know it but it is a kind of computer’s eye through which...")
dialogStr("Можешь ли ты, пожалуйста, обратить своё лицо на мигающий светодиод жесткого диска? Возможно ты не знаешь, но это один глаз, у компьютера...")

dialogId("z-v-forky", "font_big", "Stop this jokes of yours. This is a very special moment. So:")
dialogStr("Прекрати шутить. Это очень ответственный момент. Итак:")

dialogId("z-o-blahoprejeme", "font_both", "CONGRATULATIONS!!!")
dialogStr("ПОЗДРАВЛЯЕМ!!!")

dialogId("z-c-1", "", "")
dialogStr("")

dialogId("z-c-2", "", "")
dialogStr("")

dialogId("z-c-3", "", "")
dialogStr("")

dialogId("z-c-4", "", "")
dialogStr("")

dialogId("z-c-5", "", "")
dialogStr("")

dialogId("z-c-6", "", "")
dialogStr("")

dialogId("z-c-7", "", "")
dialogStr("")

dialogId("z-c-8", "", "")
dialogStr("")

dialogId("z-c-9", "", "")
dialogStr("")

dialogId("z-c-10", "", "")
dialogStr("")

dialogId("z-c-11", "", "")
dialogStr("")

dialogId("z-c-12", "", "")
dialogStr("")

dialogId("z-c-13", "", "")
dialogStr("")

dialogId("z-c-14", "", "")
dialogStr("")

dialogId("z-c-15", "", "")
dialogStr("")

dialogId("z-c-16", "", "")
dialogStr("")

dialogId("z-c-17", "", "")
dialogStr("")

dialogId("z-c-18", "", "")
dialogStr("")

dialogId("z-c-19", "", "")
dialogStr("")

dialogId("z-c-20", "", "")
dialogStr("")

dialogId("z-c-30", "", "")
dialogStr("")

dialogId("z-c-40", "", "")
dialogStr("")

dialogId("z-c-50", "", "")
dialogStr("")

dialogId("z-c-60", "", "")
dialogStr("")

dialogId("z-c-70", "", "")
dialogStr("")

dialogId("z-c-80", "", "")
dialogStr("")

dialogId("z-c-90", "", "")
dialogStr("")

dialogId("z-c-100", "", "")
dialogStr("")

dialogId("z-c-200", "", "")
dialogStr("")

dialogId("z-c-sta", "", "")
dialogStr("")

dialogId("z-c-set", "", "")
dialogStr("")

dialogId("z-c-tisic", "", "")
dialogStr("")

dialogId("z-c-tisice", "", "")
dialogStr("")

dialogId("z-c-hodin", "font_white", "To be specific, it took you %1 hours!")
dialogStr("Что бы быть точными, это заняло у тебя %1 часа!")

dialogId("z-c-konkretne", "", "")
dialogStr("")

dialogId("bar-x-suck0", "", "")
dialogStr("")

dialogId("bar-x-suck1", "", "")
dialogStr("")

dialogId("bar-x-suck2", "", "")
dialogStr("")

dialogId("bar-x-suck3", "", "")
dialogStr("")

dialogId("bar-x-suckano", "", "")
dialogStr("")

