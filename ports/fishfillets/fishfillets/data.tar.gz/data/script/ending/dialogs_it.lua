
dialogId("z-v-doma", "font_big", "I am glad to be home again.")
dialogStr("Sono lieto di essere di nuovo a casa.")


dialogId("z-m-pocit", "font_small", "I have such a good feeling of the work well done.")
dialogStr("Il lavoro ben fatto mi fa sentire bene.")


dialogId("z-v-sef", "font_big", "The boss called a moment ago. He was very satisfied with our performance.")
dialogStr("Il capo ha appena chiamato. Era molto soddisfatto della nostra prestazione.")


dialogId("z-m-nemluv", "font_small", "Don’t mention the boss to me. He sits somewhere in his cozy office and we have to do all the dirty work.")
dialogStr("Non parlarmene. Lui se ne sta seduto da qualche parte nel suo comodo ufficio e a noi resta da fare tutto il lavoro sporco.")


dialogId("z-v-slyset", "font_big", "Shhh, he could hear us.")
dialogStr("Ssst, potrebbe sentirci.")


dialogId("z-m-netusi", "font_small", "How could he? He surely doesn’t even know how long it took us.")
dialogStr("Come potrebbe? Sicuramente non sa neanche quanto ci è messo.")


dialogId("z-m-dlouho", "font_small", "Really? It didn’t seem that long to me.")
dialogStr("Davvero? A me non è sembrato tanto.")


dialogId("z-v-pozdrav", "font_big", "Dear player. We would like to communicate to you the high regards of the authors of this game. If you didn’t solve it by some cheat, you are really very, very good. It’s a pity we cannot see you from here, but...")
dialogStr("Caro giocatore. Siamo compiaciuti di presentarti i migliori complimenti dagli autori di questo gioco. Se non l'hai risolto con qualche trucchetto, te li meriti proprio. È un peccato che non possiamo vederti da qui, ma...")


dialogId("z-m-oblicej", "font_small", "Could you please put your face in front of the hard disk LED? You might not know it but it is a kind of computer’s eye through which...")
dialogStr("Potresti metterti di fronte al LED dell'hard-disk? Forse non lo sai ma è una specie di occhio del computer attraverso il quale...")


dialogId("z-v-forky", "font_big", "Stop this jokes of yours. This is a very special moment. So:")
dialogStr("Smettila con questi tuoi scherzi. È un momento speciale. Allora:")


dialogId("z-o-blahoprejeme", "font_both", "CONGRATULATIONS!!!")
dialogStr("CONGRATULAZIONI!!!")


dialogId("z-c-hodin", "font_white", "To be specific, it took you %1 hours!")
dialogStr("Per essere precisi, hai impiegato %1 ore!")

