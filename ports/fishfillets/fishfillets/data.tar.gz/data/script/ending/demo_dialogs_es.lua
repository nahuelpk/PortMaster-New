
dialogId("dlg-x-poster1", "font_poster", "Good morning, fish!")
dialogStr("¡Buenos días, peces!")


dialogId("dlg-x-poster2", "font_poster", "Again, you didn’t disappoint us. General Committee decided to decorate you with the highest orders. They are made of milk chocolate. Due to confidentiality, eat them immediately.")
dialogStr("Nuevamente, ustedes no nos han defraudado. El Comité General ha decidido condecorarlos con las más altas órdenes. Estas están hechas de chocolate de leche. Debido a la confidencialidad, cómanlas inmediatamente.")


dialogId("dlg-x-boss", "font_poster", "BOSS")
dialogStr("JEFE")


dialogId("dlg-x-poster3", "font_poster", "PS: I understand this little pld issue, but next time please tell me in advance, so that we can provide an adoption permission.")
dialogStr("PD: Entiendo este pequeño problema, pero la próxima vez por favor díganme en forma anticipada, para que podamos facilitarles un permiso de adopción.")


dialogId("dlg-x-poster4", "font_poster", "PPS: Tell me, where did you find such a good player that he managed it all? I wish he won the computer or at least some of the other prizes.")
dialogStr("PPD: Díganme, ¿Donde encontraron a tan buen jugador que manejó todo? Espero que gane el computador o al menos algunos de los otros premios.")

