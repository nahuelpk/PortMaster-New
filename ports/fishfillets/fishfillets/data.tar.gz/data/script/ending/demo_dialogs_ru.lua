-- FIXME. asm
dialogId("dlg-x-poster1", "font_poster", "Good morning, fish!")
dialogStr("Доброе утро, рыбы!")

dialogId("dlg-x-poster2", "font_poster", "Again, you didn’t disappoint us. General Committee decided to decorate you with the highest orders. They are made of milk chocolate. Due to confidentiality, eat them immediately.")
dialogStr("Снова вы не разочаровали меня. Главная Комиссия решила наградить вас большим орденом. Это будет молочная шоколадка. Это должно быть секретно, съешьте её немедленно.")

dialogId("dlg-x-boss", "font_poster", "BOSS")
dialogStr("КАПИТАН")

dialogId("dlg-x-poster3", "font_poster", "PS: I understand this little pld issue, but next time please tell me in advance, so that we can provide an adoption permission.")
dialogStr("P.S.: Я понял это маленькое течение, но в следующий раз пожалуйста сообщайте мне заранее, и мы сможешь принять обоснованное решение.")

dialogId("dlg-x-poster4", "font_poster", "PPS: Tell me, where did you find such a good player that he managed it all? I wish he won the computer or at least some of the other prizes.")
dialogStr("P.P.S.: Скажите мне, где вы нашли такого хорошего игрока, который смог сделать это все, я хотел лишь обыграть компьютер или получить какую нибудь другую награду.")

-- Стыдно, но ничего не понял, из того, что тут написано. :-(
