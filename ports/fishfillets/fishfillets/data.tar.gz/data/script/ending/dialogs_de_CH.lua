
dialogId("z-m-netusi", "font_small", "How could he? He surely doesn’t even know how long it took us.")
dialogStr("Wie könnte er? Er weiss sicher nicht einmal, wie lange wir gebraucht haben.")


dialogId("z-v-pozdrav", "font_big", "Dear player. We would like to communicate to you the high regards of the authors of this game. If you didn’t solve it by some cheat, you are really very, very good. It’s a pity we cannot see you from here, but...")
dialogStr("Werter Spieler, wir möchten dir die besten Grüsse der Autoren dieses Spiels über mitteln. Wenn du nicht geschummelt hast, bist du wirklich sehr, sehr gut. Schade, dass wir dich nicht von hier sehen können, aber...")


dialogId("z-m-oblicej", "font_small", "Could you please put your face in front of the hard disk LED? You might not know it but it is a kind of computer’s eye through which...")
dialogStr("Kannst du bitte dein Gesicht vor die Festplatten-LED halten? Vielleicht weisst du es nicht, aber das ist so eine Art Rechnerauge, durch das...")

