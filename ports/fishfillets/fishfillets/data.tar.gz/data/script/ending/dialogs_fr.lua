
dialogId("z-v-doma", "font_big", "I am glad to be home again.")
dialogStr("Je suis content de rentrer à la maison.")


dialogId("z-m-pocit", "font_small", "I have such a good feeling of the work well done.")
dialogStr("J'ai vraiment le sentiment du travail bien fait.")


dialogId("z-v-sef", "font_big", "The boss called a moment ago. He was very satisfied with our performance.")
dialogStr("Le patron vient d'appeler. Il est très satisfait de nous.")


dialogId("z-m-nemluv", "font_small", "Don’t mention the boss to me. He sits somewhere in his cozy office and we have to do all the dirty work.")
dialogStr("Ne me parle pas du patron. Il est assis quelque part dans un bureau douillet et nous faisons tout le sale boulot.")


dialogId("z-v-slyset", "font_big", "Shhh, he could hear us.")
dialogStr("Chut, il pourrait nous entendre.")


dialogId("z-m-netusi", "font_small", "How could he? He surely doesn’t even know how long it took us.")
dialogStr("Comment le pourrait-il ? Il ne sait même pas combien de temps ça nous a pris.")


dialogId("z-m-dlouho", "font_small", "Really? It didn’t seem that long to me.")
dialogStr("Vraiment ? Ça ne m'a pas paru si long que ça.")


dialogId("z-v-pozdrav", "font_big", "Dear player. We would like to communicate to you the high regards of the authors of this game. If you didn’t solve it by some cheat, you are really very, very good. It’s a pity we cannot see you from here, but...")
dialogStr("Chère joueuse ou cher joueur. Nous aimerions vous faire part du grand respect des auteurs de ce jeu envers vous. Si vous l'avez fini sans tricher, vous êtes vraiment très très fort(e). C'est vraiment dommage que nous ne puissions pas vous voir d'ici, mais...")


dialogId("z-m-oblicej", "font_small", "Could you please put your face in front of the hard disk LED? You might not know it but it is a kind of computer’s eye through which...")
dialogStr("Pouvez-vous s'il vous plaît mettre votre visage en face de la diode du disque dur ? Vous ne le savez probablement pas mais c'est comme un oeil pour l'ordinateur à travers lequel...")


dialogId("z-v-forky", "font_big", "Stop this jokes of yours. This is a very special moment. So:")
dialogStr("Arrête ta plaisanterie. C'est un moment très spécial. alors :")


dialogId("z-o-blahoprejeme", "font_both", "CONGRATULATIONS!!!")
dialogStr("FÉLICITATIONS!!!")


dialogId("z-c-hodin", "font_white", "To be specific, it took you %1 hours!")
dialogStr("Pour être précis, vous avez mis %1 heures !")

