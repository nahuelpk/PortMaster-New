dialogId("dlg-x-poster1", "font_poster", "Good morning, fish!")
dialogStr("Добро утро, рибки!")

dialogId("dlg-x-poster2", "font_poster", "Again, you didn’t disappoint us. General Committee decided to decorate you with the highest orders. They are made of milk chocolate. Due to confidentiality, eat them immediately.")
dialogStr("Отново не ни разочаровахте. Генералският съвет реши да ви награди с най-високите отличия. Направени са от млечен шоколад. Поради секретността трябва да ги изядете незабавно.")

dialogId("dlg-x-boss", "font_poster", "BOSS")
dialogStr("ШЕФА")

dialogId("dlg-x-poster3", "font_poster", "PS: I understand this little pld issue, but next time please tell me in advance, so that we can provide an adoption permission.")
dialogStr("П.П.: Разбирам за малкия ви проблем, но следващият път ме предупредете предварително за да можем да уредим разрешение за осиновяване.")

dialogId("dlg-x-poster4", "font_poster", "PPS: Tell me, where did you find such a good player that he managed it all? I wish he won the computer or at least some of the other prizes.")
dialogStr("П.П.П.: Кажете, откъде намерихте толкова печен играч, който да стигне докрай? Дано да е спечелил компютъра или поне някоя от другите награди.")

