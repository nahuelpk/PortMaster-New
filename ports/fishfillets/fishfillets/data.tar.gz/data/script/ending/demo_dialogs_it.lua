
dialogId("dlg-x-poster1", "font_poster", "Good morning, fish!")
dialogStr("Buongiorno, pesci!")


dialogId("dlg-x-poster2", "font_poster", "Again, you didn’t disappoint us. General Committee decided to decorate you with the highest orders. They are made of milk chocolate. Due to confidentiality, eat them immediately.")
dialogStr("Ancora una volta, non ci avete delusi. Il Comitato Generale ha deciso di decorarvi con i più alti gradi. Sono fatti di cioccolata al latte. In virtù della loro confidenzialità, mangiateli immediatamente.")


dialogId("dlg-x-boss", "font_poster", "BOSS")
dialogStr("IL CAPO")


dialogId("dlg-x-poster3", "font_poster", "PS: I understand this little pld issue, but next time please tell me in advance, so that we can provide an adoption permission.")
dialogStr("PS: Capisco questo piccolo problema con pld, ma la prossima volta fatecelo sapere in aticipo, così che possiamo procurarvi un permesso di adozione.")


dialogId("dlg-x-poster4", "font_poster", "PPS: Tell me, where did you find such a good player that he managed it all? I wish he won the computer or at least some of the other prizes.")
dialogStr("PPS: Ditemi, dove avete trovato un giocatore così bravo da farcela? Avrei voluto che vincesse il computer o almeno qualcuno degli altri premi.")

