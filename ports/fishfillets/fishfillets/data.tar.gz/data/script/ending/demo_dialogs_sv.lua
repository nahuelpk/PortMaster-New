
dialogId("dlg-x-poster1", "font_poster", "Good morning, fish!")
dialogStr("God morgon, fiskar!")


dialogId("dlg-x-poster2", "font_poster", "Again, you didn’t disappoint us. General Committee decided to decorate you with the highest orders. They are made of milk chocolate. Due to confidentiality, eat them immediately.")
dialogStr("Ni har inte gjort oss besvikna den här gången heller. Generalkommitén har beslutat att tilldela er den högsta ordern. De är gjorda av mjölkschoklad. På grund av hemligstämpling så måste ni äta upp dem omedelbart!")


dialogId("dlg-x-boss", "font_poster", "BOSS")
dialogStr("CHEFEN")


dialogId("dlg-x-poster3", "font_poster", "PS: I understand this little pld issue, but next time please tell me in advance, so that we can provide an adoption permission.")
dialogStr("PS: Jag förstår det lilla monster problemet, men informera mig i förväg nästa gång så kan vi ordna med adoptionstillstånd.")


dialogId("dlg-x-poster4", "font_poster", "PPS: Tell me, where did you find such a good player that he managed it all? I wish he won the computer or at least some of the other prizes.")
dialogStr("PPS: Kan ni säga mig var ni hittade så här bra spelare som klarade allt? Jag önskar att han hade vunnit datorn eller något av de andra priserna.")

