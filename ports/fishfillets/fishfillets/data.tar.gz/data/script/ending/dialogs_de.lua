
dialogId("z-v-doma", "font_big", "I am glad to be home again.")
dialogStr("Ich bin froh, wieder zuhause zu sein.")


dialogId("z-m-pocit", "font_small", "I have such a good feeling of the work well done.")
dialogStr("Ich hab so ein gutes Gefühl wegen der gut erledigten Arbeit.")


dialogId("z-v-sef", "font_big", "The boss called a moment ago. He was very satisfied with our performance.")
dialogStr("Der Chef hat gerade angerufen. Er war sehr zufrieden mit unserer Leistung.")


dialogId("z-m-nemluv", "font_small", "Don’t mention the boss to me. He sits somewhere in his cozy office and we have to do all the dirty work.")
dialogStr("Komm mir nicht mit dem Chef. Der sitzt irgendwo in seinem gemütlichen Büro und wir müssen die ganze Drecksarbeit erledigen.")


dialogId("z-v-slyset", "font_big", "Shhh, he could hear us.")
dialogStr("Psst, er könnte uns hören.")


dialogId("z-m-netusi", "font_small", "How could he? He surely doesn’t even know how long it took us.")
dialogStr("Wie könnte er? Er weiß sicher nicht einmal, wie lange wir gebraucht haben.")


dialogId("z-m-dlouho", "font_small", "Really? It didn’t seem that long to me.")
dialogStr("Wirklich? Mir kam es gar nicht so lang vor.")


dialogId("z-v-pozdrav", "font_big", "Dear player. We would like to communicate to you the high regards of the authors of this game. If you didn’t solve it by some cheat, you are really very, very good. It’s a pity we cannot see you from here, but...")
dialogStr("Werter Spieler, wir möchten dir die besten Grüße der Autoren dieses Spiels über mitteln. Wenn du nicht geschummelt hast, bist du wirklich sehr, sehr gut. Schade, dass wir dich nicht von hier sehen können, aber...")


dialogId("z-m-oblicej", "font_small", "Could you please put your face in front of the hard disk LED? You might not know it but it is a kind of computer’s eye through which...")
dialogStr("Kannst du bitte dein Gesicht vor die Festplatten-LED halten? Vielleicht weißt du es nicht, aber das ist so eine Art Rechnerauge, durch das...")


dialogId("z-v-forky", "font_big", "Stop this jokes of yours. This is a very special moment. So:")
dialogStr("Lass deine Witze. Das ist ein sehr besonderer Augenblick. Also:")


dialogId("z-o-blahoprejeme", "font_both", "CONGRATULATIONS!!!")
dialogStr("HERZLICHEN GLÜCKWUNSCH!!!")


dialogId("z-c-hodin", "font_white", "To be specific, it took you %1 hours!")
dialogStr("Um genau zu sein, du hast %1 Stunden gebraucht!")

