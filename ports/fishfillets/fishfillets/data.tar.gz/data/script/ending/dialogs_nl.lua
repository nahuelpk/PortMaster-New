
dialogId("z-v-doma", "font_big", "I am glad to be home again.")
dialogStr("Ik ben blij dat we weer thuis zijn.")


dialogId("z-m-pocit", "font_small", "I have such a good feeling of the work well done.")
dialogStr("Ik heb zo'n voldaan gevoel nou we al dat werk hebben verzet.")


dialogId("z-v-sef", "font_big", "The boss called a moment ago. He was very satisfied with our performance.")
dialogStr("De baas heeft net gebeld. Hij was erg tevreden over ons optreden.")


dialogId("z-m-nemluv", "font_small", "Don’t mention the boss to me. He sits somewhere in his cozy office and we have to do all the dirty work.")
dialogStr("Ik wil niks horen over de baas. Die zit ergens lekker achter een bureautje en wij moeten de rotklusjes opknappen.")


dialogId("z-v-slyset", "font_big", "Shhh, he could hear us.")
dialogStr("Ssst, hij kan ons misschien wel horen.")


dialogId("z-m-netusi", "font_small", "How could he? He surely doesn’t even know how long it took us.")
dialogStr("Hoe dan? Hij weet vast niet eens hoe lang we erover gedaan hebben.")


dialogId("z-m-dlouho", "font_small", "Really? It didn’t seem that long to me.")
dialogStr("Hoe bedoel je? Mij leek het niet zo lang, hoor.")


dialogId("z-v-pozdrav", "font_big", "Dear player. We would like to communicate to you the high regards of the authors of this game. If you didn’t solve it by some cheat, you are really very, very good. It’s a pity we cannot see you from here, but...")
dialogStr("Beste speler. We willen je graag de groeten doen van de makers van dit spel. Als je niet hebt valsgespeeld ben je echt heeeeeeel, heeeeeel erg goed. Het is jammer dat we je van hieraf niet kunnen zien, maar...")


dialogId("z-m-oblicej", "font_small", "Could you please put your face in front of the hard disk LED? You might not know it but it is a kind of computer’s eye through which...")
dialogStr("Kun je alsjeblieft je gezicht voor het harde-schijfLEDje houden? Misschien wist je het niet, maar dat is zo'n beetje het oog van de computer...")


dialogId("z-v-forky", "font_big", "Stop this jokes of yours. This is a very special moment. So:")
dialogStr("Hou op met je domme grapjes. Dit is een heel speciaal moment. Dus:")


dialogId("z-o-blahoprejeme", "font_both", "CONGRATULATIONS!!!")
dialogStr("GEFELICITEERD!!!")


dialogId("z-c-hodin", "font_white", "To be specific, it took you %1 hours!")
dialogStr("Om precies te zijn, het heeft je %1 uur gekost om alles op te lossen!")

