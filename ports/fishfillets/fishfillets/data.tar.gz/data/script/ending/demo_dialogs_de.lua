
dialogId("dlg-x-poster1", "font_poster", "Good morning, fish!")
dialogStr("Guten Morgen, Fische!")


dialogId("dlg-x-poster2", "font_poster", "Again, you didn’t disappoint us. General Committee decided to decorate you with the highest orders. They are made of milk chocolate. Due to confidentiality, eat them immediately.")
dialogStr("Ihr habt uns wieder mal nicht enttäuscht. Das Generalkomitee hat entschieden, euch die höchste Auszeichnung zukommen zu lassen. Die Medaillen sind aus Schokolade. Aus Geheimhaltungsgründen bitte sofort essen!")


dialogId("dlg-x-boss", "font_poster", "BOSS")
dialogStr("CHEF")


dialogId("dlg-x-poster3", "font_poster", "PS: I understand this little pld issue, but next time please tell me in advance, so that we can provide an adoption permission.")
dialogStr("PS: Ich verstehe diese kleine Monster-Sache, aber gebt mir das nächste Mal bitte vorher Bescheid, dann können wir eine Adoptionserlaubnis einholen.")


dialogId("dlg-x-poster4", "font_poster", "PPS: Tell me, where did you find such a good player that he managed it all? I wish he won the computer or at least some of the other prizes.")
dialogStr("PPS: Sagt mir, wo habt ihr einen so guten Spieler gefunden, dass er alles geschafft hat? Ich wünschte er hätte den Rechner oder zumindest ein paar andere Preise gewonnen.")

