
dialogId("dlg-x-poster1", "font_poster", "Good morning, fish!")
dialogStr("Dzień dobry, ryby!")


dialogId("dlg-x-poster2", "font_poster", "Again, you didn’t disappoint us. General Committee decided to decorate you with the highest orders. They are made of milk chocolate. Due to confidentiality, eat them immediately.")
dialogStr("Po raz kolejny pokazaliście, że możemy na was polegać. Komitet Generalny zdecydował, że zostaniecie odznaczeni najwyższym orderem Organizacji. Ordery zrobione są z czekolady i zaleca się ich natychmiastową konsumpcję w celu zapobieżenia odtajnieniu Organizacji.")


dialogId("dlg-x-boss", "font_poster", "BOSS")
dialogStr("SZEF")


dialogId("dlg-x-poster3", "font_poster", "PS: I understand this little pld issue, but next time please tell me in advance, so that we can provide an adoption permission.")
dialogStr("PS. Rozumiem wasze przywiązanie do plda, ale następnym razem poinformujcie nas, abyśmy mogli przygotować zezwolenie adopcyjne.")


dialogId("dlg-x-poster4", "font_poster", "PPS: Tell me, where did you find such a good player that he managed it all? I wish he won the computer or at least some of the other prizes.")
dialogStr("PPS. Powiedzcie mi, gdzie znaleźliście takiego dobrego gracza, który dał temu wszystkiemu rady? Przydałoby się wręczyć mu jakiś przyzwoity komputer albo inną nagrodę rzeczową...")

