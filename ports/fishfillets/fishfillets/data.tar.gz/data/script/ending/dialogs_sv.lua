
dialogId("z-v-doma", "font_big", "I am glad to be home again.")
dialogStr("Trevligt att vara hemma igen.")


dialogId("z-m-pocit", "font_small", "I have such a good feeling of the work well done.")
dialogStr("Det känns så bra när allt jobb är färdigt.")


dialogId("z-v-sef", "font_big", "The boss called a moment ago. He was very satisfied with our performance.")
dialogStr("Chefen ringde nyss. Han var nöjd med våra prestationer.")


dialogId("z-m-nemluv", "font_small", "Don’t mention the boss to me. He sits somewhere in his cozy office and we have to do all the dirty work.")
dialogStr("Nämn inte chefen. Han sitter någonstans i ett mysigt kontor när vi får göra allt skitjobb.")


dialogId("z-v-slyset", "font_big", "Shhh, he could hear us.")
dialogStr("Schhh, han kan höra oss.")


dialogId("z-m-netusi", "font_small", "How could he? He surely doesn’t even know how long it took us.")
dialogStr("Hur då? Han vet definitivt inte hur lång tid det tog oss.")


dialogId("z-m-dlouho", "font_small", "Really? It didn’t seem that long to me.")
dialogStr("Verkligen? Jag tyckte inte det verkade vara så länge.")


dialogId("z-v-pozdrav", "font_big", "Dear player. We would like to communicate to you the high regards of the authors of this game. If you didn’t solve it by some cheat, you are really very, very good. It’s a pity we cannot see you from here, but...")
dialogStr("Kära spelare. Vi skulle vilja överlämna de största lyckönskningarna från spelets författare. Om du inte fuskade någon gång så är du mycket, mycket bra. Synd att vi inte kan se dig här inifrån, men...")


dialogId("z-m-oblicej", "font_small", "Could you please put your face in front of the hard disk LED? You might not know it but it is a kind of computer’s eye through which...")
dialogStr("Kan du vara snäll och hålla dit ansikte framför hårddisk lampan? Du kanske inte vet det men det är ett sorts datoröga genom vilket...")


dialogId("z-v-forky", "font_big", "Stop this jokes of yours. This is a very special moment. So:")
dialogStr("Sluta upp att skämta. Det är ett mycket speciellt ögonblick. Så:")


dialogId("z-o-blahoprejeme", "font_both", "CONGRATULATIONS!!!")
dialogStr("GRATTIS!!!")


dialogId("z-c-hodin", "font_white", "To be specific, it took you %1 hours!")
dialogStr("För att vara exakt så tog det %1 timmar!")

