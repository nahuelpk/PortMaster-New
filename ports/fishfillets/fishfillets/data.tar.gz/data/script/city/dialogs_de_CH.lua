
dialogId("vit-hs-vitejteC", "font_statue", "On behalf of the citizens of this town I welcome you.")
dialogStr("Im Namen der Bewohner dieser Stadt heiße ich euch willkommen.")


dialogId("vit-hs-reklama2", "font_white", "To Moon Street. I need to order eight swords.")
dialogStr("Zur Mondstrasse. Ich muss acht Schwerter bestellen.")

