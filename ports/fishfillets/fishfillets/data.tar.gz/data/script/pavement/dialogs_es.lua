
dialogId("dir-m-rada0", "font_small", "Stuff yourself with your advice.")
dialogStr("Guárdate tus consejos.")


dialogId("dir-m-rada1", "font_small", "We know that very well.")
dialogStr("Lo sabemos muy bien.")


dialogId("dir-m-rada2", "font_small", "Get lost.")
dialogStr("Piérdete.")


dialogId("dir-m-rada3", "font_small", "My patience is running out.")
dialogStr("Mi paciencia se está acabando.")


dialogId("dir-m-rada4", "font_small", "Arrgh... I’ll smash it to pieces.")
dialogStr("Aaaah... Lo destrozaré en pedacitos.")


dialogId("dir-v-rada0", "font_big", "Ignore it, let it talk.")
dialogStr("Ignóralo, déjalo hablar.")


dialogId("dir-v-rada1", "font_big", "Let us think.")
dialogStr("Pensemos.")


dialogId("dir-v-rada2", "font_big", "This was some advice, again.")
dialogStr("Este fué un aviso, de nuevo.")


dialogId("dir-v-rada3", "font_big", "It’s a shame I have no ears. I could plug them.")
dialogStr("Es una lástima que no tenga oídos. Los podría tapar.")


dialogId("dir-v-rada4", "font_big", "I am fed up to my gills with its nonsense.")
dialogStr("Estoy relleno hasta mis branquias con sus cosas sin sentido.")


dialogId("dir-hs-uvod0", "font_statue", "It would be easiest if you")
dialogStr("Sería más fácil si tu")


dialogId("dir-hs-uvod1", "font_statue", "You would be better off if you")
dialogStr("No sería mejor si tu")


dialogId("dir-hs-uvod2", "font_statue", "It would help you if you")
dialogStr("Te ayudaría si tu")


dialogId("dir-hs-uvod3", "font_statue", "I have an idea. What if you")
dialogStr("Tengo una idea. Que tal si tu")


dialogId("dir-hs-uvod4", "font_statue", "Sorry to interrupt, but what if you")
dialogStr("Disculpa si te interrumpo, pero que tal si tu")


dialogId("dir-hs-konec0", "font_statue", "demolish some wall.")
dialogStr("destruyes alguna pared.")


dialogId("dir-hs-konec1", "font_statue", "break off a few stones from the wall and plug the holes with them.")
dialogStr("rompes algunas piedras de la pared y tapas los agujeros con ellas.")


dialogId("dir-hs-konec2", "font_statue", "plug those holes with something so that that hooked steel wouldn’t get stuck there.")
dialogStr("tapas esos agujeros con algo para que ese acero enganchado no se atasque ahí.")


dialogId("dir-hs-konec3", "font_statue", "smash that pillar by the exit.")
dialogStr("demueles ese pilar por la salida.")


dialogId("dir-hs-konec4", "font_statue", "saw off some of that hooked steel.")
dialogStr("pones atención a ese acero enganchado.")


dialogId("dir-hs-konec5", "font_statue", "rearrange the objects so that you can swim out.")
dialogStr("reorganizas los objetos para que puedas nadar hacia afuera.")


dialogId("dir-hs-konec6", "font_statue", "solve it somehow and get to the next level.")
dialogStr("lo resuelves de alguna forma y llegas al próximo nivel.")


dialogId("dir-hs-konec7", "font_statue", "start to think about it really hard.")
dialogStr("empiezas a pensar en eso realmente en serio.")


dialogId("dir-hs-konec8", "font_statue", "swim out through that hole on the left.")
dialogStr("nadas hacia afuera a través de ese agujero a la izquierda.")

