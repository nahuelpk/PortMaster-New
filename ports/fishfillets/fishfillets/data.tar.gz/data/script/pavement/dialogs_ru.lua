--FIXME adascor
dialogId("dir-m-rada0", "font_small", "Stuff yourself with your advice.")
dialogStr("Оставь при себе свои советы.")

dialogId("dir-m-rada1", "font_small", "We know that very well.")
dialogStr("Мы знаем это очень хорошо.")

dialogId("dir-m-rada2", "font_small", "Get lost.")
dialogStr("Исчезни.")

dialogId("dir-m-rada3", "font_small", "My patience is running out.")
dialogStr("Мое терпение на исходе.")

dialogId("dir-m-rada4", "font_small", "Arrgh... I’ll smash it to pieces.")
dialogStr("Арргх... Я разберу его на кусочки.")

dialogId("dir-v-rada0", "font_big", "Ignore it, let it talk.")
dialogStr("Оставь его, дай ему сказать.")

dialogId("dir-v-rada1", "font_big", "Let us think.")
dialogStr("Давай подумаем.")

dialogId("dir-v-rada2", "font_big", "This was some advice, again.")
dialogStr("Это был какой-то совет, снова.")

dialogId("dir-v-rada3", "font_big", "It’s a shame I have no ears. I could plug them.")
dialogStr("Это позор, у меня нет ушей. Я возможно заткнул их.")

dialogId("dir-v-rada4", "font_big", "I am fed up to my gills with its nonsense.")
dialogStr("Я сыт по жабры от этой бессмыслицы.")

dialogId("dir-hs-uvod0", "font_statue", "It would be easiest if you")
dialogStr("Будет проще, если ты")

dialogId("dir-hs-uvod1", "font_statue", "You would be better off if you")
dialogStr("Тебе будет лучше, если ты")

dialogId("dir-hs-uvod2", "font_statue", "It would help you if you")
dialogStr("У тебя будет помощь, если ты")

dialogId("dir-hs-uvod3", "font_statue", "I have an idea. What if you")
dialogStr("У меня есть идея. Что, если ты")

dialogId("dir-hs-uvod4", "font_statue", "Sorry to interrupt, but what if you")
dialogStr("Извини, что прервал, но что, если ты")

dialogId("dir-hs-konec0", "font_statue", "demolish some wall.")
dialogStr("уничтожишь некую стену.")

dialogId("dir-hs-konec1", "font_statue", "break off a few stones from the wall and plug the holes with them.")
dialogStr("вытащи несколько камней из стены и закупорь ими дыры.")

dialogId("dir-hs-konec2", "font_statue", "plug those holes with something so that that hooked steel wouldn’t get stuck there.")
dialogStr("Заполните дыры чем-нибудь так, чтобы крючковатая сталь не застряла там.")

dialogId("dir-hs-konec3", "font_statue", "smash that pillar by the exit.")
dialogStr("Разрушьте этот столб, чтобы выйти.")

dialogId("dir-hs-konec4", "font_statue", "saw off some of that hooked steel.")
dialogStr("Отрежьте часть той крючковатой стали.")

dialogId("dir-hs-konec5", "font_statue", "rearrange the objects so that you can swim out.")
dialogStr("Разместите объекты так, чтобы вы могли проплыть.")

dialogId("dir-hs-konec6", "font_statue", "solve it somehow and get to the next level.")
dialogStr("Решите это как-нибудь и переходите на следующий уровень.")

dialogId("dir-hs-konec7", "font_statue", "start to think about it really hard.")
dialogStr("Начать думать об этом действительно очень трудно.")

dialogId("dir-hs-konec8", "font_statue", "swim out through that hole on the left.")
dialogStr("Уплывайте отсюда через дыру налево.")

dialogId("k1-chob-1", "", "")
dialogStr("")

dialogId("k1-chob-2", "", "")
dialogStr("")

dialogId("k1-chob-3", "", "")
dialogStr("")

dialogId("k1-chob-p", "", "")
dialogStr("")

dialogId("k1-x-vrz", "", "")
dialogStr("")

