
dialogId("dir-m-rada0", "font_small", "Stuff yourself with your advice.")
dialogStr("Mettiti i tuoi consigli dove sai tu.")


dialogId("dir-m-rada1", "font_small", "We know that very well.")
dialogStr("Lo sappiamo benissimo.")


dialogId("dir-m-rada2", "font_small", "Get lost.")
dialogStr("Sparisci.")


dialogId("dir-m-rada3", "font_small", "My patience is running out.")
dialogStr("La mia pazienza si sta esaurendo.")


dialogId("dir-m-rada4", "font_small", "Arrgh... I’ll smash it to pieces.")
dialogStr("Arrgh... ti faccio a pezzi.")


dialogId("dir-v-rada0", "font_big", "Ignore it, let it talk.")
dialogStr("Ignoralo, lascialo parlare.")


dialogId("dir-v-rada1", "font_big", "Let us think.")
dialogStr("Lasciaci pensare.")


dialogId("dir-v-rada2", "font_big", "This was some advice, again.")
dialogStr("Ancora questi consigli...")


dialogId("dir-v-rada3", "font_big", "It’s a shame I have no ears. I could plug them.")
dialogStr("È un peccato non avere le orecchie. Così potevo tapparmele.")


dialogId("dir-v-rada4", "font_big", "I am fed up to my gills with its nonsense.")
dialogStr("Ne ho fin sopra alle branchie di queste ciance.")


dialogId("dir-hs-uvod0", "font_statue", "It would be easiest if you")
dialogStr("Sarebbe più facile")


dialogId("dir-hs-uvod1", "font_statue", "You would be better off if you")
dialogStr("Per aiutarvi sarebbe meglio")


dialogId("dir-hs-uvod2", "font_statue", "It would help you if you")
dialogStr("Vi sarebbe utile")


dialogId("dir-hs-uvod3", "font_statue", "I have an idea. What if you")
dialogStr("Ho un'idea. Cosa ne direste di")


dialogId("dir-hs-uvod4", "font_statue", "Sorry to interrupt, but what if you")
dialogStr("Spiacente interrompervi, ma perché non")


dialogId("dir-hs-konec0", "font_statue", "demolish some wall.")
dialogStr("demolire qualche muro.")


dialogId("dir-hs-konec1", "font_statue", "break off a few stones from the wall and plug the holes with them.")
dialogStr("rompere qualche pietra dalle pareti e con esse tappare i buchi.")


dialogId("dir-hs-konec2", "font_statue", "plug those holes with something so that that hooked steel wouldn’t get stuck there.")
dialogStr("riempire i buchi con qualcosa acciocché quel pezzo d'acciaio non vi si incastri.")


dialogId("dir-hs-konec3", "font_statue", "smash that pillar by the exit.")
dialogStr("demolire quel pilastro vicino all'uscita.")


dialogId("dir-hs-konec4", "font_statue", "saw off some of that hooked steel.")
dialogStr("segare un po' di quel ferro là incastrato.")


dialogId("dir-hs-konec5", "font_statue", "rearrange the objects so that you can swim out.")
dialogStr("riarrangiare gli oggetti in modo che possiate uscire.")


dialogId("dir-hs-konec6", "font_statue", "solve it somehow and get to the next level.")
dialogStr("risolvere questo problema e passare al sucessivo livello.")


dialogId("dir-hs-konec7", "font_statue", "start to think about it really hard.")
dialogStr("mettervi a ragionare più proficuamente.")


dialogId("dir-hs-konec8", "font_statue", "swim out through that hole on the left.")
dialogStr("nuotare attraverso quel foro sulla sinistra.")

