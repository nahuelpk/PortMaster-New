
dialogId("dir-m-rada0", "font_small", "Stuff yourself with your advice.")
dialogStr("Behalte deine Ratschläge für dich!")


dialogId("dir-m-rada1", "font_small", "We know that very well.")
dialogStr("Das wissen wir auch!")


dialogId("dir-m-rada2", "font_small", "Get lost.")
dialogStr("Hau ab!")


dialogId("dir-m-rada3", "font_small", "My patience is running out.")
dialogStr("Meine Geduld ist bald am Ende.")


dialogId("dir-m-rada4", "font_small", "Arrgh... I’ll smash it to pieces.")
dialogStr("Arrgh... Ich werde ihn in Stücke hauen!")


dialogId("dir-v-rada0", "font_big", "Ignore it, let it talk.")
dialogStr("Ignoriere ihn. Lass ihn reden.")


dialogId("dir-v-rada1", "font_big", "Let us think.")
dialogStr("Lass uns nachdenken.")


dialogId("dir-v-rada2", "font_big", "This was some advice, again.")
dialogStr("Das war ja wieder ein Ratschlag.")


dialogId("dir-v-rada3", "font_big", "It’s a shame I have no ears. I could plug them.")
dialogStr("Schade, dass ich keine Ohren habe. Die könnte ich zuhalten.")


dialogId("dir-v-rada4", "font_big", "I am fed up to my gills with its nonsense.")
dialogStr("Dieser Unsinn steht mir bis zu den Kiemen!")


dialogId("dir-hs-uvod0", "font_statue", "It would be easiest if you")
dialogStr("Am einfachsten wäre es, wenn ihr")


dialogId("dir-hs-uvod1", "font_statue", "You would be better off if you")
dialogStr("Ihr wärt besser dran, wenn ihr")


dialogId("dir-hs-uvod2", "font_statue", "It would help you if you")
dialogStr("Es würde helfen, wenn ihr")


dialogId("dir-hs-uvod3", "font_statue", "I have an idea. What if you")
dialogStr("Ich habe eine Idee. Es wäre gut, wenn ihr")


dialogId("dir-hs-uvod4", "font_statue", "Sorry to interrupt, but what if you")
dialogStr("Entschuldigt wenn ich unterbreche. Es wäre gut, wenn ihr")


dialogId("dir-hs-konec0", "font_statue", "demolish some wall.")
dialogStr("ein paar Mauern niederreißt.")


dialogId("dir-hs-konec1", "font_statue", "break off a few stones from the wall and plug the holes with them.")
dialogStr("ein paar Steine aus der Mauer brecht und die Löcher damit stopft.")


dialogId("dir-hs-konec2", "font_statue", "plug those holes with something so that that hooked steel wouldn’t get stuck there.")
dialogStr("diese Löcher stopft, so dass dieser gebogene Stahl nicht stecken bleibt.")


dialogId("dir-hs-konec3", "font_statue", "smash that pillar by the exit.")
dialogStr("die Säule am Ausgang zertrümmert.")


dialogId("dir-hs-konec4", "font_statue", "saw off some of that hooked steel.")
dialogStr("etwas von dem gebogenen Stahl absägt.")


dialogId("dir-hs-konec5", "font_statue", "rearrange the objects so that you can swim out.")
dialogStr("die Gegenstände so umordnet, dass ihr rausschwimmen könnt.")


dialogId("dir-hs-konec6", "font_statue", "solve it somehow and get to the next level.")
dialogStr("es irgendwie löst und in die nächste Ebene kommt.")


dialogId("dir-hs-konec7", "font_statue", "start to think about it really hard.")
dialogStr("anfangt, intensiv über eine Lösung nachzudenken.")


dialogId("dir-hs-konec8", "font_statue", "swim out through that hole on the left.")
dialogStr("durch das Loch auf der linken Seite schwimmt.")

