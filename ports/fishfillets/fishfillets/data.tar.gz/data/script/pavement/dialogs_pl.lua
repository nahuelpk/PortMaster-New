
dialogId("dir-m-rada0", "font_small", "Stuff yourself with your advice.")
dialogStr("Wypchaj się swoimi radami.")


dialogId("dir-m-rada1", "font_small", "We know that very well.")
dialogStr("Doskonale o tym wiemy.")


dialogId("dir-m-rada2", "font_small", "Get lost.")
dialogStr("Zmiataj.")


dialogId("dir-m-rada3", "font_small", "My patience is running out.")
dialogStr("Moja cierpliwość się powoli kończy.")


dialogId("dir-m-rada4", "font_small", "Arrgh... I’ll smash it to pieces.")
dialogStr("Grrr... rozniosę go na drobny pył.")


dialogId("dir-v-rada0", "font_big", "Ignore it, let it talk.")
dialogStr("Nie zwracaj na niego uwagi.")


dialogId("dir-v-rada1", "font_big", "Let us think.")
dialogStr("Daj nam pomyśleć!")


dialogId("dir-v-rada2", "font_big", "This was some advice, again.")
dialogStr("To nam poradziłeś.")


dialogId("dir-v-rada3", "font_big", "It’s a shame I have no ears. I could plug them.")
dialogStr("Jaka szkoda, że nie mam uszu. Zatkałbym je sobie.")


dialogId("dir-v-rada4", "font_big", "I am fed up to my gills with its nonsense.")
dialogStr("Mam już po skrzela tych bzdur.")


dialogId("dir-hs-uvod0", "font_statue", "It would be easiest if you")
dialogStr("Czy nie najprościej by było, gdybyście")


dialogId("dir-hs-uvod1", "font_statue", "You would be better off if you")
dialogStr("Nie pomogłoby wam, gdybyście")


dialogId("dir-hs-uvod2", "font_statue", "It would help you if you")
dialogStr("Nie byłoby lepiej, gdybyście")


dialogId("dir-hs-uvod3", "font_statue", "I have an idea. What if you")
dialogStr("Mam pomysł. Może byście")


dialogId("dir-hs-uvod4", "font_statue", "Sorry to interrupt, but what if you")
dialogStr("Przepraszam, że przeszkadzam, ale gdybyście tak")


dialogId("dir-hs-konec0", "font_statue", "demolish some wall.")
dialogStr("wyburzyli jakąś ścianę?")


dialogId("dir-hs-konec1", "font_statue", "break off a few stones from the wall and plug the holes with them.")
dialogStr("wyłamali z muru kilka cegieł i zapchali nimi dziury?")


dialogId("dir-hs-konec2", "font_statue", "plug those holes with something so that that hooked steel wouldn’t get stuck there.")
dialogStr("załatali czymś te dziury, coby ta rura wam w nie nie wpadła?")


dialogId("dir-hs-konec3", "font_statue", "smash that pillar by the exit.")
dialogStr("rozbili tę kolumnę koło wyjścia?")


dialogId("dir-hs-konec4", "font_statue", "saw off some of that hooked steel.")
dialogStr("odpiłowali kawałek tej zakrzywionej rury?")


dialogId("dir-hs-konec5", "font_statue", "rearrange the objects so that you can swim out.")
dialogStr("poprzestawiali to wszystko jakoś tak, żebyście mogli wypłynąć?")


dialogId("dir-hs-konec6", "font_statue", "solve it somehow and get to the next level.")
dialogStr("rozwiązali to jakoś i dostali się do następnego pomieszczenia?")


dialogId("dir-hs-konec7", "font_statue", "start to think about it really hard.")
dialogStr("zaczęli intensywnie myśleć nad rozwiązaniem?")


dialogId("dir-hs-konec8", "font_statue", "swim out through that hole on the left.")
dialogStr("wypłynęli tą dziurą po lewej?")

