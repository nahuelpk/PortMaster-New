dialogId("dir-m-rada0", "font_small", "Stuff yourself with your advice.")
dialogStr("Задръж си съвета.")

dialogId("dir-m-rada1", "font_small", "We know that very well.")
dialogStr("Това си го знаем много добре.")

dialogId("dir-m-rada2", "font_small", "Get lost.")
dialogStr("Изчезвай.")

dialogId("dir-m-rada3", "font_small", "My patience is running out.")
dialogStr("Търпението ми се изчерпва.")

dialogId("dir-m-rada4", "font_small", "Arrgh... I’ll smash it to pieces.")
dialogStr("Арргх... Ще го натроша на парчета.")

dialogId("dir-v-rada0", "font_big", "Ignore it, let it talk.")
dialogStr("Остави го, нека си говори.")

dialogId("dir-v-rada1", "font_big", "Let us think.")
dialogStr("Да помислим.")

dialogId("dir-v-rada2", "font_big", "This was some advice, again.")
dialogStr("Посъветваха ни. Отново.")

dialogId("dir-v-rada3", "font_big", "It’s a shame I have no ears. I could plug them.")
dialogStr("Срамота е, че нямам уши. Можех да ги запуша.")

dialogId("dir-v-rada4", "font_big", "I am fed up to my gills with its nonsense.")
dialogStr("Задръстих се до хрилете с тези безсмислици.")

dialogId("dir-hs-uvod0", "font_statue", "It would be easiest if you")
dialogStr("Най-лесно би било ако...")

dialogId("dir-hs-uvod1", "font_statue", "You would be better off if you")
dialogStr("По-добре ще е ако...")

dialogId("dir-hs-uvod2", "font_statue", "It would help you if you")
dialogStr("Би ви помогнало ако...")

dialogId("dir-hs-uvod3", "font_statue", "I have an idea. What if you")
dialogStr("Имам идея. Ами ако...")

dialogId("dir-hs-uvod4", "font_statue", "Sorry to interrupt, but what if you")
dialogStr("Извинете, че ви прекъсвам, но какво ще стане ако...")

dialogId("dir-hs-konec0", "font_statue", "demolish some wall.")
dialogStr("... съборите някоя стена.")

dialogId("dir-hs-konec1", "font_statue", "break off a few stones from the wall and plug the holes with them.")
dialogStr("... извадите няколко камъка от стените и запълните дупките с тях.")

dialogId("dir-hs-konec2", "font_statue", "plug those holes with something so that that hooked steel wouldn’t get stuck there.")
dialogStr("... запълните дупките с нещо, за да не се закача стоманената тръба.")

dialogId("dir-hs-konec3", "font_statue", "smash that pillar by the exit.")
dialogStr("... разбиете колоната до изхода.")

dialogId("dir-hs-konec4", "font_statue", "saw off some of that hooked steel.")
dialogStr("... разрежете с ножовка стоманените тръби.")

dialogId("dir-hs-konec5", "font_statue", "rearrange the objects so that you can swim out.")
dialogStr(".. разместите обектите така, че да можете да излезете.")

dialogId("dir-hs-konec6", "font_statue", "solve it somehow and get to the next level.")
dialogStr("... намерите някакво решение и стигнете до следващото ниво.")

dialogId("dir-hs-konec7", "font_statue", "start to think about it really hard.")
dialogStr("... помислите наистина сериозно.")

dialogId("dir-hs-konec8", "font_statue", "swim out through that hole on the left.")
dialogStr("... изплувате през онази дупка отляво.")

dialogId("k1-chob-1", "", "")
dialogStr("")

dialogId("k1-chob-2", "", "")
dialogStr("")

dialogId("k1-chob-3", "", "")
dialogStr("")

dialogId("k1-chob-p", "", "")
dialogStr("")

dialogId("k1-x-vrz", "", "")
dialogStr("")

