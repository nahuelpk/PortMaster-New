
dialogId("dir-m-rada0", "font_small", "Stuff yourself with your advice.")

dialogId("dir-m-rada1", "font_small", "We know that very well.")

dialogId("dir-m-rada2", "font_small", "Get lost.")

dialogId("dir-m-rada3", "font_small", "My patience is running out.")

dialogId("dir-m-rada4", "font_small", "Arrgh... I’ll smash it to pieces.")

dialogId("dir-v-rada0", "font_big", "Ignore it, let it talk.")

dialogId("dir-v-rada1", "font_big", "Let us think.")

dialogId("dir-v-rada2", "font_big", "This was some advice, again.")

dialogId("dir-v-rada3", "font_big", "It’s a shame I have no ears. I could plug them.")

dialogId("dir-v-rada4", "font_big", "I am fed up to my gills with its nonsense.")

dialogId("dir-hs-uvod0", "font_statue", "It would be easiest if you")

dialogId("dir-hs-uvod1", "font_statue", "You would be better off if you")

dialogId("dir-hs-uvod2", "font_statue", "It would help you if you")

dialogId("dir-hs-uvod3", "font_statue", "I have an idea. What if you")

dialogId("dir-hs-uvod4", "font_statue", "Sorry to interrupt, but what if you")

dialogId("dir-hs-konec0", "font_statue", "demolish some wall.")

dialogId("dir-hs-konec1", "font_statue", "break off a few stones from the wall and plug the holes with them.")

dialogId("dir-hs-konec2", "font_statue", "plug those holes with something so that that hooked steel wouldn’t get stuck there.")

dialogId("dir-hs-konec3", "font_statue", "smash that pillar by the exit.")

dialogId("dir-hs-konec4", "font_statue", "saw off some of that hooked steel.")

dialogId("dir-hs-konec5", "font_statue", "rearrange the objects so that you can swim out.")

dialogId("dir-hs-konec6", "font_statue", "solve it somehow and get to the next level.")

dialogId("dir-hs-konec7", "font_statue", "start to think about it really hard.")

dialogId("dir-hs-konec8", "font_statue", "swim out through that hole on the left.")

dialogId("k1-chob-1", "", "")

dialogId("k1-chob-2", "", "")

dialogId("k1-chob-3", "", "")

dialogId("k1-chob-p", "", "")

dialogId("k1-x-vrz", "", "")
