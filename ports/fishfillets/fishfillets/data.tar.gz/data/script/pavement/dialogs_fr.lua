
dialogId("dir-m-rada0", "font_small", "Stuff yourself with your advice.")
dialogStr("Tu peux te mettre tes conseils...")


dialogId("dir-m-rada1", "font_small", "We know that very well.")
dialogStr("Nous le savons parfaitement.")


dialogId("dir-m-rada2", "font_small", "Get lost.")
dialogStr("Oublie moi.")


dialogId("dir-m-rada3", "font_small", "My patience is running out.")
dialogStr("Ma patience est à bout.")


dialogId("dir-m-rada4", "font_small", "Arrgh... I’ll smash it to pieces.")
dialogStr("Arrgh... Je vais le casser en petits morceaux.")


dialogId("dir-v-rada0", "font_big", "Ignore it, let it talk.")
dialogStr("Ignore-le, laisse-le causer.")


dialogId("dir-v-rada1", "font_big", "Let us think.")
dialogStr("Réfléchissons.")


dialogId("dir-v-rada2", "font_big", "This was some advice, again.")
dialogStr("Ce doit être quelque indice, à nouveau.")


dialogId("dir-v-rada3", "font_big", "It’s a shame I have no ears. I could plug them.")
dialogStr("Dommage que je n'aie pas d'oreilles. Je pourrais les boucher.")


dialogId("dir-v-rada4", "font_big", "I am fed up to my gills with its nonsense.")
dialogStr("J'y perds mes branchies avec ces absurdités.")


dialogId("dir-hs-uvod0", "font_statue", "It would be easiest if you")
dialogStr("Ça serait plus facile si vous...")


dialogId("dir-hs-uvod1", "font_statue", "You would be better off if you")
dialogStr("Ce serait mieux si vous...")


dialogId("dir-hs-uvod2", "font_statue", "It would help you if you")
dialogStr("Ça vous aiderait si vous...")


dialogId("dir-hs-uvod3", "font_statue", "I have an idea. What if you")
dialogStr("J'ai une idée. Si vous...")


dialogId("dir-hs-uvod4", "font_statue", "Sorry to interrupt, but what if you")
dialogStr("Désolé d'interrompre, mais si vous...")


dialogId("dir-hs-konec0", "font_statue", "demolish some wall.")
dialogStr("Détruisez un mur.")


dialogId("dir-hs-konec1", "font_statue", "break off a few stones from the wall and plug the holes with them.")
dialogStr("Enlevez quelques pierres du mur et bouchez les trous avec.")


dialogId("dir-hs-konec2", "font_statue", "plug those holes with something so that that hooked steel wouldn’t get stuck there.")
dialogStr("Bouchez ces trous avec quelque chose, ainsi cet hameçon ne s'y coincera plus.")


dialogId("dir-hs-konec3", "font_statue", "smash that pillar by the exit.")
dialogStr("Jette ce pilier par la sortie.")


dialogId("dir-hs-konec4", "font_statue", "saw off some of that hooked steel.")
dialogStr("Faites attention aux clous.")


dialogId("dir-hs-konec5", "font_statue", "rearrange the objects so that you can swim out.")
dialogStr("Réarrangez les objets ainsi vous pourrez nager hors du tableau.")


dialogId("dir-hs-konec6", "font_statue", "solve it somehow and get to the next level.")
dialogStr("Trouvez la solution et allez au niveau suivant.")


dialogId("dir-hs-konec7", "font_statue", "start to think about it really hard.")
dialogStr("Commencez à réfléchir plus sérieusement.")


dialogId("dir-hs-konec8", "font_statue", "swim out through that hole on the left.")
dialogStr("Nagez à travers ce trou, sur la gauche.")

