
dialogId("dir-hs-konec0", "font_statue", "demolish some wall.")
dialogStr("ein paar Mauern niederreisst.")

