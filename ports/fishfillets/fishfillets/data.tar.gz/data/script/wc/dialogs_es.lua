
dialogId("wc-v-oblibene", "font_big", "The toilet is David’s favorite place.")
dialogStr("El baño es el lugar favorito de David.")


dialogId("wc-m-coze", "font_small", "What?")
dialogStr("¿Qué?")


dialogId("wc-v-neznas", "font_big", "You don’t know David? It’s one of the artists who worked on this game.")
dialogStr("¿No conoces a David? Es uno de los artistas que trabajaron en este juego.")


dialogId("wc-m-sochar", "font_small", "David was no graphic artist. He was a sculpturer. His sculptures are one of the best-known Renaissance artifacts.")
dialogStr("David no era un artista gráfico. El era escultor. Sus esculturas son uno de los mejores artefactos conocidos del Renacimiento.")


dialogId("wc-v-zmatek", "font_big", "You’ve got it all wrong.")
dialogStr("Entendiste todo mal.")


dialogId("wc-m-prasecinky", "font_small", "Didn’t I tell you, that WE don’t need a flushing toilet? And decorated with your smut, too!")
dialogStr("¿No te dije que, NOSOTROS no necesitamos un retrete? ¡Y decorado con tu suciedad tampoco!")


dialogId("wc-v-hygiena", "font_big", "The flushing toilet is more hygienic and when under water even more ecological.")
dialogStr("El retrete es más higiénico y cuando está bajo el agua incluso más ecológico.")


dialogId("wc-m-vlezt", "font_small", "Luckily, I needn’t climb inside.")
dialogStr("Por suerte, no necesito trepar hacia adentro.")


dialogId("wc-m-hrbitov", "font_small", "I don’t feel very well here. I feel like I’m in the cemetery.")
dialogStr("No me siento muy bien aquí. Me siento como si estuviera en el cementerio.")


dialogId("wc-v-coze", "font_big", "What do you mean?")
dialogStr("¿Qué quieres decir?")


dialogId("wc-m-nevis", "font_small", "Don’t you know where so many aquarium fish end their life?")
dialogStr("¿No sabes donde terminan su vida tantos peces de acuario?")

