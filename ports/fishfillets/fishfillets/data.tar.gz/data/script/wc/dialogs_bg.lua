dialogId("wc-v-oblibene", "font_big", "The toilet is David’s favorite place.")
dialogStr("Тоалетната е любимото място на Давид.")

dialogId("wc-m-coze", "font_small", "What?")
dialogStr("Какво?")

dialogId("wc-v-neznas", "font_big", "You don’t know David? It’s one of the artists who worked on this game.")
dialogStr("Не познаваш Давид? Той е един от художниците, работили по тази игра.")

dialogId("wc-m-sochar", "font_small", "David was no graphic artist. He was a sculpturer. His sculptures are one of the best-known Renaissance artifacts.")
dialogStr("Давид не е художник. Бил е скулптор. Скулптурите му са едни от най-известните Ренесансови паметници.")

dialogId("wc-v-zmatek", "font_big", "You’ve got it all wrong.")
dialogStr("Съвсем си се объркала.")

dialogId("wc-m-prasecinky", "font_small", "Didn’t I tell you, that WE don’t need a flushing toilet? And decorated with your smut, too!")
dialogStr("Не ти ли казвах, че на НАС не ни трябва тоалетна чиния? Че и украсена с твоите неприлични писания!")

dialogId("wc-v-hygiena", "font_big", "The flushing toilet is more hygienic and when under water even more ecological.")
dialogStr("Тоалетната чиния е по-хигиенична. А когато е под водата е и по-екологична.")

dialogId("wc-m-vlezt", "font_small", "Luckily, I needn’t climb inside.")
dialogStr("За щастие не се налага да скачам вътре.")

dialogId("wc-m-hrbitov", "font_small", "I don’t feel very well here. I feel like I’m in the cemetery.")
dialogStr("Не ми е добре тук. Чувствам се като в гробище.")

dialogId("wc-v-coze", "font_big", "What do you mean?")
dialogStr("В смисъл?")

dialogId("wc-m-nevis", "font_small", "Don’t you know where so many aquarium fish end their life?")
dialogStr("Не знаеш ли къде приключват житейския си път повечето аквариумни рибки?")

