
dialogId("wc-v-oblibene", "font_big", "The toilet is David’s favorite place.")
dialogStr("Les toilettes est le lieu préféré de David.")


dialogId("wc-m-coze", "font_small", "What?")
dialogStr("Pardon ?")


dialogId("wc-v-neznas", "font_big", "You don’t know David? It’s one of the artists who worked on this game.")
dialogStr("Tu ne connais pas David ? Il est l'un des artistes qui a travaillé sur ce jeu.")


dialogId("wc-m-sochar", "font_small", "David was no graphic artist. He was a sculpturer. His sculptures are one of the best-known Renaissance artifacts.")
dialogStr("David n'était pas dessinateur. Il était sculpteur. Ses sculptures sont parmi les plus réputées de la Renaissance.")


dialogId("wc-v-zmatek", "font_big", "You’ve got it all wrong.")
dialogStr("Tu as tout faux.")


dialogId("wc-m-prasecinky", "font_small", "Didn’t I tell you, that WE don’t need a flushing toilet? And decorated with your smut, too!")
dialogStr("Ne t'avais-je pas dis que NOUS n'avons pas besoin de chasse d'eau ? Et décoré avec tes mochetés, en plus !")


dialogId("wc-v-hygiena", "font_big", "The flushing toilet is more hygienic and when under water even more ecological.")
dialogStr("La chasse d'eau est plus hygiénique et sous l'eau même plus écologique.")


dialogId("wc-m-vlezt", "font_small", "Luckily, I needn’t climb inside.")
dialogStr("Heureusement, je ne dois pas grimper dedans.")


dialogId("wc-m-hrbitov", "font_small", "I don’t feel very well here. I feel like I’m in the cemetery.")
dialogStr("Je ne me sens pas très bien ici. Je me sens comme au cimetière.")


dialogId("wc-v-coze", "font_big", "What do you mean?")
dialogStr("Que veux-tu dire ?")


dialogId("wc-m-nevis", "font_small", "Don’t you know where so many aquarium fish end their life?")
dialogStr("Ne sais-tu pas ou tant de poissons d'aquarium finissent leur vie ?")

