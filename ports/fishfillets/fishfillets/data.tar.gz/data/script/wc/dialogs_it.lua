
dialogId("wc-v-oblibene", "font_big", "The toilet is David’s favorite place.")
dialogStr("La toilette è la stanza preferita da David.")


dialogId("wc-m-coze", "font_small", "What?")
dialogStr("Che?")


dialogId("wc-v-neznas", "font_big", "You don’t know David? It’s one of the artists who worked on this game.")
dialogStr("Non conosci David? E’ uno dei grafici che ha lavorato a questo gioco.")


dialogId("wc-m-sochar", "font_small", "David was no graphic artist. He was a sculpturer. His sculptures are one of the best-known Renaissance artifacts.")
dialogStr("David non era un grafico. Era uno scultore. Le sue sculture sono tra le più note opere rinascimentali.")


dialogId("wc-v-zmatek", "font_big", "You’ve got it all wrong.")
dialogStr("Non hai capito niente.")


dialogId("wc-m-prasecinky", "font_small", "Didn’t I tell you, that WE don’t need a flushing toilet? And decorated with your smut, too!")
dialogStr("Non ti avevo detto che NON ci serve un bagno con lo sciacquone? Perdipiù decorato con le tue macchie!")


dialogId("wc-v-hygiena", "font_big", "The flushing toilet is more hygienic and when under water even more ecological.")
dialogStr("Lo sciacquone è più igienico e, sott'acqua, anche più ecologico.")


dialogId("wc-m-vlezt", "font_small", "Luckily, I needn’t climb inside.")
dialogStr("Per fortuna, non devo arrampicarmici dentro.")


dialogId("wc-m-hrbitov", "font_small", "I don’t feel very well here. I feel like I’m in the cemetery.")
dialogStr("Non mi sento tanto bene qui. Mi sembra di stare al cimitero.")


dialogId("wc-v-coze", "font_big", "What do you mean?")
dialogStr("Cosa intendi?")


dialogId("wc-m-nevis", "font_small", "Don’t you know where so many aquarium fish end their life?")
dialogStr("Non lo sai in che modo tanti pesci di acquario terminano la loro esistenza?")

