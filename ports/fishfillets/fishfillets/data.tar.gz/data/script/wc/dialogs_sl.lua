
dialogId("wc-v-oblibene", "font_big", "The toilet is David’s favorite place.")
dialogStr("Najljubši Davidov prostor je stranišče.")

dialogId("wc-m-coze", "font_small", "What?")
dialogStr("Kaj?")

dialogId("wc-v-neznas", "font_big", "You don’t know David? It’s one of the artists who worked on this game.")
dialogStr("Ne poznaš Davida? On je eden od mojstrov, ki so izdelovali to igro.")

dialogId("wc-m-sochar", "font_small", "David was no graphic artist. He was a sculpturer. His sculptures are one of the best-known Renaissance artifacts.")
dialogStr("David ni bil slikar. Bil je kipar. Njegovo kiparstvo je eno od najbolj znanih renesančnih artefaktov.")

dialogId("wc-v-zmatek", "font_big", "You’ve got it all wrong.")
dialogStr("Vse si narobe razumela.")

dialogId("wc-m-prasecinky", "font_small", "Didn’t I tell you, that WE don’t need a flushing toilet? And decorated with your smut, too!")
dialogStr("Ali ti nisem povedala da MIDVA ne potrebujema, stranišča na izplakovanje? Tudi ni potrebno da je okrašeno s tvojimi sajami!")

dialogId("wc-v-hygiena", "font_big", "The flushing toilet is more hygienic and when under water even more ecological.")
dialogStr("Stranišče na izplakovanje je dosti bolj higienično in kadar je pod vodo tudi bolj ekološko.")

dialogId("wc-m-vlezt", "font_small", "Luckily, I needn’t climb inside.")
dialogStr("Na srečo mi ni treba splezati noter.")

dialogId("wc-m-hrbitov", "font_small", "I don’t feel very well here. I feel like I’m in the cemetery.")
dialogStr("Ne počutim se prav dobro tukaj. Občutek imam, kot da sem na pokopališču.")

dialogId("wc-v-coze", "font_big", "What do you mean?")
dialogStr("Kaj misliš s tem?")

dialogId("wc-m-nevis", "font_small", "Don’t you know where so many aquarium fish end their life?")
dialogStr("Ali ne veš, kje toliko akvarijskih rib konča svoje življenje?")
