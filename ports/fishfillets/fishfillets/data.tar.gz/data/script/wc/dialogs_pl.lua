
dialogId("wc-v-oblibene", "font_big", "The toilet is David’s favorite place.")
dialogStr("WC jest ulubionym miejscem Dawida..")


dialogId("wc-m-coze", "font_small", "What?")
dialogStr("Że jak?")


dialogId("wc-v-neznas", "font_big", "You don’t know David? It’s one of the artists who worked on this game.")
dialogStr("Nie znasz Dawida? To grafik, który pracowaĸł nad tą grą!")


dialogId("wc-m-sochar", "font_small", "David was no graphic artist. He was a sculpturer. His sculptures are one of the best-known Renaissance artifacts.")
dialogStr("Dawid nie był żadnym grafikiem, tylko rzeźbiarzem. Jego rzeźby są najbardziej znanymi zabytkami renesansu.")


dialogId("wc-v-zmatek", "font_big", "You’ve got it all wrong.")
dialogStr("Wszystko pomieszałaś.")


dialogId("wc-m-prasecinky", "font_small", "Didn’t I tell you, that WE don’t need a flushing toilet? And decorated with your smut, too!")
dialogStr("Mówiłam ci przecież, że nie potrzebujemy klozetu... i jeszcze te twoje sprośne plakaty.")


dialogId("wc-v-hygiena", "font_big", "The flushing toilet is more hygienic and when under water even more ecological.")
dialogStr("Toaleta ze spłuczką jest bardziej higieniczna, a pod wodą również bardziej ekologiczna.")


dialogId("wc-m-vlezt", "font_small", "Luckily, I needn’t climb inside.")
dialogStr("Dobrze, że przynajmniej nie musiałam wpływać do środka.")


dialogId("wc-m-hrbitov", "font_small", "I don’t feel very well here. I feel like I’m in the cemetery.")
dialogStr("Czuję się, jakbym była na cmentarzu.")


dialogId("wc-v-coze", "font_big", "What do you mean?")
dialogStr("Jak to?")


dialogId("wc-m-nevis", "font_small", "Don’t you know where so many aquarium fish end their life?")
dialogStr("Nie wiesz, gdzie kończy swój żywot większość rybek akwariowych?")

