
dialogId("wc-m-nevis", "font_small", "Don’t you know where so many aquarium fish end their life?")
dialogStr("Weisst du nicht, wo so viele Aquariumfische ihr Leben lassen?")

