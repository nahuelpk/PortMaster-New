
dialogId("wc-v-oblibene", "font_big", "The toilet is David’s favorite place.")
dialogStr("Toaletten är Davids favorit ställe.")


dialogId("wc-m-coze", "font_small", "What?")
dialogStr("Va?")


dialogId("wc-v-neznas", "font_big", "You don’t know David? It’s one of the artists who worked on this game.")
dialogStr("Du känner inte David? Han är en av konstnärerna som gjorde det här spelet.")


dialogId("wc-m-sochar", "font_small", "David was no graphic artist. He was a sculpturer. His sculptures are one of the best-known Renaissance artifacts.")
dialogStr("David var ingen grafisk konstnär. Han var skulptör. Hans skulpturer är bland de mest kända från renässansen.")


dialogId("wc-v-zmatek", "font_big", "You’ve got it all wrong.")
dialogStr("Du har missförstått det hela.")


dialogId("wc-m-prasecinky", "font_small", "Didn’t I tell you, that WE don’t need a flushing toilet? And decorated with your smut, too!")
dialogStr("Sade jag inte till dig att VI inte behöver en spolande toalett? Och dekorerad med dina ekivoka bilder, också!")


dialogId("wc-v-hygiena", "font_big", "The flushing toilet is more hygienic and when under water even more ecological.")
dialogStr("En spolande toalett är mera hygienisk och när den är under vatten är den även mera ekologisk.")


dialogId("wc-m-vlezt", "font_small", "Luckily, I needn’t climb inside.")
dialogStr("Som tur var behövde jag inte klättra inuti.")


dialogId("wc-m-hrbitov", "font_small", "I don’t feel very well here. I feel like I’m in the cemetery.")
dialogStr("Det känns inte så kul. Det känns som om jag är på en kyrkogård.")


dialogId("wc-v-coze", "font_big", "What do you mean?")
dialogStr("Vad menar du?")


dialogId("wc-m-nevis", "font_small", "Don’t you know where so many aquarium fish end their life?")
dialogStr("Vet du inte var många akvariefiskar slutar sina liv?")

