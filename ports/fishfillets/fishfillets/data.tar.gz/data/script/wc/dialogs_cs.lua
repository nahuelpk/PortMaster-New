
dialogId("wc-v-oblibene", "font_big", "The toilet is David’s favorite place.")
dialogStr("WC je oblíbeným Davidovým místem.")


dialogId("wc-m-coze", "font_small", "What?")
dialogStr("Cože?")


dialogId("wc-v-neznas", "font_big", "You don’t know David? It’s one of the artists who worked on this game.")
dialogStr("Ty neznáš Davida? To je grafik, který na téhle hře pracoval!")


dialogId("wc-m-sochar", "font_small", "David was no graphic artist. He was a sculpturer. His sculptures are one of the best-known Renaissance artifacts.")
dialogStr("David nebyl žádný malíř. David byl sochař. Davidova socha je jednou z nejznámějších renesančních památek.")


dialogId("wc-v-zmatek", "font_big", "You’ve got it all wrong.")
dialogStr("Máš v tom nějaký zmatek.")


dialogId("wc-m-prasecinky", "font_small", "Didn’t I tell you, that WE don’t need a flushing toilet? And decorated with your smut, too!")
dialogStr("Já jsem ti říkala, že zrovna my splachovací záchod nepotřebujeme. A ještě tu visí ty tvoje prasečinky.")


dialogId("wc-v-hygiena", "font_big", "The flushing toilet is more hygienic and when under water even more ecological.")
dialogStr("Splachovací záchod je hygieničtější a pod vodou i ekologičtější.")


dialogId("wc-m-vlezt", "font_small", "Luckily, I needn’t climb inside.")
dialogStr("Ještě, že nemusím vlézt přímo do mísy.")


dialogId("wc-m-hrbitov", "font_small", "I don’t feel very well here. I feel like I’m in the cemetery.")
dialogStr("Necítím se tady dobře. Připadám si jako na hřbitově.")


dialogId("wc-v-coze", "font_big", "What do you mean?")
dialogStr("Cože?")


dialogId("wc-m-nevis", "font_small", "Don’t you know where so many aquarium fish end their life?")
dialogStr("Copak nevíš, kde končí svůj život spousta akvarijních rybiček?")

