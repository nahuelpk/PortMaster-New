
dialogId("wc-v-oblibene", "font_big", "The toilet is David’s favorite place.")
dialogStr("Die Toilette ist Davids Lieblingsplatz.")


dialogId("wc-m-coze", "font_small", "What?")
dialogStr("Wie bitte?")


dialogId("wc-v-neznas", "font_big", "You don’t know David? It’s one of the artists who worked on this game.")
dialogStr("Du kennst David nicht? Er ist einer der Künstler, der an diesem Spiel gearbeitet hat.")


dialogId("wc-m-sochar", "font_small", "David was no graphic artist. He was a sculpturer. His sculptures are one of the best-known Renaissance artifacts.")
dialogStr("David war kein Grafiker. Er war Bildhauer. Seine Plastiken gehören zu den bekanntesten Gegenständen der Renaissance.")


dialogId("wc-v-zmatek", "font_big", "You’ve got it all wrong.")
dialogStr("Du hast alles falsch verstanden.")


dialogId("wc-m-prasecinky", "font_small", "Didn’t I tell you, that WE don’t need a flushing toilet? And decorated with your smut, too!")
dialogStr("Habe ich dir nicht gesagt, dass WIR keine Toilette mit Wasserspülung brauchen?")


dialogId("wc-v-hygiena", "font_big", "The flushing toilet is more hygienic and when under water even more ecological.")
dialogStr("Eine Wasserspülung ist hygienischer und unter Wasser auch umweltfreundlicher.")


dialogId("wc-m-vlezt", "font_small", "Luckily, I needn’t climb inside.")
dialogStr("Zum Glück muss ich nicht reinklettern.")


dialogId("wc-m-hrbitov", "font_small", "I don’t feel very well here. I feel like I’m in the cemetery.")
dialogStr("Ich fühle mich hier nicht gut. Ist wie auf dem Friedhof.")


dialogId("wc-v-coze", "font_big", "What do you mean?")
dialogStr("Was meinst du damit?")


dialogId("wc-m-nevis", "font_small", "Don’t you know where so many aquarium fish end their life?")
dialogStr("Weißt du nicht, wo so viele Aquariumfische ihr Leben lassen?")

