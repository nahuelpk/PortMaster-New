
dialogId("wc-v-oblibene", "font_big", "The toilet is David’s favorite place.")
dialogStr("De WC is de lievelingsplek van David.")


dialogId("wc-m-coze", "font_small", "What?")
dialogStr("Wat?")


dialogId("wc-v-neznas", "font_big", "You don’t know David? It’s one of the artists who worked on this game.")
dialogStr("Ken je David niet? Hij is een van de kunstenaars die dit spel gemaakt hebben.")


dialogId("wc-m-sochar", "font_small", "David was no graphic artist. He was a sculpturer. His sculptures are one of the best-known Renaissance artifacts.")
dialogStr("David was een tekenaar. Hij was een beelhouwer. Zijn beelden behoren tot de bekendste voorwerpen uit de Renaissance.")


dialogId("wc-v-zmatek", "font_big", "You’ve got it all wrong.")
dialogStr("Je begrijpt er niks van.")


dialogId("wc-m-prasecinky", "font_small", "Didn’t I tell you, that WE don’t need a flushing toilet? And decorated with your smut, too!")
dialogStr("Heb ik je niet geprobeerd duidelijk te maken dat WIJ geen wc met spoelbak nodig hebben? En met jouw rommel erin ook nog!")


dialogId("wc-v-hygiena", "font_big", "The flushing toilet is more hygienic and when under water even more ecological.")
dialogStr("Een spoelbak is hygiënischer en onderwater ook milieuvriendelijker.")


dialogId("wc-m-vlezt", "font_small", "Luckily, I needn’t climb inside.")
dialogStr("Gelukkig hoef ik er niet in te zwemmen.")


dialogId("wc-m-hrbitov", "font_small", "I don’t feel very well here. I feel like I’m in the cemetery.")
dialogStr("Ik voel me hier niet op m'n gemak. Het voelt als een kerkhof.")


dialogId("wc-v-coze", "font_big", "What do you mean?")
dialogStr("Hoe bedoel je?")


dialogId("wc-m-nevis", "font_small", "Don’t you know where so many aquarium fish end their life?")
dialogStr("Weet je niet waar veel aquariumvissen uiteindelijk terechtkomen?")

