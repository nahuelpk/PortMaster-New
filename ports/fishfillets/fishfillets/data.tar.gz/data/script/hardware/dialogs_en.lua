
dialogId("pz-v-zaskladanej", "font_big", "I’m completely blocked in here.")

dialogId("pz-m-co", "font_small", "What are you doing up there?")

dialogId("pz-v-klice1", "font_big", "These must be some hardware keys.")

dialogId("pz-v-klice2", "font_big", "There are many hardware keys here.")

dialogId("pz-v-co1", "font_big", "What do you have down there?")

dialogId("pz-v-co2", "font_big", "What’s down there?")

dialogId("pz-m-spoje1", "font_small", "There are some printed circuits here.")

dialogId("pz-m-spoje2", "font_small", "There are some integrated circuits here.")

dialogId("pz-m-spoje3", "font_small", "I am surrounded by electronics here.")

dialogId("pz-m-pocitace", "font_small", "Computers. They’ve always fascinated me. But now I’m sick of them.")

dialogId("pz-x-pocitac", "font_white", "Fish. I’ve always hated them. And now my circuits are overloaded with them.")

dialogId("pz-v-hej", "font_big", "Hey, how are you? It’s quite boring here.")

dialogId("pz-m-nech", "font_small", "Can it, will you?")

dialogId("pz-m-vylez", "font_small", "Get out!")

dialogId("pz-v-dat", "font_big", "We have to put these keys somewhere.")

dialogId("pz-m-nepasuje", "font_small", "It doesn’t seem to fit.")
