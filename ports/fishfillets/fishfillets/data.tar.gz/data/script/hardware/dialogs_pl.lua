
dialogId("pz-v-zaskladanej", "font_big", "I’m completely blocked in here.")
dialogStr("Jestem tu kompletnie zablokowany.")


dialogId("pz-m-co", "font_small", "What are you doing up there?")
dialogStr("Co masz tam na górze?")


dialogId("pz-v-klice1", "font_big", "These must be some hardware keys.")
dialogStr("To pewnie jakieś klucze hardware'owe.")


dialogId("pz-v-klice2", "font_big", "There are many hardware keys here.")
dialogStr("Sporo tu hardware'owych kluczy.")


dialogId("pz-v-co1", "font_big", "What do you have down there?")
dialogStr("A co tam masz na dole?")


dialogId("pz-v-co2", "font_big", "What’s down there?")
dialogStr("A tam na dole co jest?")


dialogId("pz-m-spoje1", "font_small", "There are some printed circuits here.")
dialogStr("Jakieś płytki drukowane.")


dialogId("pz-m-spoje2", "font_small", "There are some integrated circuits here.")
dialogStr("Jakieś zintegrowane obwody.")


dialogId("pz-m-spoje3", "font_small", "I am surrounded by electronics here.")
dialogStr("Jestem otoczona elektroniką...")


dialogId("pz-m-pocitace", "font_small", "Computers. They’ve always fascinated me. But now I’m sick of them.")
dialogStr("Komputery. Zawsze mnie fascynowały. Ale teraz mam ich już dość.")


dialogId("pz-x-pocitac", "font_white", "Fish. I’ve always hated them. And now my circuits are overloaded with them.")
dialogStr("Ryby. Zawsze ich nienawidziłem. A teraz moje obwody są ich pełne.")


dialogId("pz-v-hej", "font_big", "Hey, how are you? It’s quite boring here.")
dialogStr("Hej, jak tam na dole? Tu jest strasznie nudno.")


dialogId("pz-m-nech", "font_small", "Can it, will you?")
dialogStr("Zostaw to.")


dialogId("pz-m-vylez", "font_small", "Get out!")
dialogStr("Wyłaź!")


dialogId("pz-v-dat", "font_big", "We have to put these keys somewhere.")
dialogStr("Musimy gdzieś upchnąć te klucze.")


dialogId("pz-m-nepasuje", "font_small", "It doesn’t seem to fit.")
dialogStr("Nijak to tam nie pasuje.")

