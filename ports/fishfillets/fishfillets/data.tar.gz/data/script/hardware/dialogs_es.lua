
dialogId("pz-v-zaskladanej", "font_big", "I’m completely blocked in here.")
dialogStr("Estoy completamente encerrado aquí.")


dialogId("pz-m-co", "font_small", "What are you doing up there?")
dialogStr("¿Qué haces ahí arriba?")


dialogId("pz-v-klice1", "font_big", "These must be some hardware keys.")
dialogStr("Esas deben de ser algunas llaves de materiales.")


dialogId("pz-v-klice2", "font_big", "There are many hardware keys here.")
dialogStr("Hay muchas llaves de materiales aquí.")


dialogId("pz-v-co1", "font_big", "What do you have down there?")
dialogStr("¿Qué tienes ahí abajo?")


dialogId("pz-v-co2", "font_big", "What’s down there?")
dialogStr("¿Qué hay ahí abajo?")


dialogId("pz-m-spoje1", "font_small", "There are some printed circuits here.")
dialogStr("Aquí hay algunos circuitos impresos.")


dialogId("pz-m-spoje2", "font_small", "There are some integrated circuits here.")
dialogStr("Aquí hay algunos circuitos integrados.")


dialogId("pz-m-spoje3", "font_small", "I am surrounded by electronics here.")
dialogStr("Estoy rodeado por electrónica aquí.")


dialogId("pz-m-pocitace", "font_small", "Computers. They’ve always fascinated me. But now I’m sick of them.")
dialogStr("Computadores. Siempre me han fascinado. Pero ahora estoy enfermo de ellos.")


dialogId("pz-x-pocitac", "font_white", "Fish. I’ve always hated them. And now my circuits are overloaded with them.")
dialogStr("Peces. Siempre los he odiado. Y ahora mis circuitos están sobrecargados con ellos.")


dialogId("pz-v-hej", "font_big", "Hey, how are you? It’s quite boring here.")
dialogStr("Hola, ¿Cómo estás? Es muy aburrido por aquí.")


dialogId("pz-m-nech", "font_small", "Can it, will you?")
dialogStr("Puede, ¿Si?")


dialogId("pz-m-vylez", "font_small", "Get out!")
dialogStr("¡Fuera!")


dialogId("pz-v-dat", "font_big", "We have to put these keys somewhere.")
dialogStr("Tenemos que poner esas llaves en alguna parte.")


dialogId("pz-m-nepasuje", "font_small", "It doesn’t seem to fit.")
dialogStr("Parece que no encaja.")

