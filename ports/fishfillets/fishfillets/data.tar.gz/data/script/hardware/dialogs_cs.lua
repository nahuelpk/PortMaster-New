
dialogId("pz-v-zaskladanej", "font_big", "I’m completely blocked in here.")
dialogStr("Jsem tady úplně zaskládanej.")


dialogId("pz-m-co", "font_small", "What are you doing up there?")
dialogStr("Co to tam nahoře máš?")


dialogId("pz-v-klice1", "font_big", "These must be some hardware keys.")
dialogStr("To jsou asi nějaké hardwarové klíče.")


dialogId("pz-v-klice2", "font_big", "There are many hardware keys here.")
dialogStr("Je tu spousta hardwarových klíčů.")


dialogId("pz-v-co1", "font_big", "What do you have down there?")
dialogStr("Co to tam dole máš, nevidím tam...")


dialogId("pz-v-co2", "font_big", "What’s down there?")
dialogStr("Co je tam dole?")


dialogId("pz-m-spoje1", "font_small", "There are some printed circuits here.")
dialogStr("Je tu několik plošných spojů.")


dialogId("pz-m-spoje2", "font_small", "There are some integrated circuits here.")
dialogStr("Jsou tu nějaké integrované obvody.")


dialogId("pz-m-spoje3", "font_small", "I am surrounded by electronics here.")
dialogStr("Jsem tu obklopena elektronikou...")


dialogId("pz-m-pocitace", "font_small", "Computers. They’ve always fascinated me. But now I’m sick of them.")
dialogStr("Počítače. Vždycky jsem jimi byla fascinována. Teď jich už ale mám plný zuby.")


dialogId("pz-x-pocitac", "font_white", "Fish. I’ve always hated them. And now my circuits are overloaded with them.")
dialogStr("Ryby. Vždycky jsem je nenáviděl. A teď jich tady mám plné obvody.")


dialogId("pz-v-hej", "font_big", "Hey, how are you? It’s quite boring here.")
dialogStr("Hej, jak je tam dole? Tady je celkem nuda.")


dialogId("pz-m-nech", "font_small", "Can it, will you?")
dialogStr("Nech si to.")


dialogId("pz-m-vylez", "font_small", "Get out!")
dialogStr("Vylez!")


dialogId("pz-v-dat", "font_big", "We have to put these keys somewhere.")
dialogStr("Musíme někam dát ty klíče.")


dialogId("pz-m-nepasuje", "font_small", "It doesn’t seem to fit.")
dialogStr("Nějak to tam nepasuje.")

