
dialogId("pz-v-zaskladanej", "font_big", "I’m completely blocked in here.")
dialogStr("Ich bin hier total eingeklemmt.")


dialogId("pz-m-co", "font_small", "What are you doing up there?")
dialogStr("Was machst du da oben?")


dialogId("pz-v-klice1", "font_big", "These must be some hardware keys.")
dialogStr("Das müssen Hardware-Schlüssel sein.")


dialogId("pz-v-klice2", "font_big", "There are many hardware keys here.")
dialogStr("Hier sind viele Hardware-Schlüssel.")


dialogId("pz-v-co1", "font_big", "What do you have down there?")
dialogStr("Was hast du da unten?")


dialogId("pz-v-co2", "font_big", "What’s down there?")
dialogStr("Was ist da unten?")


dialogId("pz-m-spoje1", "font_small", "There are some printed circuits here.")
dialogStr("Hier sind ein paar Leiterplatten.")


dialogId("pz-m-spoje2", "font_small", "There are some integrated circuits here.")
dialogStr("Hier sind ein paar integrierte Schaltkreise.")


dialogId("pz-m-spoje3", "font_small", "I am surrounded by electronics here.")
dialogStr("Ich bin hier von Elektronik umgeben.")


dialogId("pz-m-pocitace", "font_small", "Computers. They’ve always fascinated me. But now I’m sick of them.")
dialogStr("Rechner. Die haben mich immer fasziniert. Aber jetzt kann ich sie nicht mehr sehen.")


dialogId("pz-x-pocitac", "font_white", "Fish. I’ve always hated them. And now my circuits are overloaded with them.")
dialogStr("Fische. Ich habe sie immer gehasst. Und jetzt sind meine Schaltkreise voll damit.")


dialogId("pz-v-hej", "font_big", "Hey, how are you? It’s quite boring here.")
dialogStr("Hey, wie geht’s dir? Hier ist es ziemlich langweilig.")


dialogId("pz-m-nech", "font_small", "Can it, will you?")
dialogStr("Verarsch mich nicht!")


dialogId("pz-m-vylez", "font_small", "Get out!")
dialogStr("Komm raus!")


dialogId("pz-v-dat", "font_big", "We have to put these keys somewhere.")
dialogStr("Wir müssen diese Schlüssel irgendwo hintun.")


dialogId("pz-m-nepasuje", "font_small", "It doesn’t seem to fit.")
dialogStr("Scheint nicht zu passen.")

