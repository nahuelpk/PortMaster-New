
dialogId("pz-v-zaskladanej", "font_big", "I’m completely blocked in here.")
dialogStr("Ik zit hier helemaal ingesloten.")


dialogId("pz-m-co", "font_small", "What are you doing up there?")
dialogStr("Wat doe je daarboven?")


dialogId("pz-v-klice1", "font_big", "These must be some hardware keys.")
dialogStr("Dit zijn vast hardwaresleutels, ofzo.")


dialogId("pz-v-klice2", "font_big", "There are many hardware keys here.")
dialogStr("Er zijn hier een hoop hardwaresleutels.")


dialogId("pz-v-co1", "font_big", "What do you have down there?")
dialogStr("Wat heb je daar beneden allemaal?")


dialogId("pz-v-co2", "font_big", "What’s down there?")
dialogStr("Wat is er daar beneden?")


dialogId("pz-m-spoje1", "font_small", "There are some printed circuits here.")
dialogStr("Hier liggen nog wat printplaatjes.")


dialogId("pz-m-spoje2", "font_small", "There are some integrated circuits here.")
dialogStr("Hier heb ik wat circuitborden.")


dialogId("pz-m-spoje3", "font_small", "I am surrounded by electronics here.")
dialogStr("Ik word omgeven door electronica.")


dialogId("pz-m-pocitace", "font_small", "Computers. They’ve always fascinated me. But now I’m sick of them.")
dialogStr("Computers. Ik vond ze altijd fascinerend, maar nu kan ik ze niet meer zien.")


dialogId("pz-x-pocitac", "font_white", "Fish. I’ve always hated them. And now my circuits are overloaded with them.")
dialogStr("Vissen. Ik heb er altijd al een hekel aan gehad. En nu zitten mijn circuits er vol mee.")


dialogId("pz-v-hej", "font_big", "Hey, how are you? It’s quite boring here.")
dialogStr("Hee, hoe gaat het? Hier is het behoorlijk saai.")


dialogId("pz-m-nech", "font_small", "Can it, will you?")
dialogStr("Hou toch je bek!")


dialogId("pz-m-vylez", "font_small", "Get out!")
dialogStr("Kom eruit!")


dialogId("pz-v-dat", "font_big", "We have to put these keys somewhere.")
dialogStr("We moeten deze sleutels ergens in stoppen.")


dialogId("pz-m-nepasuje", "font_small", "It doesn’t seem to fit.")
dialogStr("Ik denk niet dat het past.")

