
dialogId("pz-v-zaskladanej", "font_big", "I’m completely blocked in here.")
dialogStr("Je suis complètement coincé ici.")


dialogId("pz-m-co", "font_small", "What are you doing up there?")
dialogStr("Que fais-tu là haut ?")


dialogId("pz-v-klice1", "font_big", "These must be some hardware keys.")
dialogStr("Elles doivent être des clés matérielles.")


dialogId("pz-v-klice2", "font_big", "There are many hardware keys here.")
dialogStr("Il y a beaucoup de clés matérielles ici.")


dialogId("pz-v-co1", "font_big", "What do you have down there?")
dialogStr("Qu'est-ce que tu as en bas ?")


dialogId("pz-v-co2", "font_big", "What’s down there?")
dialogStr("Qu'est-ce qu'il y a en bas ?")


dialogId("pz-m-spoje1", "font_small", "There are some printed circuits here.")
dialogStr("Il y a des circuits imprimés ici.")


dialogId("pz-m-spoje2", "font_small", "There are some integrated circuits here.")
dialogStr("Il y a des circuits intégrés ici.")


dialogId("pz-m-spoje3", "font_small", "I am surrounded by electronics here.")
dialogStr("Je suis entourée d'électronique ici.")


dialogId("pz-m-pocitace", "font_small", "Computers. They’ve always fascinated me. But now I’m sick of them.")
dialogStr("Les ordinateurs. Ils m'ont toujours fascinée. Mais là ils me donnent la nausée.")


dialogId("pz-x-pocitac", "font_white", "Fish. I’ve always hated them. And now my circuits are overloaded with them.")
dialogStr("Des poissons. Je les ai toujours détestés. Et maintenant mes circuits sont surchargés à cause d'eux.")


dialogId("pz-v-hej", "font_big", "Hey, how are you? It’s quite boring here.")
dialogStr("Hé, comment tu vas ? C'est un peu ennuyeux ici.")


dialogId("pz-m-nech", "font_small", "Can it, will you?")
dialogStr("Te fous pas de moi, veux-tu ?")


dialogId("pz-m-vylez", "font_small", "Get out!")
dialogStr("Allez ouste !")


dialogId("pz-v-dat", "font_big", "We have to put these keys somewhere.")
dialogStr("Nous devons bien mettre ces clés quelque part.")


dialogId("pz-m-nepasuje", "font_small", "It doesn’t seem to fit.")
dialogStr("Elle n'a pas l'air de rentrer.")

