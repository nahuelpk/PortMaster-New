
dialogId("pz-v-zaskladanej", "font_big", "I’m completely blocked in here.")
dialogStr("Sono completamente bloccato.")

dialogId("pz-m-co", "font_small", "What are you doing up there?")
dialogStr("Cosa fai là?")

dialogId("pz-v-klice1", "font_big", "These must be some hardware keys.")
dialogStr("Queste devono esserer delle chiavi hardware.")

dialogId("pz-v-klice2", "font_big", "There are many hardware keys here.")
dialogStr("È pieno di chiavi hardware qui intorno.")

dialogId("pz-v-co1", "font_big", "What do you have down there?")
dialogStr("Che cos'hai lì in basso?")

dialogId("pz-v-co2", "font_big", "What’s down there?")
dialogStr("Che c'è laggiù?")

dialogId("pz-m-spoje1", "font_small", "There are some printed circuits here.")
dialogStr("Qui ci sono alcuni circuiti stampati.")

dialogId("pz-m-spoje2", "font_small", "There are some integrated circuits here.")
dialogStr("Qui ci sono alcuni circuiti integrati.")

dialogId("pz-m-spoje3", "font_small", "I am surrounded by electronics here.")
dialogStr("Sono circondata da componenti elettronici...")

dialogId("pz-m-pocitace", "font_small", "Computers. They’ve always fascinated me. But now I’m sick of them.")
dialogStr("I computer. Mi hanno sempre affascinato. Ma ora ne ho le tasche piene.")

dialogId("pz-x-pocitac", "font_white", "Fish. I’ve always hated them. And now my circuits are overloaded with them.")
dialogStr("Pesci. Li ho sempre odiati. E ora no ho i circuiti pieni.")

dialogId("pz-v-hej", "font_big", "Hey, how are you? It’s quite boring here.")
dialogStr("Ehi, coem va? Qui è piuttosto noioso.")

dialogId("pz-m-nech", "font_small", "Can it, will you?")
dialogStr("Potresti, eh?.")

dialogId("pz-m-vylez", "font_small", "Get out!")
dialogStr("Fuori!")

dialogId("pz-v-dat", "font_big", "We have to put these keys somewhere.")
dialogStr("Dobbiamo mettere queste chiavi da qualche parte.")

dialogId("pz-m-nepasuje", "font_small", "It doesn’t seem to fit.")
dialogStr("Non ci sta.")
