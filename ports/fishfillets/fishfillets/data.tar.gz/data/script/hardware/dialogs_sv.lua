
dialogId("pz-v-zaskladanej", "font_big", "I’m completely blocked in here.")
dialogStr("Jag är helt instängd här.")


dialogId("pz-m-co", "font_small", "What are you doing up there?")
dialogStr("Vad gör du där uppe?")


dialogId("pz-v-klice1", "font_big", "These must be some hardware keys.")
dialogStr("Det måste vara några hårdvarunycklar.")


dialogId("pz-v-klice2", "font_big", "There are many hardware keys here.")
dialogStr("Det finns många hårdvarunycklar här.")


dialogId("pz-v-co1", "font_big", "What do you have down there?")
dialogStr("Vad har du där nere?")


dialogId("pz-v-co2", "font_big", "What’s down there?")
dialogStr("Vad finns där nere?")


dialogId("pz-m-spoje1", "font_small", "There are some printed circuits here.")
dialogStr("Det finns några tryckta kretsar här.")


dialogId("pz-m-spoje2", "font_small", "There are some integrated circuits here.")
dialogStr("Det finns några integrerade kretsar här.")


dialogId("pz-m-spoje3", "font_small", "I am surrounded by electronics here.")
dialogStr("Jag är omringad av elektronik.")


dialogId("pz-m-pocitace", "font_small", "Computers. They’ve always fascinated me. But now I’m sick of them.")
dialogStr("Datorer. De har alltid fascinerat mig. Men nu har jag tröttnat på dem.")


dialogId("pz-x-pocitac", "font_white", "Fish. I’ve always hated them. And now my circuits are overloaded with them.")
dialogStr("Fisk. Jag har alltid hatat dem. Och nu är mina kretsar överbelastade med dem.")


dialogId("pz-v-hej", "font_big", "Hey, how are you? It’s quite boring here.")
dialogStr("Hej, hur mår du? Det är ganska tråkigt här.")


dialogId("pz-m-nech", "font_small", "Can it, will you?")
dialogStr("Kan den, vill du?")


dialogId("pz-m-vylez", "font_small", "Get out!")
dialogStr("Kom ut!")


dialogId("pz-v-dat", "font_big", "We have to put these keys somewhere.")
dialogStr("Vi måste stoppa de här nycklarna någonstans.")


dialogId("pz-m-nepasuje", "font_small", "It doesn’t seem to fit.")
dialogStr("Den verkar inte passa.")

