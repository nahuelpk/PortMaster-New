dialogId("pz-v-zaskladanej", "font_big", "I’m completely blocked in here.")
dialogStr("Напълно съм блокиран тук вътре.")

dialogId("pz-m-co", "font_small", "What are you doing up there?")
dialogStr("Какво правиш там горе?")

dialogId("pz-v-klice1", "font_big", "These must be some hardware keys.")
dialogStr("Това трябва да са хардуерни ключове.")

dialogId("pz-v-klice2", "font_big", "There are many hardware keys here.")
dialogStr("Тук има доста хардуерни ключове.")

dialogId("pz-v-co1", "font_big", "What do you have down there?")
dialogStr("А какво има там долу?")

dialogId("pz-v-co2", "font_big", "What’s down there?")
dialogStr("Как е там, долу?")

dialogId("pz-m-spoje1", "font_small", "There are some printed circuits here.")
dialogStr("Печатни платки.")

dialogId("pz-m-spoje2", "font_small", "There are some integrated circuits here.")
dialogStr("Има разни интегрални схеми.")

dialogId("pz-m-spoje3", "font_small", "I am surrounded by electronics here.")
dialogStr("Заобиколена съм от електроника.")

dialogId("pz-m-pocitace", "font_small", "Computers. They’ve always fascinated me. But now I’m sick of them.")
dialogStr("Компютри. Винаги съм им се възхищавала. Сега обаче ми се повдига от тях.")

dialogId("pz-x-pocitac", "font_white", "Fish. I’ve always hated them. And now my circuits are overloaded with them.")
dialogStr("Риби. Винаги съм ги мразил. А сега схемите ми са претоварени от тях.")

dialogId("pz-v-hej", "font_big", "Hey, how are you? It’s quite boring here.")
dialogStr("Хей, как си? Тук е доста скучно.")

dialogId("pz-m-nech", "font_small", "Can it, will you?")
dialogStr("Я стига!")

dialogId("pz-m-vylez", "font_small", "Get out!")
dialogStr("Вън!")

dialogId("pz-v-dat", "font_big", "We have to put these keys somewhere.")
dialogStr("Трябва да поставим някъде тези ключове.")

dialogId("pz-m-nepasuje", "font_small", "It doesn’t seem to fit.")
dialogStr("Май не пасва.")

