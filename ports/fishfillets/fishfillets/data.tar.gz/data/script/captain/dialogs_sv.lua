
dialogId("vl-m-hara", "font_small", "There is a lot of garbage here!")
dialogStr("Här är det mycket skräp!")


dialogId("vl-v-kaj1", "font_big", "This was surely a captain’s cabin.")
dialogStr("Det här var tydligen kaptens hytt.")


dialogId("vl-v-kaj2", "font_big", "What would you expect after so many years?")
dialogStr("Vad hade du väntat dig efter så många år?")


dialogId("vl-m-hak", "font_small", "Do you think that Silver had this hook in place of his hand?")
dialogStr("Tror du att kapten Silver använde den här kroken som sin hand?")


dialogId("vl-v-lodni", "font_big", "This is a ship hook. It’s used to pull up boats...")
dialogStr("Det här en båtshake. Den används för att dra upp båtar...")


dialogId("vl-x-site", "font_brown", "... and nets!")
dialogStr("... och nät!")


dialogId("vl-m-oko", "font_small", "It’s a strange looking eye.")
dialogStr("Det är ett konstigt öga.")


dialogId("vl-v-silha", "font_big", "This eye squints kind of sneakily.")
dialogStr("Ögat kikar i smyg.")


dialogId("vl-leb-kecy0", "font_lightgrey", "Haven’t you seen my eye somewhere?")
dialogStr("Har du sett mitt öga här omkring?")


dialogId("vl-leb-kecy1", "font_lightgrey", "This scarf is very important. The human skull with an empty eye socket looks really disgusting, you know.")
dialogStr("Scarfen är mycket viktig. Skallen med en tom ögonhåla ser riktigt otäckt ut.")


dialogId("vl-leb-kecy2", "font_lightgrey", "After that unfortunate accident with a teaspoon I have a completely different viewpoint of the world.")
dialogStr("Efter den oturliga olyckan med en tesked så har jag en helt ny syn på tillvaron.")


dialogId("vl-leb-kecy3", "font_lightgrey", "Why am I here, after all? As if they can’t put some chest here... or a chamber pot.")
dialogStr("Varför är jag här, egentligen? Som om de skulle ställa en kista här... eller en potta.")


dialogId("vl-leb-kecy4", "font_lightgrey", "Do you appreciate my facial expressions? Not bad for a skeleton, is it?")
dialogStr("Gillar du mina grimaser? Inte dåligt för ett skelett, va?")

