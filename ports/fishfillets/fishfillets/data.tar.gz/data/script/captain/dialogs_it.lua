
dialogId("vl-m-hara", "font_small", "There is a lot of garbage here!")
dialogStr("C'è molta spazzatura qui!")

dialogId("vl-v-kaj1", "font_big", "This was surely a captain’s cabin.")
dialogStr("Questa era sicuramente la cabina di un capitano.")

dialogId("vl-v-kaj2", "font_big", "What would you expect after so many years?")
dialogStr("Cosa ti aspetti dopo tutto questo tempo?")

dialogId("vl-m-hak", "font_small", "Do you think that Silver had this hook in place of his hand?")
dialogStr("Pensi che Silver avesse questo uncino al posto della sua mano?")

dialogId("vl-v-lodni", "font_big", "This is a ship hook. It’s used to pull up boats...")
dialogStr("È un gancio da nave. Viene utilizzato per agganciare le scialuppe...")

dialogId("vl-x-site", "font_brown", "... and nets!")
dialogStr("...e le reti!")

dialogId("vl-m-oko", "font_small", "It’s a strange looking eye.")
dialogStr("È un occhio dall'aspetto strano.")

dialogId("vl-v-silha", "font_big", "This eye squints kind of sneakily.")
dialogStr("Quest'occhio sbircia in modo sospettoso.")

dialogId("vl-leb-kecy0", "font_lightgrey", "Haven’t you seen my eye somewhere?")
dialogStr("Avete visto il mio occhio da qualche parte?")

dialogId("vl-leb-kecy1", "font_lightgrey", "This scarf is very important. The human skull with an empty eye socket looks really disgusting, you know.")
dialogStr("Questa benda è molto importante. I teschi umani con un orbita oculare vuota hanno un aspetto disgustoso, sapete.")

dialogId("vl-leb-kecy2", "font_lightgrey", "After that unfortunate accident with a teaspoon I have a completely different viewpoint of the world.")
dialogStr("Dopo quello sfortunato incidente con il cucchiaino ho una visione del mondo completamente diversa.")

dialogId("vl-leb-kecy3", "font_lightgrey", "Why am I here, after all? As if they can’t put some chest here... or a chamber pot.")
dialogStr("Ma perché sto qui, dopo tutto? Come senon potessero mettere qui qualche cassa... o un vaso da notte.")

dialogId("vl-leb-kecy4", "font_lightgrey", "Do you appreciate my facial expressions? Not bad for a skeleton, is it?")
dialogStr("Vi piace la mia mimica facciale? Non male per uno scheletro, vero?")
