
dialogId("vl-m-hara", "font_small", "There is a lot of garbage here!")
dialogStr("Hier ist ja ein Haufen Müll!")


dialogId("vl-v-kaj1", "font_big", "This was surely a captain’s cabin.")
dialogStr("Das war sicherlich eine Kapitänskajüte.")


dialogId("vl-v-kaj2", "font_big", "What would you expect after so many years?")
dialogStr("Was erwartest du nach so vielen Jahren?")


dialogId("vl-m-hak", "font_small", "Do you think that Silver had this hook in place of his hand?")
dialogStr("Denkst du dass Silver diesen Haken anstatt seiner Hand hatte?")


dialogId("vl-v-lodni", "font_big", "This is a ship hook. It’s used to pull up boats...")
dialogStr("Das ist ein Enterhaken. Der wird verwendet, um Schiffe ranzuziehen...")


dialogId("vl-x-site", "font_brown", "... and nets!")
dialogStr("... und Netze!")


dialogId("vl-m-oko", "font_small", "It’s a strange looking eye.")
dialogStr("Das Auge sieht komisch aus.")


dialogId("vl-v-silha", "font_big", "This eye squints kind of sneakily.")
dialogStr("Das Auge schielt irgendwie hinterhältig.")


dialogId("vl-leb-kecy0", "font_lightgrey", "Haven’t you seen my eye somewhere?")
dialogStr("Habt Ihr mein Auge irgendwo gesehen?")


dialogId("vl-leb-kecy1", "font_lightgrey", "This scarf is very important. The human skull with an empty eye socket looks really disgusting, you know.")
dialogStr("Dieses Kopftuch ist sehr wichtig. Der menschliche Schädel sieht mit einer leeren Augenhöle echt eklig aus, wisst Ihr?")


dialogId("vl-leb-kecy2", "font_lightgrey", "After that unfortunate accident with a teaspoon I have a completely different viewpoint of the world.")
dialogStr("Nach diesem unglücklichen Unfall mit dem Teelöffel sehe ich die Welt mit ganz anderen Augen.")


dialogId("vl-leb-kecy3", "font_lightgrey", "Why am I here, after all? As if they can’t put some chest here... or a chamber pot.")
dialogStr("Warum bin ich überhaupt hier? Irgendeine Truhe hätte auch gereicht... oder ein Nachttopf.")


dialogId("vl-leb-kecy4", "font_lightgrey", "Do you appreciate my facial expressions? Not bad for a skeleton, is it?")
dialogStr("Mögt Ihr meine Gesichtsausdrücke? Nicht schlecht für ein Skelett, oder?")

