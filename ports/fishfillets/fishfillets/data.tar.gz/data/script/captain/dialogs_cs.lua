
dialogId("vl-m-hara", "font_small", "There is a lot of garbage here!")
dialogStr("To je ale haraburdí!")


dialogId("vl-v-kaj1", "font_big", "This was surely a captain’s cabin.")
dialogStr("To byla určitě kapitánova kajuta.")


dialogId("vl-v-kaj2", "font_big", "What would you expect after so many years?")
dialogStr("Co bys chtěla po tolika letech.")


dialogId("vl-m-hak", "font_small", "Do you think that Silver had this hook in place of his hand?")
dialogStr("Myslíš, že ten hák měl Silver místo ruky? Jak by se do té kajuty vešel?")


dialogId("vl-v-lodni", "font_big", "This is a ship hook. It’s used to pull up boats...")
dialogStr("To je lodní hák. S ním se vytahují čluny...")


dialogId("vl-x-site", "font_brown", "... and nets!")
dialogStr("... a sítě!")


dialogId("vl-m-oko", "font_small", "It’s a strange looking eye.")
dialogStr("S tím okem to nevidím dobře.")


dialogId("vl-v-silha", "font_big", "This eye squints kind of sneakily.")
dialogStr("To oko potměšile šilhá.")


dialogId("vl-leb-kecy0", "font_lightgrey", "Haven’t you seen my eye somewhere?")
dialogStr("Neviděli jste někde moje oko?")


dialogId("vl-leb-kecy1", "font_lightgrey", "This scarf is very important. The human skull with an empty eye socket looks really disgusting, you know.")
dialogStr("Tenhle šátek je velice důležitý. Víte, ona lidská lebka s prázdným očním důlkem vypadá opravdu odpudivě.")


dialogId("vl-leb-kecy2", "font_lightgrey", "After that unfortunate accident with a teaspoon I have a completely different viewpoint of the world.")
dialogStr("Po té nešťastné nehodě s čajovou lžičkou se na svět dívám úplně jinak.")


dialogId("vl-leb-kecy3", "font_lightgrey", "Why am I here, after all? As if they can’t put some chest here... or a chamber pot.")
dialogStr("Proč já tady vlastně musím být. Jako by sem místo mě nemohli vrznout třeba truhlu... nebo kastról.")


dialogId("vl-leb-kecy4", "font_lightgrey", "Do you appreciate my facial expressions? Not bad for a skeleton, is it?")
dialogStr("Všímáte si práce mých mimických svalů? Dost dobrý, na kostru, ne?")

