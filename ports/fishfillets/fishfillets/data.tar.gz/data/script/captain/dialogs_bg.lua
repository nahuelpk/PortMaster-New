dialogId("vl-m-hara", "font_small", "There is a lot of garbage here!")
dialogStr("Доста боклук има тук!")

dialogId("vl-v-kaj1", "font_big", "This was surely a captain’s cabin.")
dialogStr("Това сигурно е каютата на капитана.")

dialogId("vl-v-kaj2", "font_big", "What would you expect after so many years?")
dialogStr("Ти какво очакваш след толкова много години?")

dialogId("vl-m-hak", "font_small", "Do you think that Silver had this hook in place of his hand?")
dialogStr("Мислиш ли, че това е куката, която е имал Силвър вместо ръка?")

dialogId("vl-v-lodni", "font_big", "This is a ship hook. It’s used to pull up boats...")
dialogStr("Това е корабна кука. Използва се за изтегляне на лодки...")

dialogId("vl-x-site", "font_brown", "... and nets!")
dialogStr("... и мрежи!")

dialogId("vl-m-oko", "font_small", "It’s a strange looking eye.")
dialogStr("Това око изглежда странно.")

dialogId("vl-v-silha", "font_big", "This eye squints kind of sneakily.")
dialogStr("Това око е изглежда подло кривогледо.")

dialogId("vl-leb-kecy0", "font_lightgrey", "Haven’t you seen my eye somewhere?")
dialogStr("Да сте ми виждали окото някъде?")

dialogId("vl-leb-kecy1", "font_lightgrey", "This scarf is very important. The human skull with an empty eye socket looks really disgusting, you know.")
dialogStr("Този шал е много важен. Човешкият череп с празна очна яма изглежда наистина отвратително.")

dialogId("vl-leb-kecy2", "font_lightgrey", "After that unfortunate accident with a teaspoon I have a completely different viewpoint of the world.")
dialogStr("След онзи неприятен инцидент с чаената лъжичка гледам на света по съвсем различен начин.")

dialogId("vl-leb-kecy3", "font_lightgrey", "Why am I here, after all? As if they can’t put some chest here... or a chamber pot.")
dialogStr("Защо съм тук, все пак? Можеха да сложат някой скелет наоколо... или поне гръден кош.")

dialogId("vl-leb-kecy4", "font_lightgrey", "Do you appreciate my facial expressions? Not bad for a skeleton, is it?")
dialogStr("Оценявате ли изразителността на лицето ми? Не е зле за скелет, нали?")

