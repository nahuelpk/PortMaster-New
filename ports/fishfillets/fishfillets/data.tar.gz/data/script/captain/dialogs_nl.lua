
dialogId("vl-m-hara", "font_small", "There is a lot of garbage here!")
dialogStr("Wat een zooitje!")


dialogId("vl-v-kaj1", "font_big", "This was surely a captain’s cabin.")
dialogStr("Dit was vast de hut van de kapitein.")


dialogId("vl-v-kaj2", "font_big", "What would you expect after so many years?")
dialogStr("Wat had je dan verwacht na al die tijd?")


dialogId("vl-m-hak", "font_small", "Do you think that Silver had this hook in place of his hand?")
dialogStr("Denk je dat Silver deze haak had in plaats van een hand?")


dialogId("vl-v-lodni", "font_big", "This is a ship hook. It’s used to pull up boats...")
dialogStr("Dat is een enterhaak. Die gebruikten ze voor het opheisen van boten...")


dialogId("vl-x-site", "font_brown", "... and nets!")
dialogStr("... en netten!")


dialogId("vl-m-oko", "font_small", "It’s a strange looking eye.")
dialogStr("Dat oog ziet er raar uit.")


dialogId("vl-v-silha", "font_big", "This eye squints kind of sneakily.")
dialogStr("Dat oog kijkt geniepig.")


dialogId("vl-leb-kecy0", "font_lightgrey", "Haven’t you seen my eye somewhere?")
dialogStr("Hebben jullie mijn oog toevallig ergens gezien?")


dialogId("vl-leb-kecy1", "font_lightgrey", "This scarf is very important. The human skull with an empty eye socket looks really disgusting, you know.")
dialogStr("Deze doek is erg belangrijk. Die menselijke schedel met een lege oogkas ziet er vreselijk uit, weet je.")


dialogId("vl-leb-kecy2", "font_lightgrey", "After that unfortunate accident with a teaspoon I have a completely different viewpoint of the world.")
dialogStr("Na dat afgrijselijke ongeluk met die theelepel zie ik de wereld heel anders.")


dialogId("vl-leb-kecy3", "font_lightgrey", "Why am I here, after all? As if they can’t put some chest here... or a chamber pot.")
dialogStr("Waarom ben ik hier? Het is niet alsof ze hier niet een kist zouden kunnen neerzetten... of een ondersteek.")


dialogId("vl-leb-kecy4", "font_lightgrey", "Do you appreciate my facial expressions? Not bad for a skeleton, is it?")
dialogStr("Wat vind je van mijn gezichtsuitdrukkingen? Niet slecht voor een skelet, he?")

