
dialogId("vl-m-hara", "font_small", "There is a lot of garbage here!")
dialogStr("Ale tu bałagan!")


dialogId("vl-v-kaj1", "font_big", "This was surely a captain’s cabin.")
dialogStr("To z pewnością kajuta kapitańska.")


dialogId("vl-v-kaj2", "font_big", "What would you expect after so many years?")
dialogStr("A czego się spodziewałaś po tylu latach?")


dialogId("vl-m-hak", "font_small", "Do you think that Silver had this hook in place of his hand?")
dialogStr("Myślisz, że Silver miał ten hak zamiast ręki? Chyba miałby trudności z wchodzeniem do kajuty...")


dialogId("vl-v-lodni", "font_big", "This is a ship hook. It’s used to pull up boats...")
dialogStr("To jest hak żeglarski. Wciągano nim szalupy...")


dialogId("vl-x-site", "font_brown", "... and nets!")
dialogStr("... i sieci!")


dialogId("vl-m-oko", "font_small", "It’s a strange looking eye.")
dialogStr("Dziwne to oko.")


dialogId("vl-v-silha", "font_big", "This eye squints kind of sneakily.")
dialogStr("Podejrzanie łypie to oko.")


dialogId("vl-leb-kecy0", "font_lightgrey", "Haven’t you seen my eye somewhere?")
dialogStr("Nie widzieliście gdzieś mojego oka?")


dialogId("vl-leb-kecy1", "font_lightgrey", "This scarf is very important. The human skull with an empty eye socket looks really disgusting, you know.")
dialogStr("Ta przepaska jest bardzo istotna. Wiecie, ludzka czaszka z pustym oczodołem wygląda odrażająco.")


dialogId("vl-leb-kecy2", "font_lightgrey", "After that unfortunate accident with a teaspoon I have a completely different viewpoint of the world.")
dialogStr("Po tym niefortunnym wypadku z łyżeczką od herbaty, mój obraz świata kompletnie się zmienił.")


dialogId("vl-leb-kecy3", "font_lightgrey", "Why am I here, after all? As if they can’t put some chest here... or a chamber pot.")
dialogStr("I po co ja tu jestem? Jakby nie mogli postawić jakiegoś kufra... albo nocnika.")


dialogId("vl-leb-kecy4", "font_lightgrey", "Do you appreciate my facial expressions? Not bad for a skeleton, is it?")
dialogStr("Podobają wam się moje miny? Całkiem nieźle jak na szkielet, nie?")

