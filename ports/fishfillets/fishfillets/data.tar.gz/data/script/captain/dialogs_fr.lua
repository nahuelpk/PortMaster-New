
dialogId("vl-m-hara", "font_small", "There is a lot of garbage here!")
dialogStr("Il y a beaucoup de détritus ici !")


dialogId("vl-v-kaj1", "font_big", "This was surely a captain’s cabin.")
dialogStr("C'était sûrement la cabine du capitaine.")


dialogId("vl-v-kaj2", "font_big", "What would you expect after so many years?")
dialogStr("À quoi t'attendais-tu après tant d'années?")


dialogId("vl-m-hak", "font_small", "Do you think that Silver had this hook in place of his hand?")
dialogStr("Penses-tu que Silver avait ce crochet à la place d'une main.")


dialogId("vl-v-lodni", "font_big", "This is a ship hook. It’s used to pull up boats...")
dialogStr("C'est une gaffe. Elle est utilisée pour tirer les bateaux...")


dialogId("vl-x-site", "font_brown", "... and nets!")
dialogStr("... Et les filets !")


dialogId("vl-m-oko", "font_small", "It’s a strange looking eye.")
dialogStr("Quel drôle d'oeil.")


dialogId("vl-v-silha", "font_big", "This eye squints kind of sneakily.")
dialogStr("Cet oeil louche de façon sournoise.")


dialogId("vl-leb-kecy0", "font_lightgrey", "Haven’t you seen my eye somewhere?")
dialogStr("N'avez-vous pas vu mon oeil quelque part ?")


dialogId("vl-leb-kecy1", "font_lightgrey", "This scarf is very important. The human skull with an empty eye socket looks really disgusting, you know.")
dialogStr("Ce bandeau est très important. Le crâne humain avec une orbite vide est vraiment écoeurant.")


dialogId("vl-leb-kecy2", "font_lightgrey", "After that unfortunate accident with a teaspoon I have a completely different viewpoint of the world.")
dialogStr("Après ce malheureux accident avec une cuillère à thé, ma vision du monde à complètement changé.")


dialogId("vl-leb-kecy3", "font_lightgrey", "Why am I here, after all? As if they can’t put some chest here... or a chamber pot.")
dialogStr("Pourquoi suis-je ici après tout ? Comme s'ils ne pouvaient pas mettre un coffre ici... ou un pot de chambre.")


dialogId("vl-leb-kecy4", "font_lightgrey", "Do you appreciate my facial expressions? Not bad for a skeleton, is it?")
dialogStr("Vous aimez mes expressions du visage ? Pas mal pour un squelette, n'est-ce pas ?")

