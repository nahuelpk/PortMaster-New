
dialogId("vl-m-hara", "font_small", "There is a lot of garbage here!")
dialogStr("¡Hay un montón de basura aquí!")


dialogId("vl-v-kaj1", "font_big", "This was surely a captain’s cabin.")
dialogStr("Esta fué seguramente la cabina del capitán.")


dialogId("vl-v-kaj2", "font_big", "What would you expect after so many years?")
dialogStr("¿Que esperarías después de tantos años?")


dialogId("vl-m-hak", "font_small", "Do you think that Silver had this hook in place of his hand?")
dialogStr("¿Crees que Silver tuvo este gancho en lugar de su mano?")


dialogId("vl-v-lodni", "font_big", "This is a ship hook. It’s used to pull up boats...")
dialogStr("Este es un gancho de barco. Es usado para subir los botes...")


dialogId("vl-x-site", "font_brown", "... and nets!")
dialogStr("... ¡y redes!")


dialogId("vl-m-oko", "font_small", "It’s a strange looking eye.")
dialogStr("Es un ojo que mira extraño.")


dialogId("vl-v-silha", "font_big", "This eye squints kind of sneakily.")
dialogStr("Este ojo mira de reojo.")


dialogId("vl-leb-kecy0", "font_lightgrey", "Haven’t you seen my eye somewhere?")
dialogStr("¿Haz visto mi ojo por algún lado?")


dialogId("vl-leb-kecy1", "font_lightgrey", "This scarf is very important. The human skull with an empty eye socket looks really disgusting, you know.")
dialogStr("Esta venda es muy importante. El cráneo humano con una órbita del ojo vacía es algo que luce realmente desagradable, tu sabes.")


dialogId("vl-leb-kecy2", "font_lightgrey", "After that unfortunate accident with a teaspoon I have a completely different viewpoint of the world.")
dialogStr("Después del desafortunado accidente con la cuchara de té tengo una visión completamente distinta del mundo .")


dialogId("vl-leb-kecy3", "font_lightgrey", "Why am I here, after all? As if they can’t put some chest here... or a chamber pot.")
dialogStr("¿Por qué estoy aquí después de todo? Como si ellos no pudieran poner aquí algún cofre... o un recipiente.")


dialogId("vl-leb-kecy4", "font_lightgrey", "Do you appreciate my facial expressions? Not bad for a skeleton, is it?")
dialogStr("¿Puedes apreciar mis expresiones faciales? No está mal para un esqueleto, ¿Verdad?")

