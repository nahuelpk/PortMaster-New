
dialogId("dr1-v-urcite", "font_big", "Definitely. It’s one of the earliest drakkars. Judging by the shape of the head, number of spirals and color of the water I think it belonged to the grandfather of Eric the Red.")
dialogStr("Definitiv. Es ist eine der ersten Drakkars. Nach der Form des Kopfes, der Anzahl der Spiralen und der Farbe des Wassers nach zu urteilen, gehörte es dem Grossvater von Erik dem Roten, denke ich.")


dialogId("dr1-v-leif", "font_big", "Or maybe to the great-uncle of Leif the Skillful.")
dialogStr("Oder vielleicht dem Grossonkel von Leif dem Geschickten.")


dialogId("dr1-v-harold", "font_big", "It could also belong to the niece of Harold the Great.")
dialogStr("Es könnte auch der Nichte von Harold dem Grossen gehören.")


dialogId("dr-4-erik", "font_viking4", "Even Erik the G-g-great Eric had a b-b-braid!")
dialogStr("Sogar Erik der G-g-grosse hatte ein Z-z-zopf!")

