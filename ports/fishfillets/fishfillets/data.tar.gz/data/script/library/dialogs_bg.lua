dialogId("vrak-v-vraky0", "font_big", "These shipwrecks grow more and more arrogant.")
dialogStr("Тези корабни останки стават все по-разхвърляни.")

dialogId("vrak-v-vraky1", "font_big", "These sunken ships really irritate me.")
dialogStr("Тези потънали кораби ми дойдоха до гуша.")

dialogId("vrak-v-vraky2", "font_big", "Oh my, another ship sank. It really makes me itchy.")
dialogStr("Ох, още един потънал кораб. Започват да ме побиват тръпки.")

dialogId("vrak-m-vrak0", "font_small", "Look, it broke our bookcase!")
dialogStr("Виж, библиотечката ни е счупена!")

dialogId("vrak-m-vrak1", "font_small", "Look, it smashed our shelves.")
dialogStr("Виж, смачкал ни е рафтовете.")

dialogId("vrak-m-vrak2", "font_small", "Look, it invaded our library.")
dialogStr("Гледай, нападнал е библиотеката ни.")

dialogId("vrak-m-kupovat0", "font_small", "See? You shouldn’t have bought so many books.")
dialogStr("Виждаш ли, че не трябва да купуваш толкова много книги?")

dialogId("vrak-m-kupovat1", "font_small", "You buy every book you can lay your hand on and now you have problems.")
dialogStr("Купуваш всяка книга, до която се докопаш и сега — ето ни с проблем.")

dialogId("vrak-m-naco", "font_small", "Why do you have to have so many of them?")
dialogStr("Защо трябва да имаш толкова много?")

dialogId("vrak-m-knihy0", "font_small", "ESP")
dialogStr("ЕСП")

dialogId("vrak-m-knihy1", "font_small", "Life after life.")
dialogStr("Живот след смъртта.")

dialogId("vrak-m-knihy2", "font_small", "Memories of the future.")
dialogStr("Спомени за бъдещето.")

dialogId("vrak-m-knihy3", "font_small", "Holistic methods.")
dialogStr("Холистични методи.")

dialogId("vrak-m-knihy4", "font_small", "Teach yourself telepathy.")
dialogStr("Да научим сами телепатия.")

dialogId("vrak-m-knihy5", "font_small", "Unwilling clairvoyant.")
dialogStr("Неволно подслушано.")

dialogId("vrak-m-knihy6", "font_small", "Outreaching Daniken.")
dialogStr("Достигане на недостижимото.")

dialogId("vrak-v-vyhodit", "font_big", "I’d throw out these, for example.")
dialogStr("Тези бих ги изхвърлил.")

dialogId("vrak-v-knihy0", "font_big", "The Three Little Shrimp")
dialogStr("Трите малки скаридки")

dialogId("vrak-v-knihy1", "font_big", "The Gingerbread Submarine")
dialogStr("Подводницата на Червената брада")

dialogId("vrak-v-knihy2", "font_big", "Goldilocks and the Three Lobsters")
dialogStr("Златоперка и трите омарчета")

dialogId("vrak-v-knihy3", "font_big", "Sharkerella")
dialogStr("Перкаляшка")

dialogId("vrak-v-knihy4", "font_big", "Slimy Squid and the Seven Dwarfs")
dialogStr("Лигавата сепия и седемте джуджета")

dialogId("vrak-m-pohadky", "font_small", "Never! My lovely fairy-tales.")
dialogStr("Никога! Любимите ми приказки.")

dialogId("vrak-v-nevejdu0", "font_big", "I can’t hide myself here.")
dialogStr("Не мога да се скрия тук.")

dialogId("vrak-v-nevejdu1", "font_big", "I can’t fit in here.")
dialogStr("Не се събирам тук.")

dialogId("vrak-m-cteni0", "font_small", "Why do we have so many books if we cannot pull them out anyway?")
dialogStr("Защо са ни толкова много книги при положение, че и без това не можем да ги извадим?")

dialogId("vrak-m-cteni1", "font_small", "If you did some work-outs instead of reading about silly affairs you could fit yourself in.")
dialogStr("Ако беше тренирал вместо да четеш евтини романчета сега нямаше да ти е тясно.")

dialogId("vrak-m-cteni2", "font_small", "I told you not to buy that Complete Dictionary of the Abnormal.")
dialogStr("Казвах ти да не купуваш онзи „Пълен речник на ненормалното“.")

dialogId("vrak-v-policky", "font_big", "Let’s think. We can’t get these books off the shelf.")
dialogStr("Да помислим. Не можем да свалим тези книги от рафта.")

dialogId("vrak-m-predmety", "font_small", "There are only two objects here which we can move with any results.")
dialogStr("Тук има само два обекта, които можем да преместим.")

dialogId("vrak-m-ostnatec", "font_small", "How did that prickler get here?")
dialogStr("Този игленик как се озова тук?")

dialogId("vrak-m-zivocich", "font_small", "You are in the way, strange life form!")
dialogStr("Пречиш ми да мина, странна форма на живот!")

dialogId("vrak-v-potvurka", "font_big", "You are an obstacle, strange creature!")
dialogStr("Пречиш ми, създание странно!")

dialogId("vrak-v-snek", "font_big", "Can’t you push that snail to me?")
dialogStr("Не можеш ли да бутнеш онзи охлюв върху мен?")

dialogId("vrak-m-ocel", "font_small", "How am I to get there through that steel?!")
dialogStr("Как да мина през тази стомана?!")

dialogId("vrak-m-restart", "font_small", "What about restarting and trying it again from scratch?")
dialogStr("Какво ще кажете да рестартирате и опитате отначало?")

