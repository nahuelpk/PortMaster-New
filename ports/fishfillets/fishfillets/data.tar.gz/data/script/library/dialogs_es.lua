
dialogId("vrak-v-vraky0", "font_big", "These shipwrecks grow more and more arrogant.")
dialogStr("Estos barcos ruinosos aumentan de forma cada vez mas arrogante.")


dialogId("vrak-v-vraky1", "font_big", "These sunken ships really irritate me.")
dialogStr("Estos barcos hundidos realmente me molestan.")


dialogId("vrak-v-vraky2", "font_big", "Oh my, another ship sank. It really makes me itchy.")
dialogStr("Oh, otro barco hundido. Realmente me molesta.")


dialogId("vrak-m-vrak0", "font_small", "Look, it broke our bookcase!")
dialogStr("Mira, ¡Rompió nuestra biblioteca!")


dialogId("vrak-m-vrak1", "font_small", "Look, it smashed our shelves.")
dialogStr("Mira, rompió nuestros estantes.")


dialogId("vrak-m-vrak2", "font_small", "Look, it invaded our library.")
dialogStr("Mira, invadió nuestra librería.")


dialogId("vrak-m-kupovat0", "font_small", "See? You shouldn’t have bought so many books.")
dialogStr("¿Ves? No deberías de haber comprado tantos libros.")


dialogId("vrak-m-kupovat1", "font_small", "You buy every book you can lay your hand on and now you have problems.")
dialogStr("Compras cualquier libro que esté a tu alcance y ahora tienes problemas.")


dialogId("vrak-m-naco", "font_small", "Why do you have to have so many of them?")
dialogStr("¿Porqué tienes que tener tantos?")


dialogId("vrak-m-knihy0", "font_small", "ESP")
dialogStr("Percepción Extra Sensorial.")


dialogId("vrak-m-knihy1", "font_small", "Life after life.")
dialogStr("Vida después de la vida.")


dialogId("vrak-m-knihy2", "font_small", "Memories of the future.")
dialogStr("Memorias del futuro.")


dialogId("vrak-m-knihy3", "font_small", "Holistic methods.")
dialogStr("Métodos holísticos.")


dialogId("vrak-m-knihy4", "font_small", "Teach yourself telepathy.")
dialogStr("Aprenda telepatía usted mismo.")


dialogId("vrak-m-knihy5", "font_small", "Unwilling clairvoyant.")
dialogStr("Clarividente desmotivado.")


dialogId("vrak-m-knihy6", "font_small", "Outreaching Daniken.")
dialogStr("Daniken inalcanzable.")


dialogId("vrak-v-vyhodit", "font_big", "I’d throw out these, for example.")
dialogStr("Yo tiraría esos, por ejemplo.")


dialogId("vrak-v-knihy0", "font_big", "The Three Little Shrimp")
dialogStr("Los Tres Pequeños Camarones.")


dialogId("vrak-v-knihy1", "font_big", "The Gingerbread Submarine")
dialogStr("El Submarino de Pan de Jengibre")


dialogId("vrak-v-knihy2", "font_big", "Goldilocks and the Three Lobsters")
dialogStr("Ricitos de Oro y los Tres Camarones.")


dialogId("vrak-v-knihy3", "font_big", "Sharkerella")
dialogStr("Tibucienta.")


dialogId("vrak-v-knihy4", "font_big", "Slimy Squid and the Seven Dwarfs")
dialogStr("Resbalosa Calamar y los Siete Enanos.")


dialogId("vrak-m-pohadky", "font_small", "Never! My lovely fairy-tales.")
dialogStr("¡Nunca! Mis queridas historias de hadas.")


dialogId("vrak-v-nevejdu0", "font_big", "I can’t hide myself here.")
dialogStr("No me puedo esconder aquí.")


dialogId("vrak-v-nevejdu1", "font_big", "I can’t fit in here.")
dialogStr("No quepo aquí.")


dialogId("vrak-m-cteni0", "font_small", "Why do we have so many books if we cannot pull them out anyway?")
dialogStr("¿Porqué tenemos tantos libros si ni siquiera los podemos sacar?")


dialogId("vrak-m-cteni1", "font_small", "If you did some work-outs instead of reading about silly affairs you could fit yourself in.")
dialogStr("Si hubieras hecho algo de ejercicio en lugar de leer tonterías podrías caber ahí.")


dialogId("vrak-m-cteni2", "font_small", "I told you not to buy that Complete Dictionary of the Abnormal.")
dialogStr("Te dije que no compraras ese Completo Diccionario de lo Anormal.")


dialogId("vrak-v-policky", "font_big", "Let’s think. We can’t get these books off the shelf.")
dialogStr("Pensemos. No podemos sacar esos libros del estante.")


dialogId("vrak-m-predmety", "font_small", "There are only two objects here which we can move with any results.")
dialogStr("Solo hay dos objetos aquí que podemos mover con algún resultado.")


dialogId("vrak-m-ostnatec", "font_small", "How did that prickler get here?")
dialogStr("¿Qué hacen esas espinas ahí?")


dialogId("vrak-m-zivocich", "font_small", "You are in the way, strange life form!")
dialogStr("¡Sal del camino, extraña forma de vida!")


dialogId("vrak-v-potvurka", "font_big", "You are an obstacle, strange creature!")
dialogStr("¡Eres un obstáculo, extraña criatura!")


dialogId("vrak-v-snek", "font_big", "Can’t you push that snail to me?")
dialogStr("¿Me puedes empujar ese caracol?")


dialogId("vrak-m-ocel", "font_small", "How am I to get there through that steel?!")
dialogStr("¡¿Cómo voy a poder llegar ahí a través de ese acero?!")


dialogId("vrak-m-restart", "font_small", "What about restarting and trying it again from scratch?")
dialogStr("¿Que tal reiniciando e intentándolo de nuevo desde el inicio?")

