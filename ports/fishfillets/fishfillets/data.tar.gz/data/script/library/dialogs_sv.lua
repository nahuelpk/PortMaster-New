
dialogId("vrak-v-vraky0", "font_big", "These shipwrecks grow more and more arrogant.")
dialogStr("Dom här skeppsvraken blir bara mer och mer arroganta.")


dialogId("vrak-v-vraky1", "font_big", "These sunken ships really irritate me.")
dialogStr("De här sjunkna skeppen irriterar mig mycket.")


dialogId("vrak-v-vraky2", "font_big", "Oh my, another ship sank. It really makes me itchy.")
dialogStr("Åh nej, ett till vrak. Det börjar att klia på mig")


dialogId("vrak-m-vrak0", "font_small", "Look, it broke our bookcase!")
dialogStr("Titta! Den förstörde vår bokhylla.")


dialogId("vrak-m-vrak1", "font_small", "Look, it smashed our shelves.")
dialogStr("Titta! Den slog sönder vår hylla.")


dialogId("vrak-m-vrak2", "font_small", "Look, it invaded our library.")
dialogStr("Titta! Den invaderade vårt bibliotek.")


dialogId("vrak-m-kupovat0", "font_small", "See? You shouldn’t have bought so many books.")
dialogStr("Ser du? Du skulle inte ha tagit med dig så många böcker")


dialogId("vrak-m-kupovat1", "font_small", "You buy every book you can lay your hand on and now you have problems.")
dialogStr("Du köper alla böcker du kan få tag på och nu har du problem.")


dialogId("vrak-m-naco", "font_small", "Why do you have to have so many of them?")
dialogStr("Varför måste du ha så många av dem?")


dialogId("vrak-m-knihy0", "font_small", "ESP")
dialogStr("PSI")


dialogId("vrak-m-knihy1", "font_small", "Life after life.")
dialogStr("Liv efter liv.")


dialogId("vrak-m-knihy2", "font_small", "Memories of the future.")
dialogStr("Minnen av framtiden.")


dialogId("vrak-m-knihy3", "font_small", "Holistic methods.")
dialogStr("Helhetsmetoder.")


dialogId("vrak-m-knihy4", "font_small", "Teach yourself telepathy.")
dialogStr("Lär dig själv telepati.")


dialogId("vrak-m-knihy5", "font_small", "Unwilling clairvoyant.")
dialogStr("Omedveten klärvoajans.")


dialogId("vrak-m-knihy6", "font_small", "Outreaching Daniken.")
dialogStr("Nå Daniken.")


dialogId("vrak-v-vyhodit", "font_big", "I’d throw out these, for example.")
dialogStr("Jag skulle slänga ut de här till exempel:")


dialogId("vrak-v-knihy0", "font_big", "The Three Little Shrimp")
dialogStr("Tre små räkor.")


dialogId("vrak-v-knihy1", "font_big", "The Gingerbread Submarine")
dialogStr("Rödluvan och hajen.")


dialogId("vrak-v-knihy2", "font_big", "Goldilocks and the Three Lobsters")
dialogStr("Guldlock och de tre humrarna.")


dialogId("vrak-v-knihy3", "font_big", "Sharkerella")
dialogStr("Askhajen.")


dialogId("vrak-v-knihy4", "font_big", "Slimy Squid and the Seven Dwarfs")
dialogStr("Slemvit och de sju dvärgarna.")


dialogId("vrak-m-pohadky", "font_small", "Never! My lovely fairy-tales.")
dialogStr("Min första sagobåt.")


dialogId("vrak-v-nevejdu0", "font_big", "I can’t hide myself here.")
dialogStr("Jag kan inte gömma mig här.")


dialogId("vrak-v-nevejdu1", "font_big", "I can’t fit in here.")
dialogStr("Jag får inte plats här.")


dialogId("vrak-m-cteni0", "font_small", "Why do we have so many books if we cannot pull them out anyway?")
dialogStr("Varför har vi så många böcker om vi ändå inte kan dra fram dem?")


dialogId("vrak-m-cteni1", "font_small", "If you did some work-outs instead of reading about silly affairs you could fit yourself in.")
dialogStr("Om du tränade lite istället för att läsa om fåniga affärer skulle du ha fått plats.")


dialogId("vrak-m-cteni2", "font_small", "I told you not to buy that Complete Dictionary of the Abnormal.")
dialogStr("Jag har ju sagt till dig att du inte skulle köpa ett helt uppslagsverk om det onaturliga.")


dialogId("vrak-v-policky", "font_big", "Let’s think. We can’t get these books off the shelf.")
dialogStr("Tänk efter. Vi kan inte få ner böckerna från hyllorna.")


dialogId("vrak-m-predmety", "font_small", "There are only two objects here which we can move with any results.")
dialogStr("Det finns bara två saker här som vi kan flytta på och få någon resultat av.")


dialogId("vrak-m-ostnatec", "font_small", "How did that prickler get here?")
dialogStr("Hur kom pricklern hit?")


dialogId("vrak-m-zivocich", "font_small", "You are in the way, strange life form!")
dialogStr("Du är i vägen, konstiga livsform!")


dialogId("vrak-v-potvurka", "font_big", "You are an obstacle, strange creature!")
dialogStr("Du är ett hinder, konstiga djur!")


dialogId("vrak-v-snek", "font_big", "Can’t you push that snail to me?")
dialogStr("Kan du inte knuffa snigeln mot mig?")


dialogId("vrak-m-ocel", "font_small", "How am I to get there through that steel?!")
dialogStr("Hur ska jag kunna komma genom det där stålet?!")


dialogId("vrak-m-restart", "font_small", "What about restarting and trying it again from scratch?")
dialogStr("Borde vi inte starta om från början?")

