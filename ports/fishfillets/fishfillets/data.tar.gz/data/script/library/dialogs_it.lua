
dialogId("vrak-v-vraky0", "font_big", "These shipwrecks grow more and more arrogant.")
dialogStr("Questi relitti di navi diventano ogni giorno più arroganti.")


dialogId("vrak-v-vraky1", "font_big", "These sunken ships really irritate me.")
dialogStr("Queste navi colate a picco mi irritano molto.")


dialogId("vrak-v-vraky2", "font_big", "Oh my, another ship sank. It really makes me itchy.")
dialogStr("Povero me, un'altra nave affondata. Mi fanno venire il prurito.")


dialogId("vrak-m-vrak0", "font_small", "Look, it broke our bookcase!")
dialogStr("Guarda, ha danneggiato la nostra libreria!")


dialogId("vrak-m-vrak1", "font_small", "Look, it smashed our shelves.")
dialogStr("Guarda, ha spezzato gli scaffali.")


dialogId("vrak-m-vrak2", "font_small", "Look, it invaded our library.")
dialogStr("Guarda, ci ha invaso la biblioteca.")


dialogId("vrak-m-kupovat0", "font_small", "See? You shouldn’t have bought so many books.")
dialogStr("Visto? Non avresti dovuto comprare così tanti libri.")


dialogId("vrak-m-kupovat1", "font_small", "You buy every book you can lay your hand on and now you have problems.")
dialogStr("Compri ogni libro su cui riesci a posare le pinne e adesso hai dei problemi.")


dialogId("vrak-m-naco", "font_small", "Why do you have to have so many of them?")
dialogStr("Perché devi tenerne così tanti?")


dialogId("vrak-m-knihy0", "font_small", "ESP")
dialogStr("\"La percezione extrasensoriale\"")


dialogId("vrak-m-knihy1", "font_small", "Life after life.")
dialogStr("\"La vita dopo la vita\"")


dialogId("vrak-m-knihy2", "font_small", "Memories of the future.")
dialogStr("\"Memorie dal futuro\"")


dialogId("vrak-m-knihy3", "font_small", "Holistic methods.")
dialogStr("\"Metodi olistici\"")


dialogId("vrak-m-knihy4", "font_small", "Teach yourself telepathy.")
dialogStr("\"La telepatia in dieci lezioni\"")


dialogId("vrak-m-knihy5", "font_small", "Unwilling clairvoyant.")
dialogStr("\"Il chiaroveggente riluttante\"")


dialogId("vrak-m-knihy6", "font_small", "Outreaching Daniken.")
dialogStr("\"Irraggiungibile Daniken\"")


dialogId("vrak-v-vyhodit", "font_big", "I’d throw out these, for example.")
dialogStr("Potrei liberarmi di questi, per esempio...")


dialogId("vrak-v-knihy0", "font_big", "The Three Little Shrimp")
dialogStr("\"I Tre Gamberetti\"")


dialogId("vrak-v-knihy1", "font_big", "The Gingerbread Submarine")
dialogStr("\"Il Sottomarino di Marzapane\"")


dialogId("vrak-v-knihy2", "font_big", "Goldilocks and the Three Lobsters")
dialogStr("\"Riccioli d'oro e le Tre Aragoste\"")


dialogId("vrak-v-knihy3", "font_big", "Sharkerella")
dialogStr("\"Pescerentola\"")


dialogId("vrak-v-knihy4", "font_big", "Slimy Squid and the Seven Dwarfs")
dialogStr("\"Verdealga e i Sette Calamari\"")


dialogId("vrak-m-pohadky", "font_small", "Never! My lovely fairy-tales.")
dialogStr("Mai! Le mie adorate favole.")


dialogId("vrak-v-nevejdu0", "font_big", "I can’t hide myself here.")
dialogStr("Non posso nascondermi qui.")


dialogId("vrak-v-nevejdu1", "font_big", "I can’t fit in here.")
dialogStr("Qui non ci sto.")


dialogId("vrak-m-cteni0", "font_small", "Why do we have so many books if we cannot pull them out anyway?")
dialogStr("Comunque... perché abbiamo così tanti libri se non possiamo neanche tirarli fuori?")


dialogId("vrak-m-cteni1", "font_small", "If you did some work-outs instead of reading about silly affairs you could fit yourself in.")
dialogStr("Se facessi un po' di attività invece di leggere quelle stramberie ci passeresti.")


dialogId("vrak-m-cteni2", "font_small", "I told you not to buy that Complete Dictionary of the Abnormal.")
dialogStr("Ti avevo detto di non comprare l'intera Enciclopedia del Paranormale.")


dialogId("vrak-v-policky", "font_big", "Let’s think. We can’t get these books off the shelf.")
dialogStr("Ragioniamo. Non possiamo tirar giù questi libri dagli scaffali.")


dialogId("vrak-m-predmety", "font_small", "There are only two objects here which we can move with any results.")
dialogStr("Ci sono solo due oggetti che possiamo spostare con utilità.")


dialogId("vrak-m-ostnatec", "font_small", "How did that prickler get here?")
dialogStr("Come è arrivato qui quel coso?")


dialogId("vrak-m-zivocich", "font_small", "You are in the way, strange life form!")
dialogStr("Ci stai bloccando la strada, strana forma di vita!")


dialogId("vrak-v-potvurka", "font_big", "You are an obstacle, strange creature!")
dialogStr("Ci ostacoli, bizzarra creatura!")


dialogId("vrak-v-snek", "font_big", "Can’t you push that snail to me?")
dialogStr("Potresti spingere quel lumacone verso di me?")


dialogId("vrak-m-ocel", "font_small", "How am I to get there through that steel?!")
dialogStr("Come posso arrivarci attraverso quell'acciaio?!")


dialogId("vrak-m-restart", "font_small", "What about restarting and trying it again from scratch?")
dialogStr("Che ne dici di ricominciare daccapo?")

