
dialogId("vrak-m-knihy0", "font_small", "ESP")
dialogStr("Aussersinnliche Wahrnehmung.")


dialogId("vrak-v-vyhodit", "font_big", "I’d throw out these, for example.")
dialogStr("Ich würde die hier zum Beispiel wegschmeissen:")


dialogId("vrak-v-knihy0", "font_big", "The Three Little Shrimp")
dialogStr("Der Hai und die sieben Geisslein.")

