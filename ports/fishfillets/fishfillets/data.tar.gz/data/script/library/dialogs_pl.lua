
dialogId("vrak-v-vraky0", "font_big", "These shipwrecks grow more and more arrogant.")
dialogStr("Te wraki coraz śmielej sobie poczynają.")


dialogId("vrak-v-vraky1", "font_big", "These sunken ships really irritate me.")
dialogStr("Te wraki działają mi na nerwy.")


dialogId("vrak-v-vraky2", "font_big", "Oh my, another ship sank. It really makes me itchy.")
dialogStr("I znów jakiś statek zatonął. Mam już tego dość!")


dialogId("vrak-m-vrak0", "font_small", "Look, it broke our bookcase!")
dialogStr("Zobacz, roztrzaskał naszą biblioteczkę!")


dialogId("vrak-m-vrak1", "font_small", "Look, it smashed our shelves.")
dialogStr("Spójrz, zniszczył nasze półki.")


dialogId("vrak-m-vrak2", "font_small", "Look, it invaded our library.")
dialogStr("Popatrz, wlazł nam aż do biblioteki.")


dialogId("vrak-m-kupovat0", "font_small", "See? You shouldn’t have bought so many books.")
dialogStr("I tyle ci przyszło z kupowania tych wszystkich książek.")


dialogId("vrak-m-kupovat1", "font_small", "You buy every book you can lay your hand on and now you have problems.")
dialogStr("Kupujesz każdą książkę, jaka ci wpadnie w płetwy, i się w końcu doigrałeś.")


dialogId("vrak-m-naco", "font_small", "Why do you have to have so many of them?")
dialogStr("Na co ci w ogóle tyle książek?")


dialogId("vrak-m-knihy0", "font_small", "ESP")
dialogStr("Zjawiska paranormalne.")


dialogId("vrak-m-knihy1", "font_small", "Life after life.")
dialogStr("Życie po śmierci.")


dialogId("vrak-m-knihy2", "font_small", "Memories of the future.")
dialogStr("Wspomnienia z przyszłości.")


dialogId("vrak-m-knihy3", "font_small", "Holistic methods.")
dialogStr("Metody holistyczne.")


dialogId("vrak-m-knihy4", "font_small", "Teach yourself telepathy.")
dialogStr("Telepatia dla opornych.")


dialogId("vrak-m-knihy5", "font_small", "Unwilling clairvoyant.")
dialogStr("Jasnowidz mimo woli.")


dialogId("vrak-m-knihy6", "font_small", "Outreaching Daniken.")
dialogStr("Prześcignąć Danikena.")


dialogId("vrak-v-vyhodit", "font_big", "I’d throw out these, for example.")
dialogStr("Ja bym wyrzucił kilka z tych...")


dialogId("vrak-v-knihy0", "font_big", "The Three Little Shrimp")
dialogStr("Trzy małe krewetki.")


dialogId("vrak-v-knihy1", "font_big", "The Gingerbread Submarine")
dialogStr("Piernikowa łodź podwodna.")


dialogId("vrak-v-knihy2", "font_big", "Goldilocks and the Three Lobsters")
dialogStr("Długi, Szeroki i Głęboki.")


dialogId("vrak-v-knihy3", "font_big", "Sharkerella")
dialogStr("Rybka na ziarnku piasku.")


dialogId("vrak-v-knihy4", "font_big", "Slimy Squid and the Seven Dwarfs")
dialogStr("Królewna Szczeżuja i Siedem Krasnorostów.")


dialogId("vrak-m-pohadky", "font_small", "Never! My lovely fairy-tales.")
dialogStr("Nigdy! Moje ukochane bajki!")


dialogId("vrak-v-nevejdu0", "font_big", "I can’t hide myself here.")
dialogStr("Tu się nie schowam.")


dialogId("vrak-v-nevejdu1", "font_big", "I can’t fit in here.")
dialogStr("Nie zmieszczę się tu.")


dialogId("vrak-m-cteni0", "font_small", "Why do we have so many books if we cannot pull them out anyway?")
dialogStr("Po co nam tyle książek, skoro i tak nie możemy ich wyciągnąć?")


dialogId("vrak-m-cteni1", "font_small", "If you did some work-outs instead of reading about silly affairs you could fit yourself in.")
dialogStr("Gdybyś trochę poćwiczył, zamiast czytać o głupotach, to byś się spokojnie zmieścił.")


dialogId("vrak-m-cteni2", "font_small", "I told you not to buy that Complete Dictionary of the Abnormal.")
dialogStr("Mówiłam ci, żebyś nie kupował Wielkiego Słownika Anomalii.")


dialogId("vrak-v-policky", "font_big", "Let’s think. We can’t get these books off the shelf.")
dialogStr("Pomyślmy. Nie zdejmiemy tych książek z półek.")


dialogId("vrak-m-predmety", "font_small", "There are only two objects here which we can move with any results.")
dialogStr("Tu są tylko dwa przedmioty, które możemy sensownie przemieścić.")


dialogId("vrak-m-ostnatec", "font_small", "How did that prickler get here?")
dialogStr("Jak ten kolczak się tam dostał?")


dialogId("vrak-m-zivocich", "font_small", "You are in the way, strange life form!")
dialogStr("Przeszkadzasz nam, dziwolągu!")


dialogId("vrak-v-potvurka", "font_big", "You are an obstacle, strange creature!")
dialogStr("Wadzisz nam, potworku!")


dialogId("vrak-v-snek", "font_big", "Can’t you push that snail to me?")
dialogStr("Mogłabyś pchnąć tego ślimaka do mnie?")


dialogId("vrak-m-ocel", "font_small", "How am I to get there through that steel?!")
dialogStr("Jak się mam tam niby dostać przez tę rurę?!")


dialogId("vrak-m-restart", "font_small", "What about restarting and trying it again from scratch?")
dialogStr("A może spróbujemy jeszcze raz, od początku?")

