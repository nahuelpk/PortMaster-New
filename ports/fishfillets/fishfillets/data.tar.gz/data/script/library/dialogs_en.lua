
dialogId("vrak-v-vraky0", "font_big", "These shipwrecks grow more and more arrogant.")

dialogId("vrak-v-vraky1", "font_big", "These sunken ships really irritate me.")

dialogId("vrak-v-vraky2", "font_big", "Oh my, another ship sank. It really makes me itchy.")

dialogId("vrak-m-vrak0", "font_small", "Look, it broke our bookcase!")

dialogId("vrak-m-vrak1", "font_small", "Look, it smashed our shelves.")

dialogId("vrak-m-vrak2", "font_small", "Look, it invaded our library.")

dialogId("vrak-m-kupovat0", "font_small", "See? You shouldn’t have bought so many books.")

dialogId("vrak-m-kupovat1", "font_small", "You buy every book you can lay your hand on and now you have problems.")

dialogId("vrak-m-naco", "font_small", "Why do you have to have so many of them?")

dialogId("vrak-m-knihy0", "font_small", "ESP")

dialogId("vrak-m-knihy1", "font_small", "Life after life.")

dialogId("vrak-m-knihy2", "font_small", "Memories of the future.")

dialogId("vrak-m-knihy3", "font_small", "Holistic methods.")

dialogId("vrak-m-knihy4", "font_small", "Teach yourself telepathy.")

dialogId("vrak-m-knihy5", "font_small", "Unwilling clairvoyant.")

dialogId("vrak-m-knihy6", "font_small", "Outreaching Daniken.")

dialogId("vrak-v-vyhodit", "font_big", "I’d throw out these, for example.")

dialogId("vrak-v-knihy0", "font_big", "The Three Little Shrimp")

dialogId("vrak-v-knihy1", "font_big", "The Gingerbread Submarine")

dialogId("vrak-v-knihy2", "font_big", "Goldilocks and the Three Lobsters")

dialogId("vrak-v-knihy3", "font_big", "Sharkerella")

dialogId("vrak-v-knihy4", "font_big", "Slimy Squid and the Seven Dwarfs")

dialogId("vrak-m-pohadky", "font_small", "Never! My lovely fairy-tales.")

dialogId("vrak-v-nevejdu0", "font_big", "I can’t hide myself here.")

dialogId("vrak-v-nevejdu1", "font_big", "I can’t fit in here.")

dialogId("vrak-m-cteni0", "font_small", "Why do we have so many books if we cannot pull them out anyway?")

dialogId("vrak-m-cteni1", "font_small", "If you did some work-outs instead of reading about silly affairs you could fit yourself in.")

dialogId("vrak-m-cteni2", "font_small", "I told you not to buy that Complete Dictionary of the Abnormal.")

dialogId("vrak-v-policky", "font_big", "Let’s think. We can’t get these books off the shelf.")

dialogId("vrak-m-predmety", "font_small", "There are only two objects here which we can move with any results.")

dialogId("vrak-m-ostnatec", "font_small", "How did that prickler get here?")

dialogId("vrak-m-zivocich", "font_small", "You are in the way, strange life form!")

dialogId("vrak-v-potvurka", "font_big", "You are an obstacle, strange creature!")

dialogId("vrak-v-snek", "font_big", "Can’t you push that snail to me?")

dialogId("vrak-m-ocel", "font_small", "How am I to get there through that steel?!")

dialogId("vrak-m-restart", "font_small", "What about restarting and trying it again from scratch?")
