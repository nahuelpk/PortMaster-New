
dialogId("vrak-v-vraky0", "font_big", "These shipwrecks grow more and more arrogant.")
dialogStr("De wrakken van tegenwoordig worden steeds brutaler.")


dialogId("vrak-v-vraky1", "font_big", "These sunken ships really irritate me.")
dialogStr("Ik vind deze gezonken schepen heel erg irritant.")


dialogId("vrak-v-vraky2", "font_big", "Oh my, another ship sank. It really makes me itchy.")
dialogStr("O jee, er is weer een schip gezonken. Daar word ik echt niet goed van.")


dialogId("vrak-m-vrak0", "font_small", "Look, it broke our bookcase!")
dialogStr("Kijk hier, het heeft onze boekenkast stuk gemaakt!")


dialogId("vrak-m-vrak1", "font_small", "Look, it smashed our shelves.")
dialogStr("Moet je zien, het heeft onze kasten stuk gemaakt.")


dialogId("vrak-m-vrak2", "font_small", "Look, it invaded our library.")
dialogStr("Kijk nou, het is in onze biblioteek binnengevallen.")


dialogId("vrak-m-kupovat0", "font_small", "See? You shouldn’t have bought so many books.")
dialogStr("Zie je? Je had nooit zo veel boeken moeten kopen.")


dialogId("vrak-m-kupovat1", "font_small", "You buy every book you can lay your hand on and now you have problems.")
dialogStr("Je koopt elk boek dat je in handen krijgt en nu heb je een probleem.")


dialogId("vrak-m-naco", "font_small", "Why do you have to have so many of them?")
dialogStr("Waarom heb je er zoveel?")


dialogId("vrak-m-knihy0", "font_small", "ESP")
dialogStr("Zesde zintuig.")


dialogId("vrak-m-knihy1", "font_small", "Life after life.")
dialogStr("Leven na het leven.")


dialogId("vrak-m-knihy2", "font_small", "Memories of the future.")
dialogStr("Herinnering aan de toekomst.")


dialogId("vrak-m-knihy3", "font_small", "Holistic methods.")
dialogStr("Holistische methoden.")


dialogId("vrak-m-knihy4", "font_small", "Teach yourself telepathy.")
dialogStr("Leer jezelf gedachten lezen.")


dialogId("vrak-m-knihy5", "font_small", "Unwilling clairvoyant.")
dialogStr("Onvrijwillig helderziend.")


dialogId("vrak-m-knihy6", "font_small", "Outreaching Daniken.")
dialogStr("Verder reiken dan Daniken.")


dialogId("vrak-v-vyhodit", "font_big", "I’d throw out these, for example.")
dialogStr("Deze zou ik dus weggooien, bij voorbeeld.")


dialogId("vrak-v-knihy0", "font_big", "The Three Little Shrimp")
dialogStr("De Drie Kleine Garnaaltjes.")


dialogId("vrak-v-knihy1", "font_big", "The Gingerbread Submarine")
dialogStr("De Krabbenvanger van Hamelen.")


dialogId("vrak-v-knihy2", "font_big", "Goldilocks and the Three Lobsters")
dialogStr("Doornannemoontje.")


dialogId("vrak-v-knihy3", "font_big", "Sharkerella")
dialogStr("De Zeewierstaak.")


dialogId("vrak-v-knihy4", "font_big", "Slimy Squid and the Seven Dwarfs")
dialogStr("Glibberige Inktvis en de Zeven Dwergen.")


dialogId("vrak-m-pohadky", "font_small", "Never! My lovely fairy-tales.")
dialogStr("Nooit! Dat zijn mijn favoriete sprookjes!")


dialogId("vrak-v-nevejdu0", "font_big", "I can’t hide myself here.")
dialogStr("Ik kan me hier niet verstoppen.")


dialogId("vrak-v-nevejdu1", "font_big", "I can’t fit in here.")
dialogStr("Ik pas hier niet in.")


dialogId("vrak-m-cteni0", "font_small", "Why do we have so many books if we cannot pull them out anyway?")
dialogStr("Waarom heb je zo veel boeken als we ze toch niet uit de kast kunnen trekken?")


dialogId("vrak-m-cteni1", "font_small", "If you did some work-outs instead of reading about silly affairs you could fit yourself in.")
dialogStr("Als je een beetje aan lichaamsbeweging deed in plaats van over allemaal onzin te lezen, dan paste je er misschien tussen.")


dialogId("vrak-m-cteni2", "font_small", "I told you not to buy that Complete Dictionary of the Abnormal.")
dialogStr("Ik zei toch dat je het Volledige Woordenboek van het Abnormale niet moest kopen.")


dialogId("vrak-v-policky", "font_big", "Let’s think. We can’t get these books off the shelf.")
dialogStr("Laten we eens goed nadenken. We kunnen deze boeken niet van de plank af trekken.")


dialogId("vrak-m-predmety", "font_small", "There are only two objects here which we can move with any results.")
dialogStr("Er zijn hier maar twee dingen die we met enig resultaat kunnen bewegen.")


dialogId("vrak-m-ostnatec", "font_small", "How did that prickler get here?")
dialogStr("Hoe is dat prikding hier beland?")


dialogId("vrak-m-zivocich", "font_small", "You are in the way, strange life form!")
dialogStr("Je zit in de weg, rare levensvorm!")


dialogId("vrak-v-potvurka", "font_big", "You are an obstacle, strange creature!")
dialogStr("Je bent een obstakel, vreemd beest!")


dialogId("vrak-v-snek", "font_big", "Can’t you push that snail to me?")
dialogStr("Kun je die slak niet naar mij toe duwen?")


dialogId("vrak-m-ocel", "font_small", "How am I to get there through that steel?!")
dialogStr("Hoe moet ik daar komen door dat stalen ding?!")


dialogId("vrak-m-restart", "font_small", "What about restarting and trying it again from scratch?")
dialogStr("Wat dacht je van opnieuw beginnen?")

