dialogId("start-0", "font_small", "Look, someone’s built a lock in the stone.")

dialogId("start-1", "font_big", "Where do you see a lock? I only see I can’t leave through the door.")

dialogId("start-2", "font_small", "There is a lock here somewhere. The key is down there.")

dialogId("start-3", "font_big", "I can’t leave anyway. Everything is blocked over there.")

dialogId("start-4", "font_small", "That’s why we need the key.")


dialogId("rd-0-0", "font_big", "Could you please get me the key, I would like to leave.")

dialogId("rd-0-1", "font_small", "I would if I could, but I think it’s stuck.")


dialogId("rd-1-0", "font_big", "Look, a broom.")

dialogId("rd-1-1", "font_small", "I don’t want to clean up here. It was bad enough in the boiler room.")

dialogId("rd-1-2", "font_big", "Why are you complaining? I cleared away all the heavy things there.")

dialogId("rd-1-3", "font_small", "Without me, you would still be stuck there.")


dialogId("rd-2-0", "font_small", "We could just swim out. Do you see how big the holes in the net are?")

dialogId("rd-2-1", "font_big", "Yes, too small for me.")


dialogId("rd-3-0", "font_small", "I think we should really use the key to open the lock.")

dialogId("rd-3-1", "font_big", "Then go get it, smarty-pants.")

dialogId("rd-3-2", "font_small", "Be nice to me, or I might swim out alone.")

dialogId("rd-3-3", "font_big", "OK, I won’t say such things to you anymore.")

dialogId("rd-3-4", "font_small", "Don’t even think them.")

dialogId("rd-3-5", "font_big", "Hmm... OK.")


dialogId("rd-4-0", "font_big", "Do you think the key will get loose if we move it around a bit?")

dialogId("rd-4-1", "font_small", "I don’t think so, but we can try.")


dialogId("rdopt-0-0", "font_big", "We’ll never get the key out. It’s been stuck there so long that it’s grown over with coral.")

dialogId("rdopt-0-1", "font_small", "Don’t give up.")


dialogId("rdopt-1-0", "font_big", "Could the icicle over there help?")

dialogId("rdopt-1-1", "font_small", "We can’t get it out anyway.")

dialogId("rdopt-1-2", "font_big", "We just have to apply enough force.")

dialogId("rdopt-1-3", "font_small", "Perhaps if you use the hammer?")


dialogId("cactus-0small", "font_small", "Outch, that cactus has spikes.")

dialogId("cactus-1small", "font_big", "Of course, it’s a cactus.")

dialogId("cactus-2small", "font_small", "What’s it doing here?")


dialogId("cactus-0big", "font_big", "Outch, that cactus has spikes.")

dialogId("cactus-1big", "font_small", "Of course, it’s a cactus.")

dialogId("cactus-2big", "font_big", "What’s it doing here?")


dialogId("up-0-0", "font_big", "We’ve got it. Now hold the key until I’ve left.")

dialogId("up-0-1", "font_small", "No problem.")

dialogId("up-0-2", "font_small", "As soon I’ve learned to carry steel.")

dialogId("up-0-3", "font_big", "You’d better learn quickly.")


dialogId("up-1-0", "font_big", "Please hold the key this time.")

dialogId("up-1-1", "font_small", "I’ll try.")


dialogId("down-0-0", "font_big", "No! The door closed again.")

dialogId("down-0-1", "font_small", "So open it again.")


dialogId("down-1-0", "font_big", "Grmbl...")

dialogId("down-1-1", "font_small", "Stay calm. We’ll get it soon.")

