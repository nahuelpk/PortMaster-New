
dialogId("kd-uvod", "font_white", "Good morning, fish. This is an affair of the gravest importance and so we have chosen you, our ablest underwater agents.")
dialogStr("Guten Morgen Fische. Dies ist eine Angelegenheit von grösster Wichtigkeit. Deshalb haben haben wir euch ausgewählt, unsrere fähigsten Unterwasser-Agenten.")


dialogId("kd-ufo", "font_white", "Agents of FDTO - Fish Detective Training Organization - managed to get hold of several amateur snapshots of an extraterrestrial object which has crashed somewhere in your vicinity. Your mission, if you choose to accept it, will be to recover the UFO and acquire all the information you can about the principles and nature of interstellar propulsion.")
dialogStr("Agenten der FDTO (Fisch Detektiv Training Organisation) - haben es geschafft, einige Amateurfotos eines ausserirdischen Objektes in die Hände zu bekommen, dass irgendwo in unserer Nähe abgestürzt ist. Eure Aufgabe wird sein, wenn ihr sie annehmt, das UFO ausfindig zu machen und alle Informationen über die Prinzipien und die Natur des interstellaren Antriebs zu sammeln.")


dialogId("kd-mesto", "font_white", "You should also try to close some of our as yet unsolved cases. We are mostly interested in the circumstances surrounding the sinking of the mythical city, by chance in the same area.")
dialogStr("Ihr solltet auch versuchen, einige unserer ungelösten Fälle abzuschliessen. Wir sind sehr an den Umständen des Untergangs der sagenumwobenen Stadt interessiert, die sich zufälligerweise in der gleichen Gegend befindet.")

