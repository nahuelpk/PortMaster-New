
dialogId("kuf-v-noco", "font_big", "You know there’s nothing we can do about it.")
dialogStr("Du weisst, wir können nichts dagegen tun.")


dialogId("help13", "font_small", "And unlike my bigger partner, I can’t move or even carry steel objects.")
dialogStr("Und im Gegensatz zu meinem grösseren Partner kann ich keine Gegenstände aus Stahl bewegen oder sogar tragen.")

