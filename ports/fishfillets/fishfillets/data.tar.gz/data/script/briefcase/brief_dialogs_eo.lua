-- FIXME adascor
dialogId("kd-uvod", "font_white", "Good morning, fish. This is an affair of the gravest importance and so we have chosen you, our ablest underwater agents.")
dialogStr("Bonan matenon, fiŝoj. La afero estas tre grava, tial ni elektis vin, kiujn estas plej bonaj subakvaj agentoj.")

dialogId("kd-ufo", "font_white", "Agents of FDTO - Fish Detective Training Organization - managed to get hold of several amateur snapshots of an extraterrestrial object which has crashed somewhere in your vicinity. Your mission, if you choose to accept it, will be to recover the UFO and acquire all the information you can about the principles and nature of interstellar propulsion.")
dialogStr("Agentoj de SAFD - Servo de Antaŭpreparo de FiŝDetectivoj - faris kelkajn amatorajn fotojn de eksterteraj objektojn, kiuj faliĝis ie en nia distrikto. Via tasko, se vi konsentos, estos trovi NeIdentigitan Flugantan Objekton kaj kolekti ĉiun eblan informaĵon pri strukturo de interstela forteca instalaĵo.")

dialogId("kd-mesto", "font_white", "You should also try to close some of our as yet unsolved cases. We are mostly interested in the circumstances surrounding the sinking of the mythical city, by chance in the same area.")
dialogStr("Ankaŭ vi devos provi disfaldi ankoraŭ kelkaj interesantaj nin demandoj. Nin interesas ĉefe adjektoj, ĉe kiu dronis mita urbo, estanta en tio ĉi distrikto.")

dialogId("kd-bermudy", "font_white", "This case may be connected to the mystery of the Bermuda Triangle. Find out why so many ships and planes have disappeared in this area over the past several decades.")
dialogStr("Eble, tio ĉi kiel lige kun Bermuda triangulo. Klarigu, kial en tio ĉi distrikto dum lastaj jardekoj neniiĝis tre multe ŝipoj kaj aviadiloj.")

dialogId("kd-silver", "font_white", "One of the lost ships is rumored to have belonged to the legendary Captain Silver. There are still many uncertainties surrounding this famous pirate. Most of all we are interested in the map which shows the location of his buried treasure.")
dialogStr("Unu el malaperintaj ŝipoj apartenis al legenda kapitano Silver. Nun historion de fama pirato ĉirkaŭigas multe misteroj. Ĉefe nin interesas mapo, en kiu oni markas sidejon de kaŝitaj liaj trezoroj.")

dialogId("kd-pocitac", "font_white", "One of your most important tasks is to find the computer hidden in the deep by a certain criminal organization. It contains data about a project which could change the entire world.")
dialogStr("Unu el viaj plej gravaj taskoj estas trovi komputilon, kiun estas kaŝita en profundeco de oceano per ia kriminala organizacio. Li havas datumon pri projekto, kiu povas ŝanĝi tutan mandon.")

dialogId("kd-zelva", "font_white", "You should also find and detain the mysterious coral turtle. It escaped from the FDTO interrogation facility. It is not armed, but it supposedly has telepathic abilities.")
dialogStr("Ankaŭ vi devas trovi enigman koralan testudon, kiu forkuras el SAFТ. Ĝi estas nearmita, sed supozeble havas telepatiajn potencojn.")

dialogId("kd-elektr", "font_white", "We have been notified that a certain nuclear power plant has been dumping its radioactive waste illegally. Check it out.")
dialogStr("Oni informas nin, ke ia atoma elektrejo neleĝe elĵetas radioaktivajn restaĵojn en maro. Kontrolu la inaormaĵon.")

dialogId("kd-gral", "font_white", "And don’t forget to find the holy grail.")
dialogStr("Kaj ne forgesu trovi sanktan Graalon.")

dialogId("kd-zaver", "font_white", "And as usual: If anyone from your team is injured or killed, Altar will deny any knowledge of your existence and the level will be restarted.")
dialogStr("Ankaŭ, se iu el vi pereos, nivelo restartos.")

dialogId("kd-znici", "font_white", "This disk will self-destruct in five seconds.")
dialogStr("La disko neniiĝos aŭtomate post kvin sekundoj.")
