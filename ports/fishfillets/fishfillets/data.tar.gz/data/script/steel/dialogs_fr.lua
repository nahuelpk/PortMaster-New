
dialogId("steel-m-0", "font_small", "It’s so quiet here...")
dialogStr("C'est si calme ici...")


dialogId("steel-m-1", "font_small", "Boy is it quiet...")
dialogStr("Qu'est-ce que c'est calme...")

