
dialogId("steel-m-0", "font_small", "It’s so quiet here...")
dialogStr("Het is hier zo stil...")


dialogId("steel-m-1", "font_small", "Boy is it quiet...")
dialogStr("Jeetje, wat is het stil...")

