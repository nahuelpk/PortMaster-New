
dialogId("steel-m-0", "font_small", "It’s so quiet here...")

dialogId("steel-m-1", "font_small", "Boy is it quiet...")

dialogId("steel-x-redalert", "", "")
