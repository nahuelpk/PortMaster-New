
dialogId("steel-m-0", "font_small", "It’s so quiet here...")
dialogStr("Här är det tyst...")


dialogId("steel-m-1", "font_small", "Boy is it quiet...")
dialogStr("Jösses, här är det tyst...")

