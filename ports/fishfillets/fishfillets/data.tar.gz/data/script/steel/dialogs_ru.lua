-- FIXME. speel
dialogId("steel-m-0", "font_small", "It’s so quiet here...")
dialogStr("Здесь так тихо...")

dialogId("steel-m-1", "font_small", "Boy is it quiet...")
dialogStr("Какая тишина...")

dialogId("steel-x-redalert", "", "")
dialogStr("")

