
dialogId("win-m-costim1", "font_small", "What if we try to minimize the biggest windows?")
dialogStr("Wollen wir versuchen, die grössten Fenster zu schliessen?")


dialogId("win-m-costim2", "font_small", "What if we try to close some of these windows?")
dialogStr("Wollen wir versuchen, einige der Fenster zu schliessen?")


dialogId("win-v-citim", "font_big", "So we’ll go on strike. Personally, I fully sympathize with the bigger fish inside.")
dialogStr("Also streiken wir. Ich persönlich fühle übrigens sehr mit dem grösseren Fisch da drin.")

