
dialogId("win-v-plocha", "font_big", "This is how it looks when you don’t keep your desktop tidy.")
dialogStr("Zo ziet het eruit als je je desktop niet netjes houdt.")


dialogId("win-m-costim0", "font_small", "Wouldn’t it help us if we select Desktop/Line up Icons?")
dialogStr("Zou het helpen als we op Desktop/Line up Icons klikken?")


dialogId("win-m-costim1", "font_small", "What if we try to minimize the biggest windows?")
dialogStr("Zullen we proberen de grootste vensters te verkleinen?")


dialogId("win-m-costim2", "font_small", "What if we try to close some of these windows?")
dialogStr("Zullen we proberen wat van deze vensters te sluiten?")


dialogId("win-m-costim3", "font_small", "What about shutting down the whole thing and switching to command prompt only?")
dialogStr("Wat dacht je van alles afsluiten en command.com draaien?")


dialogId("win-m-costim4", "font_small", "What about giving up altogether and swimming to the pub instead?")
dialogStr("Wat dacht je van opgeven en een behoorlijk OS installeren?")


dialogId("win-v-pocitala", "font_big", "Did you count these windows around us?")
dialogStr("Heb je geteld hoeveel vensters er om ons heen zijn?")


dialogId("win-m-nemusim", "font_small", "I don’t need to count them. There are ninety five of them.")
dialogStr("Die hoef ik niet te tellen, het zijn er vijfennegentig.")


dialogId("win-m-blok", "font_small", "Can you see that Notepad? Now is a good time to send a message to the player!")
dialogStr("Zie je dat schrijfblok? Dat is onze kans om een berichtje achter te laten voor de speler!")


dialogId("win-v-premyslej", "font_big", "Stop that folly and try to think instead.")
dialogStr("Hou op met onzin spuien en denk na over ons dilemma.")


dialogId("win-m-dira", "font_small", "This system has to have a hole somewhere.")
dialogStr("Er zit vast ergens een gat in dit systeem.")


dialogId("win-v-tamhle", "font_big", "Sure. It’s in the lower right corner.")
dialogStr("Natuurlijk, rechtsonder.")


dialogId("win-m-okno", "font_small", "Can you see that big window on the right?!")
dialogStr("Zie je dat grote venster rechts?!")


dialogId("win-v-hra", "font_big", "Oh, no! That must be the original version of this game.")
dialogStr("O, nee! Dat is vast de orginele versie van dit spel.")


dialogId("win-m-chodila", "font_small", "It ran on the antediluvial machines, in standard VGA resolution...")
dialogStr("Het liep op antieke krakbakken, in standaard VGA resolutie...")


dialogId("win-v-nic0", "font_big", "No animation...")
dialogStr("Geen animaties...")


dialogId("win-m-nic1", "font_small", "No talking...")
dialogStr("Geen tekst...")


dialogId("win-v-nic2", "font_big", "No music...")
dialogStr("Geen muziekjes...")


dialogId("win-m-nic3", "font_small", "Only a beep from time to time...")
dialogStr("Alleen af en toe een piepje...")


dialogId("win-v-hav", "font_big", "But fortunately the authors got back to it and gave it this modern facelift.")
dialogStr("Maar gelukkig hebben de makers het een moderne facelift gegeven.")


dialogId("win-m-zahrat", "font_small", "But I’d like to play it sometime, anyway!")
dialogStr("Maar ik wil het wel graag een keertje spelen, hoor!")


dialogId("win-m-vga", "font_small", "I can’t move this window. Down there, it’s a steel cylinder, though it’s only in sixteen color VGA.")
dialogStr("Ik kan dit venster niet bewegen. Daar beneden zit een stalen cylinder, ook al is het maar in zestien-kleuren VGA.")


dialogId("win-v-pockej", "font_big", "Wait a moment, player. We have to make something clear. These two fish, they are our younger selves.")
dialogStr("Momentje, speler. We moeten even iets uitleggen. Deze twee vissen, dat zijn wij zelf toen we jong waren.")


dialogId("win-m-zavrene", "font_small", "You are right. They are trapped there, poor souls.")
dialogStr("Je hebt gelijk. We zitten daar opgesloten. Arme wij.")


dialogId("win-v-osvobodit", "font_big", "We can’t leave them there. We have to get them out!")
dialogStr("We kunnen ze zo niet achterlaten. We moeten ze daar uit zien te krijgen!")


dialogId("win-m-ven", "font_small", "Yes, but the player has to get us out.")
dialogStr("Ja, maar de speler moet ons eruit redden.")


dialogId("win-v-citim", "font_big", "So we’ll go on strike. Personally, I fully sympathize with the bigger fish inside.")
dialogStr("Dan gaan we staken. Ik voel persoonlijk enorm mee met die grote vis daar.")


dialogId("win-m-vzit", "font_small", "You’re right. I can imagine what the smaller one feels.")
dialogStr("Je hebt gelijk. Ik kan me ook goed voorstellen hoe die kleine vis zich voelt.")


dialogId("win-v-nehrajem", "font_big", "We are not going to play, until you save those two, player.")
dialogStr("Speler, we gaan pas weer verder als jij die twee daar gered hebt.")


dialogId("win-v-real", "font_big", "Goodness, that is a realistic game!")
dialogStr("Lieve Hemel, dat is een realistisch spel!")


dialogId("win-m-jejda", "font_small", "Oh my, he took the game too seriously!")
dialogStr("O jee, hij of zij heeft het spel te serieus genomen!")

