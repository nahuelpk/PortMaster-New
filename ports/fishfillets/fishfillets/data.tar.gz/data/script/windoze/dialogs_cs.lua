
dialogId("win-v-plocha", "font_big", "This is how it looks when you don’t keep your desktop tidy.")
dialogStr("Tak to vypadá, když si někdo neudržuje na ploše pořádek.")


dialogId("win-m-costim0", "font_small", "Wouldn’t it help us if we select Desktop/Line up Icons?")
dialogStr("Hele, nepomohlo by nám, kdybychom zvolili funkci: Vyrovnat ikony?")


dialogId("win-m-costim1", "font_small", "What if we try to minimize the biggest windows?")
dialogStr("Co kdybychom zkusili ta největší okna minimalizovat?")


dialogId("win-m-costim2", "font_small", "What if we try to close some of these windows?")
dialogStr("Co kdybychom některá z těch oken zavřeli?")


dialogId("win-m-costim3", "font_small", "What about shutting down the whole thing and switching to command prompt only?")
dialogStr("Co takhle to celé vypnout a nabootovat v DOSu?")


dialogId("win-m-costim4", "font_small", "What about giving up altogether and swimming to the pub instead?")
dialogStr("Co takhle se na to vykašlat a odplavat do hospody?")


dialogId("win-v-pocitala", "font_big", "Did you count these windows around us?")
dialogStr("Počítala jsi ty okna všude kolem?")


dialogId("win-m-nemusim", "font_small", "I don’t need to count them. There are ninety five of them.")
dialogStr("To nemusím počítat. Je jich devadesát pět.")


dialogId("win-m-blok", "font_small", "Can you see that Notepad? Now is a good time to send a message to the player!")
dialogStr("Hele, vidíš ten Poznámkový blok? Vhodná chvíle poslat hráči nějaký vzkaz!")


dialogId("win-v-premyslej", "font_big", "Stop that folly and try to think instead.")
dialogStr("Nech těch hloupostí a raději přemýšlej.")


dialogId("win-m-dira", "font_small", "This system has to have a hole somewhere.")
dialogStr("Někde ten systém přece musí mít díru.")


dialogId("win-v-tamhle", "font_big", "Sure. It’s in the lower right corner.")
dialogStr("Jistě, támhle vpravo dole.")


dialogId("win-m-okno", "font_small", "Can you see that big window on the right?!")
dialogStr("Vidíš to velké okno napravo?!")


dialogId("win-v-hra", "font_big", "Oh, no! That must be the original version of this game.")
dialogStr("No to snad ne! To je původní verze této hry.")


dialogId("win-m-chodila", "font_small", "It ran on the antediluvial machines, in standard VGA resolution...")
dialogStr("Ta chodila na předpotopních mašinách, ve standardním VGA rozlišení...")


dialogId("win-v-nic0", "font_big", "No animation...")
dialogStr("Žádné animace...")


dialogId("win-m-nic1", "font_small", "No talking...")
dialogStr("Žádné namluvené texty...")


dialogId("win-v-nic2", "font_big", "No music...")
dialogStr("Žádná hudba...")


dialogId("win-m-nic3", "font_small", "Only a beep from time to time...")
dialogStr("Jen sem tam nějaké pípnutí...")


dialogId("win-v-hav", "font_big", "But fortunately the authors got back to it and gave it this modern facelift.")
dialogStr("Ještě, že se k ní autoři po létech vrátili a dali jí tento moderní háv.")


dialogId("win-m-zahrat", "font_small", "But I’d like to play it sometime, anyway!")
dialogStr("Stejně bych si to někdy zkusila zahrát!")


dialogId("win-m-vga", "font_small", "I can’t move this window. Down there, it’s a steel cylinder, though it’s only in sixteen color VGA.")
dialogStr("Já s tímhle oknem nepohnu. Támhle dole, to je ocelový válec, i když jen v šestnáctibarevném VGA.")


dialogId("win-v-pockej", "font_big", "Wait a moment, player. We have to make something clear. These two fish, they are our younger selves.")
dialogStr("Počkej, hráči. Musím si něco ujasnit. Támhle ty dvě rybičky, to jsme přece my zamlada.")


dialogId("win-m-zavrene", "font_small", "You are right. They are trapped there, poor souls.")
dialogStr("Máš pravdu. Jsou tam chudinky zavřené.")


dialogId("win-v-osvobodit", "font_big", "We can’t leave them there. We have to get them out!")
dialogStr("Přece je tam nenecháme! Musíme je osvobodit.")


dialogId("win-m-ven", "font_small", "Yes, but the player has to get us out.")
dialogStr("No jo, ale hráč má za úkol dostat ven nás.")


dialogId("win-v-citim", "font_big", "So we’ll go on strike. Personally, I fully sympathize with the bigger fish inside.")
dialogStr("Tak budeme stávkovat. Já osobně plně cítím s tou velkou rybičkou uvnitř.")


dialogId("win-m-vzit", "font_small", "You’re right. I can imagine what the smaller one feels.")
dialogStr("Máš pravdu. Já se také dokážu vžít do té malé.")


dialogId("win-v-nehrajem", "font_big", "We are not going to play, until you save those two, player.")
dialogStr("Dál nehrajeme, dokud ty dvě nezachráníš, hráči.")


dialogId("win-v-real", "font_big", "Goodness, that is a realistic game!")
dialogStr("Hergot, to je ale realistická hra!")


dialogId("win-m-jejda", "font_small", "Oh my, he took the game too seriously!")
dialogStr("Jejda, ten se do toho nějak vžil!")

