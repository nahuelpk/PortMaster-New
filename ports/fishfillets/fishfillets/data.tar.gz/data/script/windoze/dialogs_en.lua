
dialogId("win-v-plocha", "font_big", "This is how it looks when you don’t keep your desktop tidy.")

dialogId("win-m-costim0", "font_small", "Wouldn’t it help us if we select Desktop/Line up Icons?")

dialogId("win-m-costim1", "font_small", "What if we try to minimize the biggest windows?")

dialogId("win-m-costim2", "font_small", "What if we try to close some of these windows?")

dialogId("win-m-costim3", "font_small", "What about shutting down the whole thing and switching to command prompt only?")

dialogId("win-m-costim4", "font_small", "What about giving up altogether and swimming to the pub instead?")

dialogId("win-v-pocitala", "font_big", "Did you count these windows around us?")

dialogId("win-m-nemusim", "font_small", "I don’t need to count them. There are ninety five of them.")

dialogId("win-m-blok", "font_small", "Can you see that Notepad? Now is a good time to send a message to the player!")

dialogId("win-v-premyslej", "font_big", "Stop that folly and try to think instead.")

dialogId("win-m-dira", "font_small", "This system has to have a hole somewhere.")

dialogId("win-v-tamhle", "font_big", "Sure. It’s in the lower right corner.")

dialogId("win-m-okno", "font_small", "Can you see that big window on the right?!")

dialogId("win-v-hra", "font_big", "Oh, no! That must be the original version of this game.")

dialogId("win-m-chodila", "font_small", "It ran on the antediluvial machines, in standard VGA resolution...")

dialogId("win-v-nic0", "font_big", "No animation...")

dialogId("win-m-nic1", "font_small", "No talking...")

dialogId("win-v-nic2", "font_big", "No music...")

dialogId("win-m-nic3", "font_small", "Only a beep from time to time...")

dialogId("win-v-hav", "font_big", "But fortunately the authors got back to it and gave it this modern facelift.")

dialogId("win-m-zahrat", "font_small", "But I’d like to play it sometime, anyway!")

dialogId("win-m-vga", "font_small", "I can’t move this window. Down there, it’s a steel cylinder, though it’s only in sixteen color VGA.")

dialogId("win-v-pockej", "font_big", "Wait a moment, player. We have to make something clear. These two fish, they are our younger selves.")

dialogId("win-m-zavrene", "font_small", "You are right. They are trapped there, poor souls.")

dialogId("win-v-osvobodit", "font_big", "We can’t leave them there. We have to get them out!")

dialogId("win-m-ven", "font_small", "Yes, but the player has to get us out.")

dialogId("win-v-citim", "font_big", "So we’ll go on strike. Personally, I fully sympathize with the bigger fish inside.")

dialogId("win-m-vzit", "font_small", "You’re right. I can imagine what the smaller one feels.")

dialogId("win-v-nehrajem", "font_big", "We are not going to play, until you save those two, player.")

dialogId("win-v-real", "font_big", "Goodness, that is a realistic game!")

dialogId("win-m-jejda", "font_small", "Oh my, he took the game too seriously!")
