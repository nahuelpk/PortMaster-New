
dialogId("win-v-plocha", "font_big", "This is how it looks when you don’t keep your desktop tidy.")
dialogStr("Tak to wygląda, jeśli nie utrzymujesz porządku na swoim pulpicie.")


dialogId("win-m-costim0", "font_small", "Wouldn’t it help us if we select Desktop/Line up Icons?")
dialogStr("Może skorzystamy z opcji ’Porządkuj ikony’?")


dialogId("win-m-costim1", "font_small", "What if we try to minimize the biggest windows?")
dialogStr("Może spróbujemy zminimalizować największe okna?")


dialogId("win-m-costim2", "font_small", "What if we try to close some of these windows?")
dialogStr("Może zamkniemy klika okienek?")


dialogId("win-m-costim3", "font_small", "What about shutting down the whole thing and switching to command prompt only?")
dialogStr("A może wyłączymy całe to pieroństwo i uruchomimy w trybie MS DOS?")


dialogId("win-m-costim4", "font_small", "What about giving up altogether and swimming to the pub instead?")
dialogStr("A może damy sobie z tym spokój i popłyniemy do baru?")


dialogId("win-v-pocitala", "font_big", "Did you count these windows around us?")
dialogStr("Policzyłaś te okienka?")


dialogId("win-m-nemusim", "font_small", "I don’t need to count them. There are ninety five of them.")
dialogStr("Po co? Jest ich dziewięćdziesiąt pięć.")


dialogId("win-m-blok", "font_small", "Can you see that Notepad? Now is a good time to send a message to the player!")
dialogStr("Zobacz, Notatnik! Napiszę coś do gracza!")


dialogId("win-v-premyslej", "font_big", "Stop that folly and try to think instead.")
dialogStr("Daj temu spokój i myśl jak się stąd wydostać.")


dialogId("win-m-dira", "font_small", "This system has to have a hole somewhere.")
dialogStr("Ten system musi mieć jakąś dziurę.")


dialogId("win-v-tamhle", "font_big", "Sure. It’s in the lower right corner.")
dialogStr("Jasne. Tam, po prawej.")


dialogId("win-m-okno", "font_small", "Can you see that big window on the right?!")
dialogStr("Widzisz to duże okno po prawej?!")


dialogId("win-v-hra", "font_big", "Oh, no! That must be the original version of this game.")
dialogStr("No ładnie! To zapewne oryginalna wersja tej gry.")


dialogId("win-m-chodila", "font_small", "It ran on the antediluvial machines, in standard VGA resolution...")
dialogStr("Działała na przedpotopowych komputerach, w standardowej rozdzielczości VGA...")


dialogId("win-v-nic0", "font_big", "No animation...")
dialogStr("Żadnych animacji...")


dialogId("win-m-nic1", "font_small", "No talking...")
dialogStr("Bez tekstów mówionych...")


dialogId("win-v-nic2", "font_big", "No music...")
dialogStr("Bez muzyki...")


dialogId("win-m-nic3", "font_small", "Only a beep from time to time...")
dialogStr("Tylko od czasu do czasu coś zapipczało...")


dialogId("win-v-hav", "font_big", "But fortunately the authors got back to it and gave it this modern facelift.")
dialogStr("Na szczęście autorzy wrócili do projektu i nadali mu całkiem nowy wygląd.")


dialogId("win-m-zahrat", "font_small", "But I’d like to play it sometime, anyway!")
dialogStr("Ja bym jeszcze czasem w nią zagrała...")


dialogId("win-m-vga", "font_small", "I can’t move this window. Down there, it’s a steel cylinder, though it’s only in sixteen color VGA.")
dialogStr("Nie mogę ruszyć tego okna. Tam na dole jest stalowa rura, nawet jeśli tylko w 16 kolorach.")


dialogId("win-v-pockej", "font_big", "Wait a moment, player. We have to make something clear. These two fish, they are our younger selves.")
dialogStr("Chwila, moment. Graczu, musimy sobie coś wyjaśnić. Te dwie ryby to przecież my w młodości.")


dialogId("win-m-zavrene", "font_small", "You are right. They are trapped there, poor souls.")
dialogStr("Masz rację. Bidulki, zamknięte w tym okienku.")


dialogId("win-v-osvobodit", "font_big", "We can’t leave them there. We have to get them out!")
dialogStr("Przecież ich tak nie zostawimy! Musimy je uwolnić!")


dialogId("win-m-ven", "font_small", "Yes, but the player has to get us out.")
dialogStr("No tak, ale gracz musi uwolnić nas.")


dialogId("win-v-citim", "font_big", "So we’ll go on strike. Personally, I fully sympathize with the bigger fish inside.")
dialogStr("No to strajkujemy! Ja się w pełni solidaryzuję z tą dużą rybą w środku.")


dialogId("win-m-vzit", "font_small", "You’re right. I can imagine what the smaller one feels.")
dialogStr("Racja. Wyobrażam sobie, co ta mała musi czuć.")


dialogId("win-v-nehrajem", "font_big", "We are not going to play, until you save those two, player.")
dialogStr("Dalej nie płyniemy, póki nie uwolnisz tych dwóch.")


dialogId("win-v-real", "font_big", "Goodness, that is a realistic game!")
dialogStr("Rany, co za realistyczna gra!")


dialogId("win-m-jejda", "font_small", "Oh my, he took the game too seriously!")
dialogStr("Chyba wziął tę grę na poważnie...")

