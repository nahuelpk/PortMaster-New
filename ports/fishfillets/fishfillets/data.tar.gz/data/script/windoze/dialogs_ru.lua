--FIXME, ada
dialogId("win-v-plocha", "font_big", "This is how it looks when you don’t keep your desktop tidy.")
dialogStr("Вот что получается, когда вы не поддерживаете на рабочем столе порядок.")

dialogId("win-m-costim0", "font_small", "Wouldn’t it help us if we select Desktop/Line up Icons?")
dialogStr("Неужели не поможет, если мы выберем Рабочий стол/Упорядочить значки?")

dialogId("win-m-costim1", "font_small", "What if we try to minimize the biggest windows?")
dialogStr("Что, если мы попробуем минимизировать самые большие окна?")

dialogId("win-m-costim2", "font_small", "What if we try to close some of these windows?")
dialogStr("А давай попробуем закрыть несколько окон?")

dialogId("win-m-costim3", "font_small", "What about shutting down the whole thing and switching to command prompt only?")
dialogStr("А что, если мы закроем все это и будем пользоваться только командной строкой?")

dialogId("win-m-costim4", "font_small", "What about giving up altogether and swimming to the pub instead?")
dialogStr("Как насчет того, чтобы бросить все и вместо этого поплыть к бару?")

dialogId("win-v-pocitala", "font_big", "Did you count these windows around us?")
dialogStr("Ты посчитала все окна вокруг нас?")

dialogId("win-m-nemusim", "font_small", "I don’t need to count them. There are ninety five of them.")
dialogStr("Мне не надо их считать, их девяносто пять.")

dialogId("win-m-blok", "font_small", "Can you see that Notepad? Now is a good time to send a message to the player!")
dialogStr("Ты видишь Блокнот? Сейчас самое время отправить сообщение игроку!")

dialogId("win-v-premyslej", "font_big", "Stop that folly and try to think instead.")
dialogStr("Останови это безумие, и давай вместе подумаем.")

dialogId("win-m-dira", "font_small", "This system has to have a hole somewhere.")
dialogStr("Эта система должна иметь где-то дыру.")

dialogId("win-v-tamhle", "font_big", "Sure. It’s in the lower right corner.")
dialogStr("Конечно, она в правом нижнем углу.")

dialogId("win-m-okno", "font_small", "Can you see that big window on the right?!")
dialogStr("Ты видишь это большое окно справа?!")

dialogId("win-v-hra", "font_big", "Oh, no! That must be the original version of this game.")
dialogStr("О, нет! Это, должно быть, оригинальная версия этой игры.")

dialogId("win-m-chodila", "font_small", "It ran on the antediluvial machines, in standard VGA resolution...")
dialogStr("Она шла на старомодных машинах, в стандартном разрешении VGA...")

dialogId("win-v-nic0", "font_big", "No animation...")
dialogStr("Никакой мультипликации...")

dialogId("win-m-nic1", "font_small", "No talking...")
dialogStr("Без подсказок...")

dialogId("win-v-nic2", "font_big", "No music...")
dialogStr("Без музыки...")

dialogId("win-m-nic3", "font_small", "Only a beep from time to time...")
dialogStr("Только <бип> время от времени...")

dialogId("win-v-hav", "font_big", "But fortunately the authors got back to it and gave it this modern facelift.")
dialogStr("К счастью, авторы вернулись к этому и обновили ее.")

dialogId("win-m-zahrat", "font_small", "But I’d like to play it sometime, anyway!")
dialogStr("Но я все равно не хочу играть в нее!")

dialogId("win-m-vga", "font_small", "I can’t move this window. Down there, it’s a steel cylinder, though it’s only in sixteen color VGA.")
dialogStr("Я не могу переместить это окно. Там внизу стальной цилиндр, хотя он  только в 16-битном VGA.")

dialogId("win-v-pockej", "font_big", "Wait a moment, player. We have to make something clear. These two fish, they are our younger selves.")
dialogStr("Один момент, игрок. Нам надо разобраться. Эти рыбы - это  мы, только молодые .")

dialogId("win-m-zavrene", "font_small", "You are right. They are trapped there, poor souls.")
dialogStr("Ты прав. Они оказались там, бедные души.")

dialogId("win-v-osvobodit", "font_big", "We can’t leave them there. We have to get them out!")
dialogStr("Мы не можем оставить их там. Мы должны вывести их!")

dialogId("win-m-ven", "font_small", "Yes, but the player has to get us out.")
dialogStr("Да, но игрок должен вывести нас.")

dialogId("win-v-citim", "font_big", "So we’ll go on strike. Personally, I fully sympathize with the bigger fish inside.")
dialogStr("Тогда мы объявляем забастовку. Лично я сочувствую той большой рыбе.")

dialogId("win-m-vzit", "font_small", "You’re right. I can imagine what the smaller one feels.")
dialogStr("Ты прав. Могу представить, что чувствует маленькая.")

dialogId("win-v-nehrajem", "font_big", "We are not going to play, until you save those two, player.")
dialogStr("Эй, игрок! Мы не будем играть, пока вы держите тех двух.")

dialogId("win-v-real", "font_big", "Goodness, that is a realistic game!")
dialogStr("Господи, это реальная игра!")

dialogId("win-m-jejda", "font_small", "Oh my, he took the game too seriously!")
dialogStr("Ох, он отнесся к игре не слишком серьезно!")

