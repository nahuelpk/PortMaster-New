
dialogId("poster1", "font_poster", "When we saw the linux users we didn’t know what we should do with them. We didn’t understand why we got them and it seemed they would never agree with each other. But finally we got them to calm down, by confronting them with a windows user. From then on they kept the motto: Gentoo or Mandriva, we’re all one family.")
dialogStr("Als wir die Linuxbenutzer sahen wußten wir nicht, was wir mit ihnen machen sollten. Wir haben sie nicht verstanden und es schien unmöglich, daß sie sich aussöhnen würden. Aber schlußendlich haben wir einen Windowsbenutzer zu ihnen gebracht. Danach hielten sich sich an das Motto: Gentoo oder Mandriva, wir sind alle eine Familie.")

dialogId("poster2", "font_poster", "Although you didn’t solve any problem which we assigned to you I wouldn’t have left them in one game together either and they are quite useful here.")
dialogStr("Du hast zwar kein Problem gelöst, was wir dir zugewiesen haben, aber ich hätte sie auch nicht in einem Spiel gelassen und hier sind sie recht nützlich.")
