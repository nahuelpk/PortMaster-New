
dialogId("poster1", "font_poster", "When we saw the linux users we didn’t know what we should do with them. We didn’t understand why we got them and it seemed they would never agree with each other. But finally we got them to calm down, by confronting them with a windows user. From then on they kept the motto: Gentoo or Mandriva, we’re all one family.")
dialogStr("När vi såg linuxanvändarna visste vi inte vad vi skulle göra med dem. Vi visste inte varför vi fick dem och det verkade som om det var omöjligt att få dem att komma överens med varandra. Men till slut lyckades vi lugna ner dem, vi satte en windowsanvändare bredvid dem. Sen dess har de hållit måttot: Gentoo eller Mandriva, vi är alla en familj.")

dialogId("poster2", "font_poster", "Although you didn’t solve any problem which we assigned to you I wouldn’t have left them in one game together either and they are quite useful here.")
dialogStr("Vi förstår att du tog bort dem trots att vi aldrig bad dig om det, vi hade inte heller stått ut med dem under en hel nivå. De är dessutom ganska så användbara här.")
