
dialogId("poster1", "font_poster", "When we saw the linux users we didn’t know what we should do with them. We didn’t understand why we got them and it seemed they would never agree with each other. But finally we got them to calm down, by confronting them with a windows user. From then on they kept the motto: Gentoo or Mandriva, we’re all one family.")
dialogStr("Когато видяхме линуксаджиите не знаехме какво да ги правим. Не разбрахме защо са доставени, а и изглеждаше, че никога няма да се разберат помежду си. Най-сетне ги сдобрихме като поставихме до тях един потребител на уиндоус. От тогава си имат мото: Gentoo или Mandriva, всички сме роднини.")

dialogId("poster2", "font_poster", "Although you didn’t solve any problem which we assigned to you I wouldn’t have left them in one game together either and they are quite useful here.")
dialogStr("Въпреки, че не сме ви възлагали тази задача, разбираме, че не е било възможно да ги търпите повече, а и тук са доста полезни.")
