
dialogId("poster1", "font_poster", "When we saw the linux users we didn’t know what we should do with them. We didn’t understand why we got them and it seemed they would never agree with each other. But finally we got them to calm down, by confronting them with a windows user. From then on they kept the motto: Gentoo or Mandriva, we’re all one family.")
dialogId("poster2", "font_poster", "Although you didn’t solve any problem which we assigned to you I wouldn’t have left them in one game together either and they are quite useful here.")
