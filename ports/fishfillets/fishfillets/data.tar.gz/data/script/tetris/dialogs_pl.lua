
dialogId("tet-m-vypadala", "font_small", "So this is what the most successful game of all time originally looked like.")
dialogStr("A więc tak pierwotnie wyglądała najpopularniejsza gra wszech czasów.")


dialogId("tet-v-ucta", "font_big", "Only deep respect for its memory prevents me from saying what it looks like...")
dialogStr("Tylko szacunek dla jej pamięci powstrzymuje mnie od powiedzenia, że wygląda jak...")


dialogId("tet-m-usudek", "font_small", "But everybody else can see for themselves.")
dialogStr("Tetris jaki jest, każdy widzi.")


dialogId("tet-v-myslim", "font_big", "Do you know what I have in mind?")
dialogStr("Wiesz co sobie myślę?")


dialogId("tet-m-ano", "font_small", "Well?")
dialogStr("Tak?")


dialogId("tet-v-lepsi", "font_big", "I think we could do a better tetris than this room.")
dialogStr("Myślę sobie, że potrafilibyśmy zrobić lepszy tetris, niż ten tutaj.")


dialogId("tet-m-jaklepsi", "font_small", "What do you mean, better?")
dialogStr("Co masz na myśli?")


dialogId("tet-v-hybat", "font_big", "At least, you won’t have to move all the pieces to the right.")
dialogStr("No, przynajmniej o tyle, że nie trzeba by było przesuwać wszystkich klocków w prawo.")


dialogId("tet-m-predmety", "font_small", "The truth is we have an ample supply of suitable objects here.")
dialogStr("Prawdą jest, że mamy tu obszerny wybór elementów.")


dialogId("tet-v-uprava", "font_big", "I think a little patch of code could give the player the possibility to enjoy some original tetris.")
dialogStr("Pewnie wystarczyłaby mała poprawka kodu, żeby gracz mógł nacieszyć się oryginalnym Tetrisem.")


dialogId("tet-m-program", "font_small", "Okay, try to program it!")
dialogStr("Więc to zaprogramuj.")


dialogId("tet-m-pozor", "font_small", "Be careful not to hurt us.")
dialogStr("Uważaj, żebyś nie zrobił nam krzywdy.")


dialogId("tet-v-kostky", "font_big", "We will have to stack these pieces more efficiently, perhaps.")
dialogStr("Chyba będziemy musieli upchnąć te elementy nieco ciaśniej.")


dialogId("tet-m-lepe", "font_small", "Hmm... I should have arranged it better.")
dialogStr("Hmmm... powinnam była lepiej to ułożyć.")

