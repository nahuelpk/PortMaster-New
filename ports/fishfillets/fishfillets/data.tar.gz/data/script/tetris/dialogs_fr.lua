
dialogId("tet-m-vypadala", "font_small", "So this is what the most successful game of all time originally looked like.")
dialogStr("Donc, voici à quoi ressemblait le jeu le plus populaire de tous les temps.")


dialogId("tet-v-ucta", "font_big", "Only deep respect for its memory prevents me from saying what it looks like...")
dialogStr("C'est par respect pour sa mémoire que je préfère ne pas dire à quoi il ressemble.")


dialogId("tet-m-usudek", "font_small", "But everybody else can see for themselves.")
dialogStr("Mais tout le monde peut s'en rendre compte.")


dialogId("tet-v-myslim", "font_big", "Do you know what I have in mind?")
dialogStr("Sais-tu ce que j'ai en tête ?")


dialogId("tet-m-ano", "font_small", "Well?")
dialogStr("Et bien ?")


dialogId("tet-v-lepsi", "font_big", "I think we could do a better tetris than this room.")
dialogStr("Je pense que nous pouvons faire un meilleur tetris que ça.")


dialogId("tet-m-jaklepsi", "font_small", "What do you mean, better?")
dialogStr("Qu'entends-tu par meilleur ?")


dialogId("tet-v-hybat", "font_big", "At least, you won’t have to move all the pieces to the right.")
dialogStr("Au moins, tu n'auras pas à pousser toutes les pièces sur la droite.")


dialogId("tet-m-predmety", "font_small", "The truth is we have an ample supply of suitable objects here.")
dialogStr("En vérité, nous avons largement tout ce dont nous avons besoin.")


dialogId("tet-v-uprava", "font_big", "I think a little patch of code could give the player the possibility to enjoy some original tetris.")
dialogStr("Je pense qu'un petit bout de code permettrait au joueur d'apprécier le tetris original.")


dialogId("tet-m-program", "font_small", "Okay, try to program it!")
dialogStr("Ok, essaie de le programmer.")


dialogId("tet-m-pozor", "font_small", "Be careful not to hurt us.")
dialogStr("Fais attention, nous sommes fragiles.")


dialogId("tet-v-kostky", "font_big", "We will have to stack these pieces more efficiently, perhaps.")
dialogStr("Nous devons ranger ces pièces de manière plus efficace, peut-être.")


dialogId("tet-m-lepe", "font_small", "Hmm... I should have arranged it better.")
dialogStr("Hum... Je devrais mieux empiler ça.")

