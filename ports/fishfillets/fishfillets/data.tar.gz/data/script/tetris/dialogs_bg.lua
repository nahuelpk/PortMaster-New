dialogId("tet-m-vypadala", "font_small", "So this is what the most successful game of all time originally looked like.")
dialogStr("Значи така е изглеждала първоначално най-успешната игра за всички времена.")

dialogId("tet-v-ucta", "font_big", "Only deep respect for its memory prevents me from saying what it looks like...")
dialogStr("Само дълбоката ми почит към паметта ѝ ми пречи да кажа на какво прилича...")

dialogId("tet-m-usudek", "font_small", "But everybody else can see for themselves.")
dialogStr("Но всеки може да види сам.")

dialogId("tet-v-myslim", "font_big", "Do you know what I have in mind?")
dialogStr("Знаеш ли какво си  мисля?")

dialogId("tet-m-ano", "font_small", "Well?")
dialogStr("Какво?")

dialogId("tet-v-lepsi", "font_big", "I think we could do a better tetris than this room.")
dialogStr("Мисля, че ние можем да направим по-добър тетрис от тази стая.")

dialogId("tet-m-jaklepsi", "font_small", "What do you mean, better?")
dialogStr("Какво имаш предвид под по-добър?")

dialogId("tet-v-hybat", "font_big", "At least, you won’t have to move all the pieces to the right.")
dialogStr("Ами поне нямаше да ни се налага да избутваме всички парчета вдясно.")

dialogId("tet-m-predmety", "font_small", "The truth is we have an ample supply of suitable objects here.")
dialogStr("Истината е, че тук разполагаме с достатъчно подходящи парчета.")

dialogId("tet-v-uprava", "font_big", "I think a little patch of code could give the player the possibility to enjoy some original tetris.")
dialogStr("Мисля, че малка поправка в кода на играта може да даде на играча възможността да се забавлява с оригинален тетрис.")

dialogId("tet-m-program", "font_small", "Okay, try to program it!")
dialogStr("Добре, опитай да програмираш поправката!")

dialogId("tet-m-pozor", "font_small", "Be careful not to hurt us.")
dialogStr("Внимавай да не ни нараниш.")

dialogId("tet-v-kostky", "font_big", "We will have to stack these pieces more efficiently, perhaps.")
dialogStr("Вероятно ще трябва да подредим парчетата по-оптимално.")

dialogId("tet-m-lepe", "font_small", "Hmm... I should have arranged it better.")
dialogStr("Хм... Трябваше да ги подредя по-добре.")

