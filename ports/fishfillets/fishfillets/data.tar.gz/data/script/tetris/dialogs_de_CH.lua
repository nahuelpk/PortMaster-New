
dialogId("tet-v-myslim", "font_big", "Do you know what I have in mind?")
dialogStr("Weisst du was ich denke?")

