
dialogId("tet-m-vypadala", "font_small", "So this is what the most successful game of all time originally looked like.")

dialogId("tet-v-ucta", "font_big", "Only deep respect for its memory prevents me from saying what it looks like...")

dialogId("tet-m-usudek", "font_small", "But everybody else can see for themselves.")

dialogId("tet-v-myslim", "font_big", "Do you know what I have in mind?")

dialogId("tet-m-ano", "font_small", "Well?")

dialogId("tet-v-lepsi", "font_big", "I think we could do a better tetris than this room.")

dialogId("tet-m-jaklepsi", "font_small", "What do you mean, better?")

dialogId("tet-v-hybat", "font_big", "At least, you won’t have to move all the pieces to the right.")

dialogId("tet-m-predmety", "font_small", "The truth is we have an ample supply of suitable objects here.")

dialogId("tet-v-uprava", "font_big", "I think a little patch of code could give the player the possibility to enjoy some original tetris.")

dialogId("tet-m-program", "font_small", "Okay, try to program it!")

dialogId("tet-m-pozor", "font_small", "Be careful not to hurt us.")

dialogId("tet-v-kostky", "font_big", "We will have to stack these pieces more efficiently, perhaps.")

dialogId("tet-m-lepe", "font_small", "Hmm... I should have arranged it better.")
