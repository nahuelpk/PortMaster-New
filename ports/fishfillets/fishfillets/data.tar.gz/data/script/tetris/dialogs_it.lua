
dialogId("tet-m-vypadala", "font_small", "So this is what the most successful game of all time originally looked like.")
dialogStr("Ecco dunque come appariva originariamente il gioco più famoso di tutti i tempi.")


dialogId("tet-v-ucta", "font_big", "Only deep respect for its memory prevents me from saying what it looks like...")
dialogStr("Solo il profondo rispetto per la sua memoria mi trattiene dal dire che cosa mi sembra...")


dialogId("tet-m-usudek", "font_small", "But everybody else can see for themselves.")
dialogStr("Ma questo lo possono vedere tutti.")


dialogId("tet-v-myslim", "font_big", "Do you know what I have in mind?")
dialogStr("Sai cosa ho in menta?")


dialogId("tet-m-ano", "font_small", "Well?")
dialogStr("Ebbene?")


dialogId("tet-v-lepsi", "font_big", "I think we could do a better tetris than this room.")
dialogStr("Penso che potremmo realizzare un tetris migliore di questo.")


dialogId("tet-m-jaklepsi", "font_small", "What do you mean, better?")
dialogStr("Cosa vuoi dire, migliore?")


dialogId("tet-v-hybat", "font_big", "At least, you won’t have to move all the pieces to the right.")
dialogStr("Almeno, non dovresti spingere tutti i pezzi verso destra.")


dialogId("tet-m-predmety", "font_small", "The truth is we have an ample supply of suitable objects here.")
dialogStr("La verità e che abbiamo un'ampia varietà di pezzi adatti, qui.")


dialogId("tet-v-uprava", "font_big", "I think a little patch of code could give the player the possibility to enjoy some original tetris.")
dialogStr("Penso che una piccola patch al codice possa dare al giocatore la possibilità di godersi un po' di tetris innovativo.")


dialogId("tet-m-program", "font_small", "Okay, try to program it!")
dialogStr("Bene, inizia a programmarlo!")


dialogId("tet-m-pozor", "font_small", "Be careful not to hurt us.")
dialogStr("Stai attento a non colpirci.")


dialogId("tet-v-kostky", "font_big", "We will have to stack these pieces more efficiently, perhaps.")
dialogStr("Dovremmo accatastare meglio questi pezzi, forse.")


dialogId("tet-m-lepe", "font_small", "Hmm... I should have arranged it better.")
dialogStr("Mmm... avrei dovuti arrangiarli meglio.")

