
dialogId("tet-m-vypadala", "font_small", "So this is what the most successful game of all time originally looked like.")
dialogStr("So sah also das erfolgreichste Spiel aller Zeiten aus.")


dialogId("tet-v-ucta", "font_big", "Only deep respect for its memory prevents me from saying what it looks like...")
dialogStr("Nur der tiefe Respekt vor seinem Andenken hält mich davon ab, zu sagen wie es aussieht...")


dialogId("tet-m-usudek", "font_small", "But everybody else can see for themselves.")
dialogStr("Aber jeder kann es selbst sehen.")


dialogId("tet-v-myslim", "font_big", "Do you know what I have in mind?")
dialogStr("Weißt du was ich denke?")


dialogId("tet-m-ano", "font_small", "Well?")
dialogStr("Was?")


dialogId("tet-v-lepsi", "font_big", "I think we could do a better tetris than this room.")
dialogStr("Ich denke, wir könnten ein besseres Tetris machen, als diesen Raum.")


dialogId("tet-m-jaklepsi", "font_small", "What do you mean, better?")
dialogStr("Wie \"besser\"?")


dialogId("tet-v-hybat", "font_big", "At least, you won’t have to move all the pieces to the right.")
dialogStr("Zumindest, dass man nicht alle Teile nach rechts bewegen müsste.")


dialogId("tet-m-predmety", "font_small", "The truth is we have an ample supply of suitable objects here.")
dialogStr("Die Wahrheit ist, dass wir hier reichlich passende Teile haben.")


dialogId("tet-v-uprava", "font_big", "I think a little patch of code could give the player the possibility to enjoy some original tetris.")
dialogStr("Ich denke, dass ein kleines Programmstück dem Spieler die Möglichkeit geben kann, sich an einem Original-Tetris zu erfreuen.")


dialogId("tet-m-program", "font_small", "Okay, try to program it!")
dialogStr("Gut, versuche es zu programmieren.")


dialogId("tet-m-pozor", "font_small", "Be careful not to hurt us.")
dialogStr("Pass auf, dass du uns nicht wehtust.")


dialogId("tet-v-kostky", "font_big", "We will have to stack these pieces more efficiently, perhaps.")
dialogStr("Wir müssen die Teile wahrscheinlich effizienter stapeln.")


dialogId("tet-m-lepe", "font_small", "Hmm... I should have arranged it better.")
dialogStr("Hmm... Ich hätte es besser anordnen sollen.")

