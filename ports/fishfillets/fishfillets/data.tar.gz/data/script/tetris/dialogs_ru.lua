-- FIXME. speel
dialogId("tet-m-vypadala", "font_small", "So this is what the most successful game of all time originally looked like.")
dialogStr("Итак, эта игра оказалась очень популярной в своё время.")

dialogId("tet-v-ucta", "font_big", "Only deep respect for its memory prevents me from saying what it looks like...")
dialogStr("Только глубокое уважение к ее памяти мешает мне сказать, на что она похожа... ")   --- Глубокий респект тому, кто сможет в додуматься до решения в памяти...") --- ??? 

dialogId("tet-m-usudek", "font_small", "But everybody else can see for themselves.")
dialogStr("Но каждый еще может увидеть ее сам.") ---Но все же любой может найти решение.") -- ????

dialogId("tet-v-myslim", "font_big", "Do you know what I have in mind?")
dialogStr("Знаешь, о чем я думаю?")

dialogId("tet-m-ano", "font_small", "Well?")
dialogStr("О чем?") ---Итак?")

dialogId("tet-v-lepsi", "font_big", "I think we could do a better tetris than this room.")
dialogStr("Я думаю, мы должны улучшить тетрис здесь.")

dialogId("tet-m-jaklepsi", "font_small", "What do you mean, better?")
dialogStr("Как ты думаешь, лучше?")

dialogId("tet-v-hybat", "font_big", "At least, you won’t have to move all the pieces to the right.")
dialogStr("По крайней мере, тебе не надо передвигать элементы вправо.")   ---Не понятно, ты хочешь сдвинуть все куски в право.")

dialogId("tet-m-predmety", "font_small", "The truth is we have an ample supply of suitable objects here.")
dialogStr("Действительно, у нас есть достаточно подходящих элементов здесь.") ---Истина в том, что нужно собрать объекты достаточно аккуратно.") -- ???

dialogId("tet-v-uprava", "font_big", "I think a little patch of code could give the player the possibility to enjoy some original tetris.")
dialogStr("Я думаю, что небольшой патч к исходникам даст игроку возможность играть в оригинальный тетрис.")

dialogId("tet-m-program", "font_small", "Okay, try to program it!")
dialogStr("Хорошо, попробуй написать его!")

dialogId("tet-m-pozor", "font_small", "Be careful not to hurt us.")
dialogStr("Будь осторожен, чтобы не повредить нас.")          ---Будь аккуратнее.")

dialogId("tet-v-kostky", "font_big", "We will have to stack these pieces more efficiently, perhaps.")
dialogStr("Возможно некоторые элементы можно расположить оптимальнее.")

dialogId("tet-m-lepe", "font_small", "Hmm... I should have arranged it better.")
dialogStr("Хм... Я должна расположить это лучше.")

