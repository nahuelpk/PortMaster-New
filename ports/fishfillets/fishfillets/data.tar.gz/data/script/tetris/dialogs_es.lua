
dialogId("tet-m-vypadala", "font_small", "So this is what the most successful game of all time originally looked like.")
dialogStr("Entonces así es como se veía el juego más exitoso de todos los tiempos.")


dialogId("tet-v-ucta", "font_big", "Only deep respect for its memory prevents me from saying what it looks like...")
dialogStr("Sólo el profundo respeto a su memoria me impide decir como se ve...")


dialogId("tet-m-usudek", "font_small", "But everybody else can see for themselves.")
dialogStr("Pero todos pueden verlo por si mismos.")


dialogId("tet-v-myslim", "font_big", "Do you know what I have in mind?")
dialogStr("¿Sabes lo que tengo en mente?")


dialogId("tet-m-ano", "font_small", "Well?")
dialogStr("¿Bien?")


dialogId("tet-v-lepsi", "font_big", "I think we could do a better tetris than this room.")
dialogStr("Creo que podríamos hacer un mejor tetris que esta habitación.")


dialogId("tet-m-jaklepsi", "font_small", "What do you mean, better?")
dialogStr("¿Qué quieres decir con mejor?")


dialogId("tet-v-hybat", "font_big", "At least, you won’t have to move all the pieces to the right.")
dialogStr("Al menos, no tienes que mover todas las piezas a la derecha.")


dialogId("tet-m-predmety", "font_small", "The truth is we have an ample supply of suitable objects here.")
dialogStr("La verdad es que tenemos un amplio surtido de objetos apropiados aquí.")


dialogId("tet-v-uprava", "font_big", "I think a little patch of code could give the player the possibility to enjoy some original tetris.")
dialogStr("Creo que ese pequeño parche de código puede dar al jugador la posibilidad de disfrutar algún tetris original.")


dialogId("tet-m-program", "font_small", "Okay, try to program it!")
dialogStr("Bueno, ¡Trata de programarlo!")


dialogId("tet-m-pozor", "font_small", "Be careful not to hurt us.")
dialogStr("Ten cuidado de no hacernos daño.")


dialogId("tet-v-kostky", "font_big", "We will have to stack these pieces more efficiently, perhaps.")
dialogStr("Quizás tendremos que apilar esas piezas en forma más eficiente.")


dialogId("tet-m-lepe", "font_small", "Hmm... I should have arranged it better.")
dialogStr("Hmm... Debería de haberlas organizado mejor.")

