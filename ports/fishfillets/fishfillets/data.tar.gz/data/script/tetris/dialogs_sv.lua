
dialogId("tet-m-vypadala", "font_small", "So this is what the most successful game of all time originally looked like.")
dialogStr("Så det är så här som tidernas största spel såg ut från början.")


dialogId("tet-v-ucta", "font_big", "Only deep respect for its memory prevents me from saying what it looks like...")
dialogStr("Bara den djupaste respekten för dess minne hindrar mig från att säga vad det liknar...")


dialogId("tet-m-usudek", "font_small", "But everybody else can see for themselves.")
dialogStr("Men alla andra kan ju se det själva.")


dialogId("tet-v-myslim", "font_big", "Do you know what I have in mind?")
dialogStr("Vet du vad jag tänker på?")


dialogId("tet-m-ano", "font_small", "Well?")
dialogStr("Vad?")


dialogId("tet-v-lepsi", "font_big", "I think we could do a better tetris than this room.")
dialogStr("Jag tänker att vi kan göra ett bättre tetris än det här rummet.")


dialogId("tet-m-jaklepsi", "font_small", "What do you mean, better?")
dialogStr("Vad då \"bättre\"?")


dialogId("tet-v-hybat", "font_big", "At least, you won’t have to move all the pieces to the right.")
dialogStr("Vi skulle åtminstone inte behöva flytta alla bitar åt höger.")


dialogId("tet-m-predmety", "font_small", "The truth is we have an ample supply of suitable objects here.")
dialogStr("Sanningen är att vi har en bra hög med passande bitar här.")


dialogId("tet-v-uprava", "font_big", "I think a little patch of code could give the player the possibility to enjoy some original tetris.")
dialogStr("Jag tror att en liten ändring av koden skulle ge spelaren möjlighet att njuta av original spelet.")


dialogId("tet-m-program", "font_small", "Okay, try to program it!")
dialogStr("OK, prova att programmera det.")


dialogId("tet-m-pozor", "font_small", "Be careful not to hurt us.")
dialogStr("Var försiktig så att du inte gör oss illa.")


dialogId("tet-v-kostky", "font_big", "We will have to stack these pieces more efficiently, perhaps.")
dialogStr("Vi behöver stapla bitarna lite mera effektivt, kanske.")


dialogId("tet-m-lepe", "font_small", "Hmm... I should have arranged it better.")
dialogStr("Humm... Jag kunde ha staplat bättre.")

