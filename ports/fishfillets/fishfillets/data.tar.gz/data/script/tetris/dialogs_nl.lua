
dialogId("tet-m-vypadala", "font_small", "So this is what the most successful game of all time originally looked like.")
dialogStr("Dus zo zag het meest succesvolle spel ooit eruit.")


dialogId("tet-v-ucta", "font_big", "Only deep respect for its memory prevents me from saying what it looks like...")
dialogStr("Alleen mijn diepe respect voor de nagedachtenis eraan weerhoudt me ervan te zeggen hoe dit eruit ziet...")


dialogId("tet-m-usudek", "font_small", "But everybody else can see for themselves.")
dialogStr("Maar iedereen kan het nu zelf zien.")


dialogId("tet-v-myslim", "font_big", "Do you know what I have in mind?")
dialogStr("Weet je wat ik denk?")


dialogId("tet-m-ano", "font_small", "Well?")
dialogStr("Wat?")


dialogId("tet-v-lepsi", "font_big", "I think we could do a better tetris than this room.")
dialogStr("Ik denk dat wij een betere tetris inelkaar zouden kunnen draaien dan deze kamer.")


dialogId("tet-m-jaklepsi", "font_small", "What do you mean, better?")
dialogStr("Hoezo beter?")


dialogId("tet-v-hybat", "font_big", "At least, you won’t have to move all the pieces to the right.")
dialogStr("Op z'n minst zou je niet al die blokjes naar rechts hoeven te bewegen.")


dialogId("tet-m-predmety", "font_small", "The truth is we have an ample supply of suitable objects here.")
dialogStr("We hebben hier een flinke voorraad geschikte objecten.")


dialogId("tet-v-uprava", "font_big", "I think a little patch of code could give the player the possibility to enjoy some original tetris.")
dialogStr("Ik denk dat een kleine patch op de broncode de speler de gelegenheid zou geven om de oorspronkelijk tetris te spelen.")


dialogId("tet-m-program", "font_small", "Okay, try to program it!")
dialogStr("Mooi, programmeer het maar uit.")


dialogId("tet-m-pozor", "font_small", "Be careful not to hurt us.")
dialogStr("Pas op dat je ons heel laat.")


dialogId("tet-v-kostky", "font_big", "We will have to stack these pieces more efficiently, perhaps.")
dialogStr("We zullen deze blokjes wat efficienter moeten stapelen.")


dialogId("tet-m-lepe", "font_small", "Hmm... I should have arranged it better.")
dialogStr("Hmm... Ik had dit beter moeten stapelen.")

