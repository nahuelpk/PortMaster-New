
dialogId("tet-m-vypadala", "font_small", "So this is what the most successful game of all time originally looked like.")
dialogStr("Tak takhle vypadala nejúspěšnější hra všech dob.")


dialogId("tet-v-ucta", "font_big", "Only deep respect for its memory prevents me from saying what it looks like...")
dialogStr("Jenom úcta k její památce mi brání v tom, abych řekl, jak to vypadá...")


dialogId("tet-m-usudek", "font_small", "But everybody else can see for themselves.")
dialogStr("Ale každý si může udělat úsudek sám.")


dialogId("tet-v-myslim", "font_big", "Do you know what I have in mind?")
dialogStr("Víš, co si myslím?")


dialogId("tet-m-ano", "font_small", "Well?")
dialogStr("Ano?")


dialogId("tet-v-lepsi", "font_big", "I think we could do a better tetris than this room.")
dialogStr("Dokázali bychom udělat lepší tetris, než je tahle místnost.")


dialogId("tet-m-jaklepsi", "font_small", "What do you mean, better?")
dialogStr("Jak lepší?")


dialogId("tet-v-hybat", "font_big", "At least, you won’t have to move all the pieces to the right.")
dialogStr("No, přinejmenším tak, aby se tam dalo hýbat kostkou nejen doprava.")


dialogId("tet-m-predmety", "font_small", "The truth is we have an ample supply of suitable objects here.")
dialogStr("Pravda je, že tu máme spoustu vhodných předmětů.")


dialogId("tet-v-uprava", "font_big", "I think a little patch of code could give the player the possibility to enjoy some original tetris.")
dialogStr("Myslím, že by stačila jen malá úprava kódu, aby si hráč mohl vychutnat trochu originálního tetrisu.")


dialogId("tet-m-program", "font_small", "Okay, try to program it!")
dialogStr("Tak to zkus naprogramovat.")


dialogId("tet-m-pozor", "font_small", "Be careful not to hurt us.")
dialogStr("Dej si pozor, ať nám něco neuděláš.")


dialogId("tet-v-kostky", "font_big", "We will have to stack these pieces more efficiently, perhaps.")
dialogStr("Asi tam budeme muset ty kostky naskládat úsporněji.")


dialogId("tet-m-lepe", "font_small", "Hmm... I should have arranged it better.")
dialogStr("Hmmm... měla jsem to tam naskládat nějak lépe.")

