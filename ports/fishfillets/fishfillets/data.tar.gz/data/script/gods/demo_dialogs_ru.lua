-- FIXME adascor
dialogId("dlg-x-poster1", "font_poster", "Occupation of the captive we are sending to you is an ocean god. Except of the plane and ship disappearings (so called Sea Battle case) he is responsible for the other crimes as well, moving the continents (code name Run, continent, run) and meteorite in Tunguzka (code Jumping Jack) are among them.")
dialogStr("Захваченного в плен мы отправляем тебе, Бог Океана. Кроме исчезнувших самолета и корабля (так называемый Морской корабль), он ответственнен и за другие преступления, такие как перемещение материков (кодовое имя Беги, материк, беги) и Тунгусский метеорит (кодовое имя Прыгающий Джек).")

dialogId("dlg-x-poster2", "font_poster", "We managed to intervene just in the nick of time: we have found a brand new unwrapped box with a table game called STAR WARS in the captive’s house.")
dialogStr("Нам удалось вмешаться только в самый последний момент: мы нашли совершенно новую развернутую коробку с настольной игрой под названием ЗВЕЗДНЫЕ ВОЙНЫ в доме пленника.")

dialogId("dlg-x-poster3", "font_poster", "You can find the records of his sea battles in the attachement.")
dialogStr("Вы можете найти отчеты его морских сражений в приложении.")

