
dialogId("dlg-x-poster1", "font_poster", "Occupation of the captive we are sending to you is an ocean god. Except of the plane and ship disappearings (so called Sea Battle case) he is responsible for the other crimes as well, moving the continents (code name Run, continent, run) and meteorite in Tunguzka (code Jumping Jack) are among them.")
dialogStr("Die Berufstätigkeit des Gefangenen, den wir ihnen schicken, ist Meeresgott. Außer des Verschwindens von Flugzeugen und Schiffen (dem sogenannten Schiffe-Versenken-Fall) ist er weiterer Verbrechen schuldig, darunter: Verschieben von Kontinenten (Kennzeichen Run,Continent,Run) und eines Meteoriten in Tunguska (Kennzeichen Jumping Jack).")


dialogId("dlg-x-poster2", "font_poster", "We managed to intervene just in the nick of time: we have found a brand new unwrapped box with a table game called STAR WARS in the captive’s house.")
dialogStr("Wir schafften es, im letzten Augenblick einzugreifen: Wir haben eine brandneue Schachtel mit dem Tischspiel \"STAR WARS\" im Haus des Gefangenen gefunden.")


dialogId("dlg-x-poster3", "font_poster", "You can find the records of his sea battles in the attachement.")
dialogStr("Sie finden die Aufzeichnungen seiner Seeschlachten im Anhang.")

