
dialogId("dlg-x-poster1", "font_poster", "Occupation of the captive we are sending to you is an ocean god. Except of the plane and ship disappearings (so called Sea Battle case) he is responsible for the other crimes as well, moving the continents (code name Run, continent, run) and meteorite in Tunguzka (code Jumping Jack) are among them.")
dialogStr("L'occupazione abituale del prigioniero che vi stiamo mandando è fare la divinità oceanica. Oltre alle sparizioni di navi ed aerei (il cosiddetto caso Battaglia Navale), è responsabile di altri crimini, della deriva dei continenti (nome in codice Corri, continente, corri) e del meteorite della Tunguska (nome in codice Saltapicchio) tra gli altri.")

dialogId("dlg-x-poster2", "font_poster", "We managed to intervene just in the nick of time: we have found a brand new unwrapped box with a table game called STAR WARS in the captive’s house.")
dialogStr("Siamo riusciti ad intervenire appena in tempo: nell'alloggio del prigioniero abbiamo trovato una scatola nuova non ancora aperta contenente un gioco da tavolo chiamato GUERRE STELLARI.")

dialogId("dlg-x-poster3", "font_poster", "You can find the records of his sea battles in the attachement.")
dialogStr("Troverete il rapporto completo delle sue battaglie navali in allegato.")
