
dialogId("dlg-x-poster1", "font_poster", "Occupation of the captive we are sending to you is an ocean god. Except of the plane and ship disappearings (so called Sea Battle case) he is responsible for the other crimes as well, moving the continents (code name Run, continent, run) and meteorite in Tunguzka (code Jumping Jack) are among them.")
dialogStr("La profession du captif que nous vous avons envoyé est dieu de l'océan. En plus de la disparition des bateaux et avions (aussi appelée bataille navale) il est responsable de bien d'autres crimes, dont le déplacement des continents (nom de code Cours, continent, cours) ou encore la météorite de Tunguzka (code Pantin).")


dialogId("dlg-x-poster2", "font_poster", "We managed to intervene just in the nick of time: we have found a brand new unwrapped box with a table game called STAR WARS in the captive’s house.")
dialogStr("Nous sommes intervenus in extremis : nous avons trouvé tout juste déballée une boîte contenant le jeu de plateau STAR WARS dans la maison du prisonnier.")


dialogId("dlg-x-poster3", "font_poster", "You can find the records of his sea battles in the attachement.")
dialogStr("Vous trouverez les enregistrements de ses batailles navales en annexes.")

