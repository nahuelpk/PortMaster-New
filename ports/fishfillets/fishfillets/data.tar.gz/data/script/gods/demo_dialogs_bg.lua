dialogId("dlg-x-poster1", "font_poster", "Occupation of the captive we are sending to you is an ocean god. Except of the plane and ship disappearings (so called Sea Battle case) he is responsible for the other crimes as well, moving the continents (code name Run, continent, run) and meteorite in Tunguzka (code Jumping Jack) are among them.")
dialogStr("Длъжността на затворника, чиято позиция ши изпращаме е океански бог. Освен за изчезванията на самолети и кораби (т.нар. случай „Морска Битка“), той е отговорен и за други престъпления. Преместването на континентите (кодови име „Бягай, континент, бягай“) и Тунгуският метеорит (кодово име „Подскачащият Джак“) са свежи примери.")

dialogId("dlg-x-poster2", "font_poster", "We managed to intervene just in the nick of time: we have found a brand new unwrapped box with a table game called STAR WARS in the captive’s house.")
dialogStr("Успяхме да се намесим точно навреме: намерихме чисто нова, неотворена кутия с настолна игра, наречена „Звездни войни“ в къщата на затворника.")

dialogId("dlg-x-poster3", "font_poster", "You can find the records of his sea battles in the attachement.")
dialogStr("Историята на морските битки можете да намерите в приложението.")

