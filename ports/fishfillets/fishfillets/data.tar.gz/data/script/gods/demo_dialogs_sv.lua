
dialogId("dlg-x-poster1", "font_poster", "Occupation of the captive we are sending to you is an ocean god. Except of the plane and ship disappearings (so called Sea Battle case) he is responsible for the other crimes as well, moving the continents (code name Run, continent, run) and meteorite in Tunguzka (code Jumping Jack) are among them.")
dialogStr("Yrket som fången vi skickar till er har är havsgud. Förutom försvunna flygplan och skepp (så kallade havsslagsfall) är han ansvarig för andra brott inklusive, flyttande av kontinenter (kodnamn Spring, kontinent, spring) och meteoriten i Tunguzka (kodnamn Jumping Jack) är några av dem.")


dialogId("dlg-x-poster2", "font_poster", "We managed to intervene just in the nick of time: we have found a brand new unwrapped box with a table game called STAR WARS in the captive’s house.")
dialogStr("Vi lyckades avstyra i sista stund: vi har hittat en helt ny ouppackad låda med ett spel kallat STAR WARS i den fängslades hus")


dialogId("dlg-x-poster3", "font_poster", "You can find the records of his sea battles in the attachement.")
dialogStr("Ni kan finna uppgifter om hans sjöslag i det bifogade tillägget.")

