-- FIXME adascor
dialogId("lod-v-silenost0", "font_big", "I have a suspicion that we are about to discover something terrible.")
dialogStr("У меня есть подозрение, что мы нашли что-то ужасное.")

dialogId("lod-v-silenost1", "font_big", "I always knew that: the gods must be mad.")
dialogStr("Я всегда знал, что Боги наверное сумасшедшие.")

dialogId("lod-v-silenost2", "font_big", "God is mad and the whole world is his plaything.")
dialogStr("Боги, должно быть, сумашедште, и весь мир для них - игрушка.")

dialogId("lod-m-pravda0", "font_small", "I think that you are right.")
dialogStr("Думаю, что ты прав.")

dialogId("lod-m-pravda1", "font_small", "I am afraid that you are right.")
dialogStr("Я боюсь, что ты прав.")

dialogId("lod-m-pravda2", "font_small", "Yes, it is shocking.")
dialogStr("Это ошеломляет.")

dialogId("lod-m-costim", "font_small", "What are we to do about it?")
dialogStr("Что мы будем делать с этим?")

dialogId("lod-v-internovat", "font_big", "We can’t leave it this way. We must incarcerate them.")
dialogStr("Мы не можем так это оставить. Мы должны посадить их в тюрьму.")

dialogId("lod-m-co", "font_small", "What must we do?")
dialogStr("Что мы должны сделать?")

dialogId("lod-v-cvok", "font_big", "Put them into the mad... I mean into the detainment facility of FDTO.")
dialogStr("Поместить их в сумашедший... Я думаю на поддержание аппаратуры в Службу Подготовки Рыб-Детективов .")  --- ???

dialogId("lod-m-oba", "font_small", "You are right. Shall we take both of them?")
dialogStr("Ты прав. Мы вдвоем возьмем их?")

dialogId("lod-v-golf", "font_big", "Of course. If we leave one of them here, any mad idea could occur to him. He could try to start playing golf, for example.")
dialogStr("Конечно. Если мы оставим одного из них здесь, у него может возникнуть какая-нибудь сумашедшая идея. Он может попытаться начать играть в гольф, например.")

dialogId("lod-m-jednoho", "font_small", "Hardly with this club. I think we should be happy if we manage to get one. The other one will be harmless then.")
dialogStr("Тяжело с этой клюшкой. Думаю, мы будем счастливы, если нам удастся получить одного. Тогда другой станет безобидным.")

dialogId("lod-v-koho", "font_big", "Well. Which one?")
dialogStr("Хорошо. Который?")

dialogId("lod-m-zluty", "font_small", "The yellow one.")
dialogStr("Желтый.")

dialogId("lod-m-modry", "font_small", "The blue one.")
dialogStr("Синий.")

dialogId("lod-v-zluty", "font_big", "That yellow one.")
dialogStr("Желтый.")

dialogId("lod-v-modry", "font_big", "That blue one.")
dialogStr("Синий.")

dialogId("lod-m-hrac", "font_small", "We will leave this to the player.")
dialogStr("Мы оставим это игроку.")

dialogId("lod-v-hrac", "font_big", "We shall leave this to the player.")
dialogStr("Мы должны оставить это игроку.")

dialogId("lod-v-hul", "font_big", "Look at that club: something terrible happened to it.")
dialogStr("Посмотри на клюшку: что-то ужасное случилось с ней.")

dialogId("lod-m-ozizlana", "font_small", "A pld probably sucked upon it.")
dialogStr("Возможно, она попала в водоворот.") ---??

dialogId("lod-v-hravost", "font_big", "Mother was right. Abnormal playfulness is the root of all evil.")
dialogStr("Мама была права. Ненормальная игривость - это корень всех зол.")

dialogId("lod-m-palka", "font_small", "That’s true. It would be much easier if that table tennis bat was somewhere else.")
dialogStr("Это верно. Было бы проще, если бы ракетка от настольного тенниса была где-то еще.")

dialogId("lod-v-micky", "font_big", "By the way, did you notice that the real golf ball is in the upper left corner while that thing in the lower right corner is a cricket ball?")
dialogStr("Между прочим, Вы заметили, что настоящий шар для гольфа находится в верхнем левом углу, в то время как в нижнем правом углу - шар крикета?")

dialogId("lod-m-vyznam", "font_small", "Is there some hidden symbolism?")
dialogStr("Это некая скрытая символика?")

dialogId("lod-v-kdovi", "font_big", "Who knows.")
dialogStr("Кто знает.")

dialogId("lod-m-micek", "font_small", "I thought it was a table tennis ball up there.")
dialogStr("Я думал, что там был шар настольного тенниса.")

dialogId("lod-v-rozliseni", "font_big", "It’s hard to say with this screen resolution.")
dialogStr("Трудно сказать с такой разрешающей способностью экрана.")

dialogId("lod-m-bohove", "font_small", "This time our goal is to get out one of those gods.")
dialogStr("Тем временем, наша цель - вытащить одного из тех богов.")

dialogId("b1-voda1", "font_yellow", "Miss!")
dialogStr("Мимо!")

dialogId("b1-voda2", "font_yellow", "Miss!")
dialogStr("Мимо!")

dialogId("b1-voda3", "font_yellow", "Miss!")
dialogStr("Мимо!")

dialogId("b1-voda4", "font_yellow", "Miss!")
dialogStr("Мимо!")

dialogId("b1-voda5", "font_yellow", "Miss!")
dialogStr("Мимо!")

dialogId("b1-zasah1", "font_yellow", "Hit!")
dialogStr("Ранен!")

dialogId("b1-zasah2", "font_yellow", "Hit!")
dialogStr("Ранен!")

dialogId("b1-zasah3", "font_yellow", "Hit!")
dialogStr("Ранен!")

dialogId("b1-zasah4", "font_yellow", "Hit!")
dialogStr("Ранен!")

dialogId("b1-potop1", "font_yellow", "Sank!")
dialogStr("Убит!")

dialogId("b1-potop2", "font_yellow", "Sank!")
dialogStr("Убит!")

dialogId("b1-potop3", "font_yellow", "Sank!")
dialogStr("Убит!")

dialogId("b1-vyhral", "font_yellow", "I won, you sissy!!!")
dialogStr("Я победил, сестричка!!!")

dialogId("b1-zacinam", "font_yellow", "I start!")
dialogStr("Я начинаю!")

dialogId("b1-dobre", "font_yellow", "Well!")
dialogStr("Отлично!")

dialogId("b1-znovu", "font_yellow", "Shall we play another one?")
dialogStr("Будем играть еще раз?")

dialogId("b1-nepodvadim", "font_yellow", "I don’t cheat.")
dialogStr("Я не обманываю.")

dialogId("b1-spletl", "font_yellow", "It was a mistake, probably...")
dialogStr("Возможно, это была ошибка...")

dialogId("b2-voda1", "font_cyan", "Miss!")
dialogStr("Мимо!")

dialogId("b2-voda2", "font_cyan", "Miss!")
dialogStr("Мимо!")

dialogId("b2-voda3", "font_cyan", "Miss!")
dialogStr("Мимо!")

dialogId("b2-voda4", "font_cyan", "Miss!")
dialogStr("Мимо!")

dialogId("b2-voda5", "font_cyan", "Miss!")
dialogStr("Мимо!")

dialogId("b2-zasah1", "font_cyan", "Hit!")
dialogStr("Ранен!")

dialogId("b2-zasah2", "font_cyan", "Hit!")
dialogStr("Ранен!")

dialogId("b2-zasah3", "font_cyan", "Hit!")
dialogStr("Ранен!")

dialogId("b2-zasah4", "font_cyan", "Hit!")
dialogStr("Ранен!")

dialogId("b2-potop1", "font_cyan", "Sank!")
dialogStr("Убит!")

dialogId("b2-potop2", "font_cyan", "Sank!")
dialogStr("Убит!")

dialogId("b2-potop3", "font_cyan", "Sank!")
dialogStr("Убит!")

dialogId("b2-vyhral", "font_cyan", "He, he, he... I won!")
dialogStr("Ха, ха, ха... Я выиграл!")

dialogId("b2-dobre", "font_cyan", "Well!")
dialogStr("Хорошо!")

dialogId("b2-znovu", "font_cyan", "Shall we try it again?")
dialogStr("Начнем сначала?")

dialogId("b2-rikal1", "font_cyan", "You already tried this!")
dialogStr("Ты уже устал!")

dialogId("b2-rikal2", "font_cyan", "You already said that!")
dialogStr("Ты уже говорил!")

dialogId("b2-nemuze", "font_cyan", "It can’t be a miss on this space.")
dialogStr("Я не мог промахнуться здесь.")

dialogId("b2-podvadis", "font_cyan", "You cheat!!!")
dialogStr("Ты жульничаешь!!!")

dialogId("b2-spatne", "font_cyan", "I have tried that - and you said ‘miss’!")
dialogStr("Я попробовал, и ты сказал: 'мимо?!'")

dialogId("b1-1", "", "")
dialogStr("")

dialogId("b1-2", "", "")
dialogStr("")

dialogId("b1-3", "", "")
dialogStr("")

dialogId("b1-4", "", "")
dialogStr("")

dialogId("b1-5", "", "")
dialogStr("")

dialogId("b1-6", "", "")
dialogStr("")

dialogId("b1-7", "", "")
dialogStr("")

dialogId("b1-8", "", "")
dialogStr("")

dialogId("b1-9", "", "")
dialogStr("")

dialogId("b1-10", "", "")
dialogStr("")

dialogId("b1-a", "font_yellow", "A%1.")
dialogStr("А%1.")

dialogId("b1-b", "font_yellow", "B%1.")
dialogStr("Б%1.")

dialogId("b1-c", "font_yellow", "C%1.")
dialogStr("В%1.")

dialogId("b1-d", "font_yellow", "D%1.")
dialogStr("Г%1.")

dialogId("b1-e", "font_yellow", "E%1.")
dialogStr("Д%1.")

dialogId("b1-f", "font_yellow", "F%1.")
dialogStr("Е%1.")

dialogId("b1-g", "font_yellow", "G%1.")
dialogStr("Ё%1.")

dialogId("b1-h", "font_yellow", "H%1.")
dialogStr("Ж%1.")

dialogId("b1-i", "font_yellow", "I%1.")
dialogStr("З%1.")

dialogId("b1-j", "font_yellow", "J%1.")
dialogStr("И%1.")

dialogId("b2-1", "", "")
dialogStr("")

dialogId("b2-2", "", "")
dialogStr("")

dialogId("b2-3", "", "")
dialogStr("")

dialogId("b2-4", "", "")
dialogStr("")

dialogId("b2-5", "", "")
dialogStr("")

dialogId("b2-6", "", "")
dialogStr("")

dialogId("b2-7", "", "")
dialogStr("")

dialogId("b2-8", "", "")
dialogStr("")

dialogId("b2-9", "", "")
dialogStr("")

dialogId("b2-10", "", "")
dialogStr("")

dialogId("b2-a", "font_cyan", "A%1.")
dialogStr("А%1.")

dialogId("b2-b", "font_cyan", "B%1.")
dialogStr("Б%1.")

dialogId("b2-c", "font_cyan", "C%1.")
dialogStr("В%1.")

dialogId("b2-d", "font_cyan", "D%1.")
dialogStr("Г%1.")

dialogId("b2-e", "font_cyan", "E%1.")
dialogStr("Д%1.")

dialogId("b2-f", "font_cyan", "F%1.")
dialogStr("Е%1.")

dialogId("b2-g", "font_cyan", "G%1.")
dialogStr("Ё%1.")

dialogId("b2-h", "font_cyan", "H%1.")
dialogStr("Ж%1.")

dialogId("b2-i", "font_cyan", "I%1.")
dialogStr("З%1.")

dialogId("b2-j", "font_cyan", "J%1.")
dialogStr("И%1.")

