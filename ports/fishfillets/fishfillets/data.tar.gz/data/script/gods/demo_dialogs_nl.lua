
dialogId("dlg-x-poster1", "font_poster", "Occupation of the captive we are sending to you is an ocean god. Except of the plane and ship disappearings (so called Sea Battle case) he is responsible for the other crimes as well, moving the continents (code name Run, continent, run) and meteorite in Tunguzka (code Jumping Jack) are among them.")
dialogStr("Het dagelijkse beroep van een arrestant die we naar jullie toe sturen is zeegod. Behalve voor de verdwijningen van de vliegtuigen en het schepen (de Zeeslag zaak) is hij ook verantwoordelijk voor andere misdaden, onder andere het verplaatsen van de continenten (codenaam “Ren, continentje, ren”) en de meteoor in Tunguzka (codenaam “Duveltje uit een Doosje”).")


dialogId("dlg-x-poster2", "font_poster", "We managed to intervene just in the nick of time: we have found a brand new unwrapped box with a table game called STAR WARS in the captive’s house.")
dialogStr("Het is ons op het nippertje gelukt om in te grijpen: we hebben in het huis van de verdachte een gloednieuwe, zojuist uitgepakte doos gevonden met een bordspel genaamd STAR WARS.")


dialogId("dlg-x-poster3", "font_poster", "You can find the records of his sea battles in the attachement.")
dialogStr("Voor details over zijn zeeslagen, zie het bijvoegsel.")

