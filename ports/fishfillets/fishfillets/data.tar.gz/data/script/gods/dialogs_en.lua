
dialogId("lod-v-silenost0", "font_big", "I have a suspicion that we are about to discover something terrible.")

dialogId("lod-v-silenost1", "font_big", "I always knew that: the gods must be mad.")

dialogId("lod-v-silenost2", "font_big", "God is mad and the whole world is his plaything.")

dialogId("lod-m-pravda0", "font_small", "I think that you are right.")

dialogId("lod-m-pravda1", "font_small", "I am afraid that you are right.")

dialogId("lod-m-pravda2", "font_small", "Yes, it is shocking.")

dialogId("lod-m-costim", "font_small", "What are we to do about it?")

dialogId("lod-v-internovat", "font_big", "We can’t leave it this way. We must incarcerate them.")

dialogId("lod-m-co", "font_small", "What must we do?")

dialogId("lod-v-cvok", "font_big", "Put them into the mad... I mean into the detainment facility of FDTO.")

dialogId("lod-m-oba", "font_small", "You are right. Shall we take both of them?")

dialogId("lod-v-golf", "font_big", "Of course. If we leave one of them here, any mad idea could occur to him. He could try to start playing golf, for example.")

dialogId("lod-m-jednoho", "font_small", "Hardly with this club. I think we should be happy if we manage to get one. The other one will be harmless then.")

dialogId("lod-v-koho", "font_big", "Well. Which one?")

dialogId("lod-m-zluty", "font_small", "The yellow one.")

dialogId("lod-m-modry", "font_small", "The blue one.")

dialogId("lod-v-zluty", "font_big", "That yellow one.")

dialogId("lod-v-modry", "font_big", "That blue one.")

dialogId("lod-m-hrac", "font_small", "We will leave this to the player.")

dialogId("lod-v-hrac", "font_big", "We shall leave this to the player.")

dialogId("lod-v-hul", "font_big", "Look at that club: something terrible happened to it.")

dialogId("lod-m-ozizlana", "font_small", "A pld probably sucked upon it.")

dialogId("lod-v-hravost", "font_big", "Mother was right. Abnormal playfulness is the root of all evil.")

dialogId("lod-m-palka", "font_small", "That’s true. It would be much easier if that table tennis bat was somewhere else.")

dialogId("lod-v-micky", "font_big", "By the way, did you notice that the real golf ball is in the upper left corner while that thing in the lower right corner is a cricket ball?")

dialogId("lod-m-vyznam", "font_small", "Is there some hidden symbolism?")

dialogId("lod-v-kdovi", "font_big", "Who knows.")

dialogId("lod-m-micek", "font_small", "I thought it was a table tennis ball up there.")

dialogId("lod-v-rozliseni", "font_big", "It’s hard to say with this screen resolution.")

dialogId("lod-m-bohove", "font_small", "This time our goal is to get out one of those gods.")

dialogId("b1-voda1", "font_yellow", "Miss!")

dialogId("b1-voda2", "font_yellow", "Miss!")

dialogId("b1-voda3", "font_yellow", "Miss!")

dialogId("b1-voda4", "font_yellow", "Miss!")

dialogId("b1-voda5", "font_yellow", "Miss!")

dialogId("b1-zasah1", "font_yellow", "Hit!")

dialogId("b1-zasah2", "font_yellow", "Hit!")

dialogId("b1-zasah3", "font_yellow", "Hit!")

dialogId("b1-zasah4", "font_yellow", "Hit!")

dialogId("b1-potop1", "font_yellow", "Sank!")

dialogId("b1-potop2", "font_yellow", "Sank!")

dialogId("b1-potop3", "font_yellow", "Sank!")

dialogId("b1-vyhral", "font_yellow", "I won, you sissy!!!")

dialogId("b1-zacinam", "font_yellow", "I start!")

dialogId("b1-dobre", "font_yellow", "Well!")

dialogId("b1-znovu", "font_yellow", "Shall we play another one?")

dialogId("b1-nepodvadim", "font_yellow", "I don’t cheat.")

dialogId("b1-spletl", "font_yellow", "It was a mistake, probably...")

dialogId("b2-voda1", "font_cyan", "Miss!")

dialogId("b2-voda2", "font_cyan", "Miss!")

dialogId("b2-voda3", "font_cyan", "Miss!")

dialogId("b2-voda4", "font_cyan", "Miss!")

dialogId("b2-voda5", "font_cyan", "Miss!")

dialogId("b2-zasah1", "font_cyan", "Hit!")

dialogId("b2-zasah2", "font_cyan", "Hit!")

dialogId("b2-zasah3", "font_cyan", "Hit!")

dialogId("b2-zasah4", "font_cyan", "Hit!")

dialogId("b2-potop1", "font_cyan", "Sank!")

dialogId("b2-potop2", "font_cyan", "Sank!")

dialogId("b2-potop3", "font_cyan", "Sank!")

dialogId("b2-vyhral", "font_cyan", "He, he, he... I won!")

dialogId("b2-dobre", "font_cyan", "Well!")

dialogId("b2-znovu", "font_cyan", "Shall we try it again?")

dialogId("b2-rikal1", "font_cyan", "You already tried this!")

dialogId("b2-rikal2", "font_cyan", "You already said that!")

dialogId("b2-nemuze", "font_cyan", "It can’t be a miss on this space.")

dialogId("b2-podvadis", "font_cyan", "You cheat!!!")

dialogId("b2-spatne", "font_cyan", "I have tried that - and you said ‘miss’!")

dialogId("b1-1", "", "")

dialogId("b1-2", "", "")

dialogId("b1-3", "", "")

dialogId("b1-4", "", "")

dialogId("b1-5", "", "")

dialogId("b1-6", "", "")

dialogId("b1-7", "", "")

dialogId("b1-8", "", "")

dialogId("b1-9", "", "")

dialogId("b1-10", "", "")

dialogId("b1-a", "font_yellow", "A%1.")

dialogId("b1-b", "font_yellow", "B%1.")

dialogId("b1-c", "font_yellow", "C%1.")

dialogId("b1-d", "font_yellow", "D%1.")

dialogId("b1-e", "font_yellow", "E%1.")

dialogId("b1-f", "font_yellow", "F%1.")

dialogId("b1-g", "font_yellow", "G%1.")

dialogId("b1-h", "font_yellow", "H%1.")

dialogId("b1-i", "font_yellow", "I%1.")

dialogId("b1-j", "font_yellow", "J%1.")

dialogId("b2-1", "", "")

dialogId("b2-2", "", "")

dialogId("b2-3", "", "")

dialogId("b2-4", "", "")

dialogId("b2-5", "", "")

dialogId("b2-6", "", "")

dialogId("b2-7", "", "")

dialogId("b2-8", "", "")

dialogId("b2-9", "", "")

dialogId("b2-10", "", "")

dialogId("b2-a", "font_cyan", "A%1.")

dialogId("b2-b", "font_cyan", "B%1.")

dialogId("b2-c", "font_cyan", "C%1.")

dialogId("b2-d", "font_cyan", "D%1.")

dialogId("b2-e", "font_cyan", "E%1.")

dialogId("b2-f", "font_cyan", "F%1.")

dialogId("b2-g", "font_cyan", "G%1.")

dialogId("b2-h", "font_cyan", "H%1.")

dialogId("b2-i", "font_cyan", "I%1.")

dialogId("b2-j", "font_cyan", "J%1.")

