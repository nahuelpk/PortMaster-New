
dialogId("dlg-x-poster1", "font_poster", "Occupation of the captive we are sending to you is an ocean god. Except of the plane and ship disappearings (so called Sea Battle case) he is responsible for the other crimes as well, moving the continents (code name Run, continent, run) and meteorite in Tunguzka (code Jumping Jack) are among them.")
dialogStr("")


dialogId("dlg-x-poster2", "font_poster", "We managed to intervene just in the nick of time: we have found a brand new unwrapped box with a table game called STAR WARS in the captive’s house.")
dialogStr("")


dialogId("dlg-x-poster3", "font_poster", "You can find the records of his sea battles in the attachement.")
dialogStr("")

