
dialogId("dlg-x-poster1", "font_poster", "Occupation of the captive we are sending to you is an ocean god. Except of the plane and ship disappearings (so called Sea Battle case) he is responsible for the other crimes as well, moving the continents (code name Run, continent, run) and meteorite in Tunguzka (code Jumping Jack) are among them.")
dialogStr("Die Berufstätigkeit des Gefangenen, den wir ihnen schicken, ist Meeresgott. Ausser des Verschwindens von Flugzeugen und Schiffen (dem sogenannten Schiffe-Versenken-Fall) ist er weiterer Verbrechen schuldig, darunter: Verschieben von Kontinenten (Kennzeichen Run,Continent,Run) und eines Meteoriten in Tunguska (Kennzeichen Jumping Jack).")

