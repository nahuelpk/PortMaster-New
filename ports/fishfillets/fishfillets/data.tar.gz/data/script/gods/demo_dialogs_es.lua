
dialogId("dlg-x-poster1", "font_poster", "Occupation of the captive we are sending to you is an ocean god. Except of the plane and ship disappearings (so called Sea Battle case) he is responsible for the other crimes as well, moving the continents (code name Run, continent, run) and meteorite in Tunguzka (code Jumping Jack) are among them.")
dialogStr("La profesión del prisionero que te estamos enviando es un dios del océano. Excepto por las desapariciones del avión y de la nave (llamados el caso de la Batalla Marina) él es responsable por los otros crímenes también. Moviendo los continentes (nombre clave Corre, continente, corre) y el meteorito en Tunguzka (nombre código Jack Saltador) están entre éstos.")


dialogId("dlg-x-poster2", "font_poster", "We managed to intervene just in the nick of time: we have found a brand new unwrapped box with a table game called STAR WARS in the captive’s house.")
dialogStr("Conseguimos intervenir justo en el límite del tiempo: encontramos una nueva caja desempaquetada con un juego de mesa llamado STAR WARS en la casa del prisionero.")


dialogId("dlg-x-poster3", "font_poster", "You can find the records of his sea battles in the attachement.")
dialogStr("Puedes encontrar los registros de sus batallas de mar en los adjuntos.")

