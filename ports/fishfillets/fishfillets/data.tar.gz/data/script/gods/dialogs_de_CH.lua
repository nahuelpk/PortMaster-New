
dialogId("lod-v-kdovi", "font_big", "Who knows.")
dialogStr("Wer weiss.")

