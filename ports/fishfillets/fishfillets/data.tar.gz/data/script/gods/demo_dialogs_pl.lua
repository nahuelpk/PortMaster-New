
dialogId("dlg-x-poster1", "font_poster", "Occupation of the captive we are sending to you is an ocean god. Except of the plane and ship disappearings (so called Sea Battle case) he is responsible for the other crimes as well, moving the continents (code name Run, continent, run) and meteorite in Tunguzka (code Jumping Jack) are among them.")
dialogStr("Jeniec, którego wam przesyłamy, jest bogiem oceanu. Poza zaginionymi statkami i samolotami (tzw. sprawa Statków), jest odpowiedzialny za inne przestępstwa, między innymi wędrówkę kontynentów (kryptonim Lądy Przez Morza) i Meteoryt Tunguski (kryptonim Hop Siup).")


dialogId("dlg-x-poster2", "font_poster", "We managed to intervene just in the nick of time: we have found a brand new unwrapped box with a table game called STAR WARS in the captive’s house.")
dialogStr("Zdążyliśmy z naszą interwencją w ostatniej chwili. W domu zatrzymanego odkryliśmy nowiutkie, jeszcze nie rozpakowane pudełko zawierające grę planszową o nazwie Gwiezdne Wojny.")


dialogId("dlg-x-poster3", "font_poster", "You can find the records of his sea battles in the attachement.")
dialogStr("W załączeniu przesyłamy zapis rozegranych przez niego partii Statków.")

