-- FIXME. asm
dialogId("semafor-v", "font_big", "Wait, see the red on the traffic light!")
dialogStr("Подожди, не ведешь красный цвет?")
 
dialogId("budova-m", "font_small", "This is the building of Fish Detective Training Organization.")
dialogStr("Это здание Службы Подготовки Рыб-Детективов.")

dialogId("rozkladaci-v", "font_big", "I think we can take it to pieces.")
dialogStr("Я думаю мы можем взять эту штуку.")

dialogId("drzel-m", "font_small", "But our home holds together despite UFO crashed into it.")
dialogStr("Но наш дом оставался целым, даже когда НЛО обрушилось на него.")

dialogId("nacekala-m", "font_small", "Sorry, it isn’t a good idea.")
dialogStr("Прости, это плохая идея.")

dialogId("vidis-v", "font_big", "Do you see it?")
dialogStr("Ведешь это")

dialogId("zelena-v", "font_big", "Look, the green light is started now.")
dialogStr("Смотри, зелёный цвет, можно двигаться.")

dialogId("nevi-b", "font_white", "FDTO - Nobody knows about us!")
dialogStr("СПРД - Никто не знает о ней.")

dialogId("nejlepsi-b", "font_white", "FDTO - We are the best!")
dialogStr("СПРД - мы лучшие!")

dialogId("mrka-m", "font_small", "The seahorse winks very nice.")
dialogStr("Морской конек подмигивает очень мило.")

dialogId("nemrka-v", "font_big", "No it doesn’t.")
dialogStr("Нет, совсем не мило.")

dialogId("ted1-m", "font_small", "Look... right now!")
dialogStr("Смотри... справа!")

dialogId("ted2-m", "font_small", "Look... right now!")
dialogStr("Смотри... справа!")

dialogId("ted3-m", "font_small", "Look... right now!")
dialogStr("Смотри... справа!")

dialogId("ted4-m", "font_small", "Look... right now!")
dialogStr("Смотри... справа!")

dialogId("nebyl-v", "font_big", "It would be better if it never existed.")
dialogStr("Было бы лучше, если его никогда бы не было.")

dialogId("hybeme-v", "font_big", "See, we are iconographic here and we are moving.")
dialogStr("Смотри, мы нарисованы здесь и двигаемся.")

dialogId("agenti-m", "font_small", "Yes, we are their ablest agents...")
dialogStr("Да, мы лучшие агенты...")

dialogId("podvodou-v", "font_big", "...underwater.")
dialogStr("...под водой.")

dialogId("mene-m", "font_small", "You may be less able.")
dialogStr("Может быть ты менее квалифицированный?")

dialogId("kecas-v", "font_big", "Why are you drivelling?")
dialogStr("Зачем ты говоришь глупости")

dialogId("cely-m", "font_small", "You aren’t complete there.")
dialogStr("Ты там не дорисован.")

dialogId("proc-v", "font_big", "What are you doing whith these small balls when the antenna is here?")
dialogStr("Что ты делаешь с этими маленькими шарами, когда антенна здесь?")

dialogId("proc-m", "font_small", "Why we are destroying this building when it is clear than we have to put one ball to this horse?")
dialogStr("Почему как только мы уничтожим здание, сразу становиться ясно, что шар нужно положить на эту лошадь?")

dialogId("rozbil-v", "font_big", "What? The traffic light is broken.")
dialogStr("Ждать? Светофор сломался.")
