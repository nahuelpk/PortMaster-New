dialogId("semafor-v", "font_big", "Wait, see the red on the traffic light!")
dialogStr("Vänta, ser du det röda på trafikljuset!")
 
dialogId("budova-m", "font_small", "This is the building of Fish Detective Training Organization.")
dialogStr("Det här är FiskDetektivTräningOrganisationens hus.")

dialogId("rozkladaci-v", "font_big", "I think we can take it to pieces.")
dialogStr("Jag tror att vi kan plocka isär det")

dialogId("drzel-m", "font_small", "But our home holds together despite UFO crashed into it.")
dialogStr("Men vårt hus håller ju ihop trotts att ett UFO har kraschat där.")

dialogId("nacekala-m", "font_small", "Sorry, it isn’t a good idea.")
dialogStr("Tyvärr, det är ingen bra idé.")

dialogId("vidis-v", "font_big", "Do you see it?")
dialogStr("Ser du den?")

dialogId("zelena-v", "font_big", "Look, the green light is started now.")
dialogStr("Titta, det är grönt ljus nu?")

dialogId("nevi-b", "font_white", "FDTO - Nobody knows about us!")
dialogStr("FDTO - Ingen känner till oss!")

dialogId("nejlepsi-b", "font_white", "FDTO - We are the best!")
dialogStr("FDTO - Vi är bäst!")

dialogId("mrka-m", "font_small", "The seahorse winks very nice.")
dialogStr("Hästen vinkar trevligt.")

dialogId("nemrka-v", "font_big", "No it doesn’t.")
dialogStr("Nej det gör han inte.")

dialogId("ted1-m", "font_small", "Look... right now!")
dialogStr("Titta ... precis nu!")

dialogId("ted2-m", "font_small", "Look... right now!")
dialogStr("Titta ... precis nu!")

dialogId("ted3-m", "font_small", "Look... right now!")
dialogStr("Titta ... precis nu!")

dialogId("ted4-m", "font_small", "Look... right now!")
dialogStr("Titta ... precis nu!")

dialogId("nebyl-v", "font_big", "It would be better if it never existed.")
dialogStr("Det skulle ha varit bättre om det aldrig hade existerat.")

dialogId("hybeme-v", "font_big", "See, we are iconographic here and we are moving.")
dialogStr("Titta, vi är ikongrafik och rör på oss.")

dialogId("agenti-m", "font_small", "Yes, we are their ablest agents...")
dialogStr("Ja, vi är deras mest lämpade agenter.")

dialogId("podvodou-v", "font_big", "...underwater.")
dialogStr("Under vattnet.")

dialogId("mene-m", "font_small", "You may be less able.")
dialogStr("Du kanske är mindre lämpad.")

dialogId("kecas-v", "font_big", "Why are you drivelling?")
dialogStr("Varför pladdrar du?")

dialogId("cely-m", "font_small", "You aren’t complete there.")
dialogStr("Du är inte här helt och hållet.")

dialogId("proc-v", "font_big", "What are you doing whith these small balls when the antenna is here?")
dialogStr("Vad gör du med de där små bollarna när antennen är här borta?")

dialogId("proc-m", "font_small", "Why we are destroying this building when it is clear than we have to put one ball to this horse?")
dialogStr("Varför plockar vi isär byggnaden när det är helt klart att vi måste lägga en boll till hästen.")

dialogId("rozbil-v", "font_big", "What? The traffic light is broken.")
dialogStr("Vad då? Trafikljuset är trasigt.")

