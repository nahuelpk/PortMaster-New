dialogId("semafor-v", "font_big", "Wait, see the red on the traffic light!")
dialogStr("Wacht, zie je dat rode stoplicht niet!")
 
dialogId("budova-m", "font_small", "This is the building of Fish Detective Training Organization.")
dialogStr("Dit is het gebouw van Vissen Detective Training Organisatie.")

dialogId("rozkladaci-v", "font_big", "I think we can take it to pieces.")
dialogStr("Ik denk dat we het kunnen afbreken.")

dialogId("drzel-m", "font_small", "But our home holds together despite UFO crashed into it.")
dialogStr("Maar ons huis is nog heel, ondanks de vliegende schotel die erop neergestort is.")

dialogId("nacekala-m", "font_small", "Sorry, it isn’t a good idea.")
dialogStr("Sorry, dat is geen goed idee.")

dialogId("vidis-v", "font_big", "Do you see it?")
dialogStr("Zie je dat?")

dialogId("zelena-v", "font_big", "Look, the green light is started now.")
dialogStr("Kijk, het groene licht is nu aan.")

dialogId("nevi-b", "font_white", "FDTO - Nobody knows about us!")
dialogStr("VDTO - Niemand weet dat we bestaan!")

dialogId("nejlepsi-b", "font_white", "FDTO - We are the best!")
dialogStr("VDTO - Wij zijn de besten!")

dialogId("mrka-m", "font_small", "The seahorse winks very nice.")
dialogStr("Dat zeepaardje knipoogt heel vriendelijk.")

dialogId("nemrka-v", "font_big", "No it doesn’t.")
dialogStr("Niet waar.")

dialogId("ted1-m", "font_small", "Look... right now!")
dialogStr("Kijk... nu net!")

dialogId("ted2-m", "font_small", "Look... right now!")
dialogStr("Kijk... nu net!")

dialogId("ted3-m", "font_small", "Look... right now!")
dialogStr("Kijk... nu net!")

dialogId("ted4-m", "font_small", "Look... right now!")
dialogStr("Kijk... nu net!")

dialogId("nebyl-v", "font_big", "It would be better if it never existed.")
dialogStr("Het zou beter zijn als het nooit had bestaan.")

dialogId("hybeme-v", "font_big", "See, we are iconographic here and we are moving.")
dialogStr("Kijk, we zijn ikoontjes hier, en we bewegen.")

dialogId("agenti-m", "font_small", "Yes, we are their ablest agents...")
dialogStr("Ja, we zijn hun beste agenten...")

dialogId("podvodou-v", "font_big", "...underwater.")
dialogStr("...onderwater.")

dialogId("mene-m", "font_small", "You may be less able.")
dialogStr("Jij bent misschien wat minder goed.")

dialogId("kecas-v", "font_big", "Why are you drivelling?")
dialogStr("Wat kwebbel je nou?")

dialogId("cely-m", "font_small", "You aren’t complete there.")
dialogStr("Je bent er niet helemaal.")

dialogId("proc-v", "font_big", "What are you doing whith these small balls when the antenna is here?")
dialogStr("Wat doe je met die kleine balletjes als de antenne hier is?")

dialogId("proc-m", "font_small", "Why we are destroying this building when it is clear than we have to put one ball to this horse?")
dialogStr("Waarom breken we dit gebouw af als het duidelijk is dat er een bal naar dat paard moet?")

dialogId("rozbil-v", "font_big", "What? The traffic light is broken.")
dialogStr("Wat? Het stoplicht is kapot.")
