dialogId("semafor-v", "font_big", "Wait, see the red on the traffic light!")
 
dialogId("budova-m", "font_small", "This is the building of Fish Detective Training Organization.")

dialogId("rozkladaci-v", "font_big", "I think we can take it to pieces.")

dialogId("drzel-m", "font_small", "But our home holds together despite UFO crashed into it.")

dialogId("nacekala-m", "font_small", "Sorry, it isn’t a good idea.")

dialogId("vidis-v", "font_big", "Do you see it?")

dialogId("zelena-v", "font_big", "Look, the green light is started now.")

dialogId("nevi-b", "font_white", "FDTO - Nobody knows about us!")

dialogId("nejlepsi-b", "font_white", "FDTO - We are the best!")

dialogId("mrka-m", "font_small", "The seahorse winks very nice.")

dialogId("nemrka-v", "font_big", "No it doesn’t.")

dialogId("ted1-m", "font_small", "Look... right now!")

dialogId("ted2-m", "font_small", "Look... right now!")

dialogId("ted3-m", "font_small", "Look... right now!")

dialogId("ted4-m", "font_small", "Look... right now!")

dialogId("nebyl-v", "font_big", "It would be better if it never existed.")

dialogId("hybeme-v", "font_big", "See, we are iconographic here and we are moving.")

dialogId("agenti-m", "font_small", "Yes, we are their ablest agents...")

dialogId("podvodou-v", "font_big", "...underwater.")

dialogId("mene-m", "font_small", "You may be less able.")

dialogId("kecas-v", "font_big", "Why are you drivelling?")

dialogId("cely-m", "font_small", "You aren’t complete there.")

dialogId("proc-v", "font_big", "What are you doing whith these small balls when the antenna is here?")

dialogId("proc-m", "font_small", "Why we are destroying this building when it is clear than we have to put one ball to this horse?")

dialogId("rozbil-v", "font_big", "What? The traffic light is broken.")
