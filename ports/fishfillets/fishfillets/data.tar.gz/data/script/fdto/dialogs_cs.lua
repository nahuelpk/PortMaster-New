dialogId("semafor-v", "font_big", "Wait, see the red on the traffic light!")
dialogStr("Подожди, видешь крастный свет.Počkej, na semaforu svítí červená.")
 
dialogId("budova-m", "font_small", "This is the building of Fish Detective Training Organization.")
dialogStr("To je budova fakt děsně tajné organizace.")

dialogId("rozkladaci-v", "font_big", "I think we can take it to pieces.")
dialogStr("Zdá se, že je rozkládací.")

dialogId("drzel-m", "font_small", "But our home holds together despite UFO crashed into it.")
dialogStr("Zato náš domeček držel jakž takž vcelku, i když do něj narazilo UFO.")

dialogId("nacekala-m", "font_small", "Sorry, it isn’t a good idea.")
dialogStr("To bych se načekala.")

dialogId("vidis-v", "font_big", "Do you see it?")
dialogStr("Vidíš to?")

dialogId("zelena-v", "font_big", "Look, the green light is started now.")
dialogStr("Vidíš, už svítí zelená.")

dialogId("nevi-b", "font_white", "FDTO - Nobody knows about us!")
dialogStr("FDTO - Nikdo o nás neví.")

dialogId("nejlepsi-b", "font_white", "FDTO - We are the best!")
dialogStr("FDTO - jsme nejlepší.")

dialogId("mrka-m", "font_small", "The seahorse winks very nice.")
dialogStr("Ten koník ale pěkně mrká.")

dialogId("nemrka-v", "font_big", "No it doesn’t.")
dialogStr("Nemrká.")

dialogId("ted1-m", "font_small", "Look... right now!")
dialogStr("Ale jo, třebá... Teď!")

dialogId("ted2-m", "font_small", "Look... right now!")
dialogStr("Ale jo, třebá... Teď!")

dialogId("ted3-m", "font_small", "Look... right now!")
dialogStr("Ale jo, třebá... Teď!")

dialogId("ted4-m", "font_small", "Look... right now!")
dialogStr("Ale jo, třebá... Teď!")

dialogId("nebyl-v", "font_big", "It would be better if it never existed.")
dialogStr("Stejně by bylo lepší, kdyby tam vůbec nebyl.")

dialogId("hybeme-v", "font_big", "See, we are iconographic here and we are moving.")
dialogStr("Podívej, jsme tady nakreslení a hýbeme se.")

dialogId("agenti-m", "font_small", "Yes, we are their ablest agents...")
dialogStr("Jsme přece jejich nejschopnější agenti.")

dialogId("podvodou-v", "font_big", "...underwater.")
dialogStr("Pod vodou.")

dialogId("mene-m", "font_small", "You may be less able.")
dialogStr("Ty jsi asi méně shopný")

dialogId("kecas-v", "font_big", "Why are you drivelling?")
dialogStr("Co kecáš")

dialogId("cely-m", "font_small", "You aren’t complete there.")
dialogStr("Nejsi tam celý")

dialogId("proc-v", "font_big", "What are you doing whith these small balls when the antenna is here?")
dialogStr("Co to tam vyvádíš s těmi míčky, když tady máme anténu.")

dialogId("proc-m", "font_small", "Why we are destroying this building when it is clear than we have to put one ball to this horse?")
dialogStr("Proč tady rozebíráme budovu, když je vidět, že k tomu koníkovi musíme dostat jeden z těch míčků.")

dialogId("rozbil-v", "font_big", "What? The traffic light is broken.")
dialogStr("Co to? Semafor se rozbil.")
