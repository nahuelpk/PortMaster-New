dialogId("semafor-v", "font_big", "Wait, see the red on the traffic light!")
dialogStr("Poczekaj, przecież jest czerwone światło!")
 
dialogId("budova-m", "font_small", "This is the building of Fish Detective Training Organization.")
dialogStr("To jest siedziba Faktycznie Działającej Tajnej Organizacji.")

dialogId("rozkladaci-v", "font_big", "I think we can take it to pieces.")
dialogStr("Chyba da się to rozmontować.")

dialogId("drzel-m", "font_small", "But our home holds together despite UFO crashed into it.")
dialogStr("Za to nasz domek jest w jednym kawałku, mimo że spadło na niego UFO.")

dialogId("nacekala-m", "font_small", "Sorry, it isn’t a good idea.")
dialogStr("Aha, i mam tak czekać w nieskończoność?")

dialogId("vidis-v", "font_big", "Do you see it?")
dialogStr("Widzisz to?")

dialogId("zelena-v", "font_big", "Look, the green light is started now.")
dialogStr("O, już jest zielone.")

dialogId("nevi-b", "font_white", "FDTO - Nobody knows about us!")
dialogStr("FDTO - nikt o nas nie wie!")

dialogId("nejlepsi-b", "font_white", "FDTO - We are the best!")
dialogStr("FDTO - jesteśmy najlepsi!")

dialogId("mrka-m", "font_small", "The seahorse winks very nice.")
dialogStr("Ten konik tak ładnie mruga.")

dialogId("nemrka-v", "font_big", "No it doesn’t.")
dialogStr("Nie mruga.")

dialogId("ted1-m", "font_small", "Look... right now!")
dialogStr("Mruga, spójrz... teraz!")

dialogId("ted2-m", "font_small", "Look... right now!")
dialogStr("Mruga, spójrz... teraz!")

dialogId("ted3-m", "font_small", "Look... right now!")
dialogStr("Mruga, spójrz... teraz!")

dialogId("ted4-m", "font_small", "Look... right now!")
dialogStr("Mruga, spójrz... teraz!")

dialogId("nebyl-v", "font_big", "It would be better if it never existed.")
dialogStr("Byłoby lepiej, gdyby go tu w ogóle nie było.")

dialogId("hybeme-v", "font_big", "See, we are iconographic here and we are moving.")
dialogStr("Popatrz, jesteśmy tylko rysunkami, a poruszamy się.")

dialogId("agenti-m", "font_small", "Yes, we are their ablest agents...")
dialogStr("Jesteśmy ich najzdolniejszymi agentami...")

dialogId("podvodou-v", "font_big", "...underwater.")
dialogStr("...pod wodą.")

dialogId("mene-m", "font_small", "You may be less able.")
dialogStr("Ty jesteś trochę mniej zdolny.")

dialogId("kecas-v", "font_big", "Why are you drivelling?")
dialogStr("Niby dlaczego.")

dialogId("cely-m", "font_small", "You aren’t complete there.")
dialogStr("Jesteś nieco niekompletny.")

dialogId("proc-v", "font_big", "What are you doing whith these small balls when the antenna is here?")
dialogStr("Czemu się bawisz kuleczkami, skoro antena jest tutaj?")

dialogId("proc-m", "font_small", "Why we are destroying this building when it is clear than we have to put one ball to this horse?")
dialogStr("Po co rozbieramy ten budynek, skoro wystarczy dać konikowi jedną kulkę?")

dialogId("rozbil-v", "font_big", "What? The traffic light is broken.")
dialogStr("Co jest, światła się popsuły?")
