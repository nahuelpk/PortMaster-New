
--NOTE: this file is also used by dialogLoad()
--  to determine avaiable languages.
--NOTE: DEFAULT_LANG ("en") must be the first one
--NOTE: country variants (e.g. "de_CH") must be after pure lang (e.g. "de")

select_addFlag("en", "images/menu/flags/en.png")
select_addFlag("cs", "images/menu/flags/cs.png")
select_addFlag("fr", "images/menu/flags/fr.png")
select_addFlag("de", "images/menu/flags/de.png")
select_addFlag("de_CH", "images/menu/flags/de_ch.png")
select_addFlag("it", "images/menu/flags/it.png")
select_addFlag("pl", "images/menu/flags/pl.png")
select_addFlag("es", "images/menu/flags/es.png")
select_addFlag("nl", "images/menu/flags/nl.png")
select_addFlag("bg", "images/menu/flags/bg.png")
select_addFlag("sv", "images/menu/flags/sv.png")
select_addFlag("sl", "images/menu/flags/sl.png")
select_addFlag("pt_BR", "images/menu/flags/pt_br.png")
select_addFlag("ru", "images/menu/flags/ru.png")
select_addFlag("eo", "images/menu/flags/eo.png")
