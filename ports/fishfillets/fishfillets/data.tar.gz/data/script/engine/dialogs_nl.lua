
dialogId("mot-m-info", "font_small", "I think we can gain some information about the interstellar propulsion here.")
dialogStr("Ik denk dat we hier misschien wat aanwijzingen kunnen vinden over ruimtereizen.")


dialogId("mot-v-konvencni", "font_big", "This looks more like conventional propulsion for the landing craft.")
dialogStr("Dit ziet er meer uit als een conventionele aandrijving voor het landingsvoertuigje.")


dialogId("mot-m-tak", "font_small", "So. We found the drive. We have achieved one of the objectives of our mission.")
dialogStr("Zo. We hebben de aandrijving gevonden. We hebben een van onze doelen van deze missie bereikt!")


dialogId("mot-v-zavery", "font_big", "Don’t be so hasty. We haven’t searched the whole wreck yet.")
dialogStr("Niet zo vlug. We hebben de rest van het wrak nog helemaal niet doorzocht.")


dialogId("mot-m-akce0", "font_small", "I am sorry that none of these technical marvels around us work.")
dialogStr("Jammer dat al die technische hoogstandjes om ons heen het niet meer doen.")


dialogId("mot-m-akce1", "font_small", "I’d like to see some of these extraterrestrial gizmos in action.")
dialogStr("Ik zou deze buitenaardse apparaatjes wel eens in actie willen zien.")


dialogId("mot-m-akce2", "font_small", "I wonder if this motor could work under water.")
dialogStr("Ik vraag me af of deze motor onderwater zou kunnen werken.")


dialogId("mot-v-funkce0", "font_big", "Maybe it’s better for us if it doesn’t work.")
dialogStr("Misschien is het maar goed dat hij het niet doet.")


dialogId("mot-v-funkce1", "font_big", "I am rather glad we cannot turn anything on here.")
dialogStr("Ik ben blij dat we hier niks per ongeluk aan kunnen zetten.")


dialogId("mot-v-funkce2", "font_big", "We should be happy that we could not switch anything on yet.")
dialogStr("We moeten blij zijn dat we hier niks per ongeluk aan kunnen zetten.")


dialogId("mot-v-klic", "font_big", "Careful with that wrench.")
dialogStr("Voorzichtig met die steeksleutel.")


dialogId("mot-m-ublizit", "font_small", "I can’t harm anything here.")
dialogStr("Ik kan hier toch niks kapot maken.")


dialogId("mot-m-zvuky0", "font_small", "What have you done? Turn off that roar!")
dialogStr("Wat heb je gedaan? Zet die herrie uit!")


dialogId("mot-m-zvuky1", "font_small", "This is terrible! Turn it off before it’s too late!")
dialogStr("Aaarggg! Zet het snel weer uit!")


dialogId("mot-v-nemuzu0", "font_big", "I can’t! I can’t take it out!")
dialogStr("Het lukt niet. Ik krijg het er niet uit!")


dialogId("mot-v-nemuzu1", "font_big", "I don’t know how! I can’t take it out!")
dialogStr("Hoe dan? Ik krijg het er niet meer uit!")


dialogId("mot-m-mayday", "font_small", "Mayday! Mayday!")
dialogStr("Mayday! Mayday!")


dialogId("mot-v-konecne0", "font_big", "Finally.")
dialogStr("Eindelijk.")


dialogId("mot-v-konecne1", "font_big", "What a relief.")
dialogStr("Wat een opluchting.")


dialogId("mot-v-zvuky0", "font_big", "What are you doing? Where are we going?")
dialogStr("Wat doe je nou? Waar gaan we heen?")


dialogId("mot-v-zvuky1", "font_big", "What have you activated? Where is it taking us?")
dialogStr("Waar heb je aan gezeten? Waar brengt dit ding ons heen?")


dialogId("mot-m-nemuzu0", "font_small", "How can I turn it off?!")
dialogStr("Hoe krijg ik dit uit?!")


dialogId("mot-m-nemuzu1", "font_small", "I can’t turn it off!")
dialogStr("Ik krijg hem niet uit!")


dialogId("mot-m-konecne0", "font_small", "Thanks.")
dialogStr("Bedankt.")


dialogId("mot-m-konecne1", "font_small", "Finally.")
dialogStr("Eindelijk.")


dialogId("mot-v-znovu0", "font_big", "I am only afraid we’ll have to turn it on again.")
dialogStr("Ik ben alleen bang dat we hem weer aan moeten zetten.")

