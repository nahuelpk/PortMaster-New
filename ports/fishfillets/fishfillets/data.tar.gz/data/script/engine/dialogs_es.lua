
dialogId("mot-m-info", "font_small", "I think we can gain some information about the interstellar propulsion here.")
dialogStr("Creo que podríamos ganar algo de información acerca de la propulsión interestelar aquí.")


dialogId("mot-v-konvencni", "font_big", "This looks more like conventional propulsion for the landing craft.")
dialogStr("Esto luce mas como propulsión convencional para la lancha de desembarque.")


dialogId("mot-m-tak", "font_small", "So. We found the drive. We have achieved one of the objectives of our mission.")
dialogStr("En fin. Encontramos el motor. Hemos alcanzado uno de los objetivos de nuestra misión.")


dialogId("mot-v-zavery", "font_big", "Don’t be so hasty. We haven’t searched the whole wreck yet.")
dialogStr("No te apures. No hemos buscado en toda la grieta aún.")


dialogId("mot-m-akce0", "font_small", "I am sorry that none of these technical marvels around us work.")
dialogStr("Siento mucho que ninguna de esas maravillas técnicas alrededor nuestro funcione.")


dialogId("mot-m-akce1", "font_small", "I’d like to see some of these extraterrestrial gizmos in action.")
dialogStr("Me gustaría ver alguno de esos aparatos extraterestres en acción.")


dialogId("mot-m-akce2", "font_small", "I wonder if this motor could work under water.")
dialogStr("Me pregunto si este motor podría funcionar bajo el agua.")


dialogId("mot-v-funkce0", "font_big", "Maybe it’s better for us if it doesn’t work.")
dialogStr("Quizás es mejor para nosotros que no funcione.")


dialogId("mot-v-funkce1", "font_big", "I am rather glad we cannot turn anything on here.")
dialogStr("Estoy algo alegre de que no podamos encender nada aquí.")


dialogId("mot-v-funkce2", "font_big", "We should be happy that we could not switch anything on yet.")
dialogStr("Deberíamos estar felices de que no pudimos encender nada aún.")


dialogId("mot-v-klic", "font_big", "Careful with that wrench.")
dialogStr("Ten cuidado con esa llave.")


dialogId("mot-m-ublizit", "font_small", "I can’t harm anything here.")
dialogStr("No puedo romper nada aquí.")


dialogId("mot-m-zvuky0", "font_small", "What have you done? Turn off that roar!")
dialogStr("¿Qué haz hecho? ¡Apaga eso!")


dialogId("mot-m-zvuky1", "font_small", "This is terrible! Turn it off before it’s too late!")
dialogStr("¡Esto es terrible! ¡Apágalo antes de que sea muy tarde!")


dialogId("mot-v-nemuzu0", "font_big", "I can’t! I can’t take it out!")
dialogStr("¡No puedo! ¡No puedo apagarlo!")


dialogId("mot-v-nemuzu1", "font_big", "I don’t know how! I can’t take it out!")
dialogStr("¡No sé como! ¡No lo puedo apagar!")


dialogId("mot-m-mayday", "font_small", "Mayday! Mayday!")
dialogStr("Mayday! Mayday!")


dialogId("mot-v-konecne0", "font_big", "Finally.")
dialogStr("Al fin.")


dialogId("mot-v-konecne1", "font_big", "What a relief.")
dialogStr("Que alivio.")


dialogId("mot-v-zvuky0", "font_big", "What are you doing? Where are we going?")
dialogStr("¿Qué estás haciendo? ¿Hacia donde vamos?")


dialogId("mot-v-zvuky1", "font_big", "What have you activated? Where is it taking us?")
dialogStr("¿Qué haz activado? ¿Hacia donde nos lleva?")


dialogId("mot-m-nemuzu0", "font_small", "How can I turn it off?!")
dialogStr("¡¿Como lo puedo apagar?!")


dialogId("mot-m-nemuzu1", "font_small", "I can’t turn it off!")
dialogStr("¡No lo puedo apagar!")


dialogId("mot-m-konecne0", "font_small", "Thanks.")
dialogStr("Gracias.")


dialogId("mot-m-konecne1", "font_small", "Finally.")
dialogStr("Al fin.")


dialogId("mot-v-znovu0", "font_big", "I am only afraid we’ll have to turn it on again.")
dialogStr("Solo me preocupa que lo tengamos que encender de nuevo.")

