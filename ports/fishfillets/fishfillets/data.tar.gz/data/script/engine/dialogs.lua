
dialogLoad("script/"..codename.."/")
