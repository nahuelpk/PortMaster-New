
dialogId("mot-m-info", "font_small", "I think we can gain some information about the interstellar propulsion here.")
dialogStr("Penso che qui potremo trarre alcune informazioni sulla propulsione interstellare.")


dialogId("mot-v-konvencni", "font_big", "This looks more like conventional propulsion for the landing craft.")
dialogStr("Sembra più un normale propulsore per la navetta di atterraggio.")


dialogId("mot-m-tak", "font_small", "So. We found the drive. We have achieved one of the objectives of our mission.")
dialogStr("E così abbiamo trovato il motore. Abbiamo raggiuntouno degli obiettivi della nostra missione.")


dialogId("mot-v-zavery", "font_big", "Don’t be so hasty. We haven’t searched the whole wreck yet.")
dialogStr("Non essere così impazionete. Non abbiamo ancora perlustrato tutto il rottame.")


dialogId("mot-m-akce0", "font_small", "I am sorry that none of these technical marvels around us work.")
dialogStr("Mi dispiace che nessuna di queste meraviglie della tecnica qui intorno funzioni.")


dialogId("mot-m-akce1", "font_small", "I’d like to see some of these extraterrestrial gizmos in action.")
dialogStr("Mi piacerebbe vedere un po' di questi aggeggi extraterrestri in azione.")


dialogId("mot-m-akce2", "font_small", "I wonder if this motor could work under water.")
dialogStr("Mi domando se questo motore possa funzionare sott'acqua.")


dialogId("mot-v-funkce0", "font_big", "Maybe it’s better for us if it doesn’t work.")
dialogStr("Forse è meglio per noi se non funziona.")


dialogId("mot-v-funkce1", "font_big", "I am rather glad we cannot turn anything on here.")
dialogStr("Sono piuttosto contento che non possiamo accendere niente qui.")


dialogId("mot-v-funkce2", "font_big", "We should be happy that we could not switch anything on yet.")
dialogStr("Dovremo essere felici di non aver attivato ancora niente.")


dialogId("mot-v-klic", "font_big", "Careful with that wrench.")
dialogStr("Attenta con quella chiave inglese.")


dialogId("mot-m-ublizit", "font_small", "I can’t harm anything here.")
dialogStr("Non posso danneggiare niente qui.")


dialogId("mot-m-zvuky0", "font_small", "What have you done? Turn off that roar!")
dialogStr("Cosa hai fatto? Spegni quel baccano!")


dialogId("mot-m-zvuky1", "font_small", "This is terrible! Turn it off before it’s too late!")
dialogStr("Che disgrazia! Spegnilo prima che sia troppo tardi!")


dialogId("mot-v-nemuzu0", "font_big", "I can’t! I can’t take it out!")
dialogStr("Non posso! Non riesco a tirarlo fuori!")


dialogId("mot-v-nemuzu1", "font_big", "I don’t know how! I can’t take it out!")
dialogStr("Non so come! Non riesco a tirarlo fuori!")


dialogId("mot-m-mayday", "font_small", "Mayday! Mayday!")
dialogStr("Mayday! Mayday!")


dialogId("mot-v-konecne0", "font_big", "Finally.")
dialogStr("Finalmente.")


dialogId("mot-v-konecne1", "font_big", "What a relief.")
dialogStr("Che sollievo.")


dialogId("mot-v-zvuky0", "font_big", "What are you doing? Where are we going?")
dialogStr("Cosa fai? Dove sei?")


dialogId("mot-v-zvuky1", "font_big", "What have you activated? Where is it taking us?")
dialogStr("Cos'hai acceso? Dove ci porta?")


dialogId("mot-m-nemuzu0", "font_small", "How can I turn it off?!")
dialogStr("Come faccio a spegnerlo?!")


dialogId("mot-m-nemuzu1", "font_small", "I can’t turn it off!")
dialogStr("Non riesco a spegnerlo!")


dialogId("mot-m-konecne0", "font_small", "Thanks.")
dialogStr("Grazie.")


dialogId("mot-m-konecne1", "font_small", "Finally.")
dialogStr("Finalmente.")


dialogId("mot-v-znovu0", "font_big", "I am only afraid we’ll have to turn it on again.")
dialogStr("Ho solo paura che dovremo accenderlo ancora.")

