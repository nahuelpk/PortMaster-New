
dialogId("mot-m-akce1", "font_small", "I’d like to see some of these extraterrestrial gizmos in action.")
dialogStr("Ich will mal eins dieser ausserirdischen Dinger in Aktion erleben!.")


dialogId("mot-v-nemuzu1", "font_big", "I don’t know how! I can’t take it out!")
dialogStr("Ich weiss nicht wie! Ich krieg’s nicht aus!")

