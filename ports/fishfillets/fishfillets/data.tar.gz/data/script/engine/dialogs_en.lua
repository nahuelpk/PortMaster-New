
dialogId("mot-m-info", "font_small", "I think we can gain some information about the interstellar propulsion here.")

dialogId("mot-v-konvencni", "font_big", "This looks more like conventional propulsion for the landing craft.")

dialogId("mot-m-tak", "font_small", "So. We found the drive. We have achieved one of the objectives of our mission.")

dialogId("mot-v-zavery", "font_big", "Don’t be so hasty. We haven’t searched the whole wreck yet.")

dialogId("mot-m-akce0", "font_small", "I am sorry that none of these technical marvels around us work.")

dialogId("mot-m-akce1", "font_small", "I’d like to see some of these extraterrestrial gizmos in action.")

dialogId("mot-m-akce2", "font_small", "I wonder if this motor could work under water.")

dialogId("mot-v-funkce0", "font_big", "Maybe it’s better for us if it doesn’t work.")

dialogId("mot-v-funkce1", "font_big", "I am rather glad we cannot turn anything on here.")

dialogId("mot-v-funkce2", "font_big", "We should be happy that we could not switch anything on yet.")

dialogId("mot-v-klic", "font_big", "Careful with that wrench.")

dialogId("mot-m-ublizit", "font_small", "I can’t harm anything here.")

dialogId("mot-m-zvuky0", "font_small", "What have you done? Turn off that roar!")

dialogId("mot-m-zvuky1", "font_small", "This is terrible! Turn it off before it’s too late!")

dialogId("mot-v-nemuzu0", "font_big", "I can’t! I can’t take it out!")

dialogId("mot-v-nemuzu1", "font_big", "I don’t know how! I can’t take it out!")

dialogId("mot-m-mayday", "font_small", "Mayday! Mayday!")

dialogId("mot-v-konecne0", "font_big", "Finally.")

dialogId("mot-v-konecne1", "font_big", "What a relief.")

dialogId("mot-v-zvuky0", "font_big", "What are you doing? Where are we going?")

dialogId("mot-v-zvuky1", "font_big", "What have you activated? Where is it taking us?")

dialogId("mot-m-nemuzu0", "font_small", "How can I turn it off?!")

dialogId("mot-m-nemuzu1", "font_small", "I can’t turn it off!")

dialogId("mot-m-konecne0", "font_small", "Thanks.")

dialogId("mot-m-konecne1", "font_small", "Finally.")

dialogId("mot-v-znovu0", "font_big", "I am only afraid we’ll have to turn it on again.")

dialogId("mot-x-motor", "", "")
