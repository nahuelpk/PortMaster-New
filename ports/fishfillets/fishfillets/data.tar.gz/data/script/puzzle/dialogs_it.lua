
dialogId("puc-m-koukej", "font_small", "Look what we can find on such a dump.")
dialogStr("Guardo cosa si trova in questa pattumiera.")

dialogId("puc-v-podivej", "font_big", "It’s interesting what kind of stuff somebody will throw out.")
dialogStr("È interessante la roba che qualcuno butta via.")

dialogId("puc-v-videl", "font_big", "I am sure I have seen this woman somewhere.")
dialogStr("Sono sicuro di aver già visto questa donna da qualche parte.")

dialogId("puc-m-oblicej", "font_small", "You are probably wrong. It’s a completely plain face.")
dialogStr("Per me ti sbagli, è un viso che non mi dice niente.")

dialogId("puc-m-pld0", "font_small", "Look at that thing.")
dialogStr("Guarda quella cosa.")

dialogId("puc-m-pld1", "font_small", "Look at that pld. What a monster.")
dialogStr("Guarda quel pld. È un mostro.")

dialogId("puc-m-hele", "font_small", "Oh, my, this is repulsive.")
dialogStr("Povera me, è ributtante.")

dialogId("puc-m-slizka", "font_small", "Repulsive, slimy, dirty and in the way.")
dialogStr("Ributtante, viscido, sporco e d'intralcio.")

dialogId("puc-v-fuska0", "font_big", "It’s taxing.")
dialogStr("Che fatica!")

dialogId("puc-v-fuska1", "font_big", "It’s quite demanding.")
dialogStr("Piuttosto inpegnativo.")

dialogId("puc-v-fuska2", "font_big", "It was a lot of work.")
dialogStr("È stato un lavorone.")

dialogId("puc-m-stalo", "font_small", "But it paid off, didn’t it?")
dialogStr("Me gratificante, no?")

dialogId("puc-m-obraz", "font_small", "Just imagine it was some precious painting and we have saved it!")
dialogStr("Pensa se fosse un prezioso dipinto, e noi lo abbiamo salvato!")

dialogId("puc-v-nesmysl", "font_big", "What  nonsense!")
dialogStr("Che sciocchezze!")
