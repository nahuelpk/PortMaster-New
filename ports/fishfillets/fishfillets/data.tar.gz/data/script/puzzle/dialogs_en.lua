
dialogId("puc-m-koukej", "font_small", "Look what we can find on such a dump.")

dialogId("puc-v-podivej", "font_big", "It’s interesting what kind of stuff somebody will throw out.")

dialogId("puc-v-videl", "font_big", "I am sure I have seen this woman somewhere.")

dialogId("puc-m-oblicej", "font_small", "You are probably wrong. It’s a completely plain face.")

dialogId("puc-m-pld0", "font_small", "Look at that thing.")

dialogId("puc-m-pld1", "font_small", "Look at that pld. What a monster.")

dialogId("puc-m-hele", "font_small", "Oh, my, this is repulsive.")

dialogId("puc-m-slizka", "font_small", "Repulsive, slimy, dirty and in the way.")

dialogId("puc-v-fuska0", "font_big", "It’s taxing.")

dialogId("puc-v-fuska1", "font_big", "It’s quite demanding.")

dialogId("puc-v-fuska2", "font_big", "It was a lot of work.")

dialogId("puc-m-stalo", "font_small", "But it paid off, didn’t it?")

dialogId("puc-m-obraz", "font_small", "Just imagine it was some precious painting and we have saved it!")

dialogId("puc-v-nesmysl", "font_big", "What  nonsense!")

dialogId("puc-x-pldik", "font_pink", "MUAHHH... UAHH... UUUH...")
