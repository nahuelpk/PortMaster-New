
dialogId("puc-m-koukej", "font_small", "Look what we can find on such a dump.")
dialogStr("Schau, was man alles so auf einer Müllhalde finden kann!")


dialogId("puc-v-podivej", "font_big", "It’s interesting what kind of stuff somebody will throw out.")
dialogStr("Interessant, was die Leute so wegwerfen.")


dialogId("puc-v-videl", "font_big", "I am sure I have seen this woman somewhere.")
dialogStr("Ich hab die Frau mit Sicherheit schon mal gesehen.")


dialogId("puc-m-oblicej", "font_small", "You are probably wrong. It’s a completely plain face.")
dialogStr("Du irrst dich wahrscheinlich, das ist ein einfaches Gesicht.")


dialogId("puc-m-pld0", "font_small", "Look at that thing.")
dialogStr("Schau dir das mal an.")


dialogId("puc-m-pld1", "font_small", "Look at that pld. What a monster.")
dialogStr("Schau dir das mal an. Was für ein Monster!")


dialogId("puc-m-hele", "font_small", "Oh, my, this is repulsive.")
dialogStr("Bäh, ist das eklig.")


dialogId("puc-m-slizka", "font_small", "Repulsive, slimy, dirty and in the way.")
dialogStr("Eklig, schleimig, schutzig und im Weg.")


dialogId("puc-v-fuska0", "font_big", "It’s taxing.")
dialogStr("Das ist ermüdend.")


dialogId("puc-v-fuska1", "font_big", "It’s quite demanding.")
dialogStr("Das ist ziemlich anstrengend.")


dialogId("puc-v-fuska2", "font_big", "It was a lot of work.")
dialogStr("Das war ’ne Menge Arbeit.")


dialogId("puc-m-stalo", "font_small", "But it paid off, didn’t it?")
dialogStr("Aber es hat sich ausgezahlt, oder?")


dialogId("puc-m-obraz", "font_small", "Just imagine it was some precious painting and we have saved it!")
dialogStr("Stell dir vor, es war ein schönes Gemälde und wir haben es gerettet!")


dialogId("puc-v-nesmysl", "font_big", "What  nonsense!")
dialogStr("Blödsinn!")

