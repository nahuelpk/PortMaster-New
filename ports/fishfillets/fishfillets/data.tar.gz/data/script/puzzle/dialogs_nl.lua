
dialogId("puc-m-koukej", "font_small", "Look what we can find on such a dump.")
dialogStr("Kijk eens wat je op zo'n vuilnishoop kunt vinden.")


dialogId("puc-v-podivej", "font_big", "It’s interesting what kind of stuff somebody will throw out.")
dialogStr("Het is interessant om te zien wat mensen weggooien.")


dialogId("puc-v-videl", "font_big", "I am sure I have seen this woman somewhere.")
dialogStr("Ik heb deze vrouw al eens eerder gezien.")


dialogId("puc-m-oblicej", "font_small", "You are probably wrong. It’s a completely plain face.")
dialogStr("Misschien vergis je je. Ze is niet bijzonder knap.")


dialogId("puc-m-pld0", "font_small", "Look at that thing.")
dialogStr("Moet je dat zien.")


dialogId("puc-m-pld1", "font_small", "Look at that pld. What a monster.")
dialogStr("Moet je dat zien. Wat een monster!")


dialogId("puc-m-hele", "font_small", "Oh, my, this is repulsive.")
dialogStr("Bah, wat vies.")


dialogId("puc-m-slizka", "font_small", "Repulsive, slimy, dirty and in the way.")
dialogStr("Vies, slijmerig, goor en in de weg.")


dialogId("puc-v-fuska0", "font_big", "It’s taxing.")
dialogStr("Wat lastig toch allemaal.")


dialogId("puc-v-fuska1", "font_big", "It’s quite demanding.")
dialogStr("Dit is behoorlijk zwaar werk.")


dialogId("puc-v-fuska2", "font_big", "It was a lot of work.")
dialogStr("Dat was een flinke klus.")


dialogId("puc-m-stalo", "font_small", "But it paid off, didn’t it?")
dialogStr("Maar het was de moeite waard, toch?")


dialogId("puc-m-obraz", "font_small", "Just imagine it was some precious painting and we have saved it!")
dialogStr("Stel je voor dat het een belangrijk meesterwerk was en dat wij het zojuist hebben gered!")


dialogId("puc-v-nesmysl", "font_big", "What  nonsense!")
dialogStr("Wat een onzin!")

