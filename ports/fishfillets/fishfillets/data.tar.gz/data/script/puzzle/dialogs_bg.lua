dialogId("puc-m-koukej", "font_small", "Look what we can find on such a dump.")
dialogStr("Я какви неща могат да се намерят на сметището.")

dialogId("puc-v-podivej", "font_big", "It’s interesting what kind of stuff somebody will throw out.")
dialogStr("Интересно какви неща изхвърлят хората.")

dialogId("puc-v-videl", "font_big", "I am sure I have seen this woman somewhere.")
dialogStr("Сигурен съм, че съм виждал тази жена някъде.")

dialogId("puc-m-oblicej", "font_small", "You are probably wrong. It’s a completely plain face.")
dialogStr("Сигурно грешиш. Има типична физиономия.")

dialogId("puc-m-pld0", "font_small", "Look at that thing.")
dialogStr("Погледни това нещо.")

dialogId("puc-m-pld1", "font_small", "Look at that pld. What a monster.")
dialogStr("Погледни това. Какво чудовище.")

dialogId("puc-m-hele", "font_small", "Oh, my, this is repulsive.")
dialogStr("О, това е отблъскващо.")

dialogId("puc-m-slizka", "font_small", "Repulsive, slimy, dirty and in the way.")
dialogStr("Отблъскващо, лигаво, мръсно и пречи.")

dialogId("puc-v-fuska0", "font_big", "It’s taxing.")
dialogStr("Данъците!.")

dialogId("puc-v-fuska1", "font_big", "It’s quite demanding.")
dialogStr("Тоста труд си трябва.")

dialogId("puc-v-fuska2", "font_big", "It was a lot of work.")
dialogStr("Бая работа трябваше.")

dialogId("puc-m-stalo", "font_small", "But it paid off, didn’t it?")
dialogStr("Но си заслужаваше, нали?")

dialogId("puc-m-obraz", "font_small", "Just imagine it was some precious painting and we have saved it!")
dialogStr("Представи си само, че беше някоя ценна картина и ние сме я спасили!")

dialogId("puc-v-nesmysl", "font_big", "What  nonsense!")
dialogStr("Ама че глупост!")

dialogId("puc-x-pldik", "font_pink", "MUAHHH... UAHH... UUUH...")
dialogStr("МУАХ... УАХ... УХ...")

