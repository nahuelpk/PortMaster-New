
dialogId("puc-m-koukej", "font_small", "Look what we can find on such a dump.")
dialogStr("Смотри-ка, что можно найти на такой свалке.")

dialogId("puc-v-podivej", "font_big", "It’s interesting what kind of stuff somebody will throw out.")
dialogStr("Интересно, какие вещи люди выкидывают.")

dialogId("puc-v-videl", "font_big", "I am sure I have seen this woman somewhere.")
dialogStr("Я точно видел где-то эту женщину.")

dialogId("puc-m-oblicej", "font_small", "You are probably wrong. It’s a completely plain face.")
dialogStr("Вероятно, ты ошибаешься. Лицо совершенно типичное.")

dialogId("puc-m-pld0", "font_small", "Look at that thing.")
dialogStr("Посмотри на ту штуку.")

dialogId("puc-m-pld1", "font_small", "Look at that pld. What a monster.")
dialogStr("Посмотри на то чудище.")

dialogId("puc-m-hele", "font_small", "Oh, my, this is repulsive.")
dialogStr("Фу, оно просто отвратительно.")

dialogId("puc-m-slizka", "font_small", "Repulsive, slimy, dirty and in the way.")
dialogStr("Отвратительное, склизкое и грязное, да к тому же на дороге.")

dialogId("puc-v-fuska0", "font_big", "It’s taxing.")
dialogStr("Это нелегко.")

dialogId("puc-v-fuska1", "font_big", "It’s quite demanding.")
dialogStr("Довольно трудно.")

dialogId("puc-v-fuska2", "font_big", "It was a lot of work.")
dialogStr("Эта была нелёгкая работа.")

dialogId("puc-m-stalo", "font_small", "But it paid off, didn’t it?")
dialogStr("Но это того стоило, не правда ли?")

dialogId("puc-m-obraz", "font_small", "Just imagine it was some precious painting and we have saved it!")
dialogStr("Представь, что это была очень ценная картина, и мы ее спасли!")

dialogId("puc-v-nesmysl", "font_big", "What  nonsense!")
dialogStr("Что за чепуха!")

dialogId("puc-x-pldik", "font_pink", "MUAHHH... UAHH... UUUH...")
dialogStr("УАААХХ... ААХХ... УУУХ...")

