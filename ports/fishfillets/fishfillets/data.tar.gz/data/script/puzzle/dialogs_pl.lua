
dialogId("puc-m-koukej", "font_small", "Look what we can find on such a dump.")
dialogStr("Czego to człowiek nie znajdzie na takim wysypisku...")


dialogId("puc-v-podivej", "font_big", "It’s interesting what kind of stuff somebody will throw out.")
dialogStr("Ciekawe rzeczy ludzie wyrzucają.")


dialogId("puc-v-videl", "font_big", "I am sure I have seen this woman somewhere.")
dialogStr("Ja tę kobietę już gdzieś widziałem.")


dialogId("puc-m-oblicej", "font_small", "You are probably wrong. It’s a completely plain face.")
dialogStr("Wydaje ci się. Z twarzy podobna zupełnie do nikogo.")


dialogId("puc-m-pld0", "font_small", "Look at that thing.")
dialogStr("Spójrz na to coś.")


dialogId("puc-m-pld1", "font_small", "Look at that pld. What a monster.")
dialogStr("Spójrz na tego plda. Co za potwora.")


dialogId("puc-m-hele", "font_small", "Oh, my, this is repulsive.")
dialogStr("Och, to jest odrażające!")


dialogId("puc-m-slizka", "font_small", "Repulsive, slimy, dirty and in the way.")
dialogStr("Odrażające, oślizgłe, brudne i stoi nam na drodze.")


dialogId("puc-v-fuska0", "font_big", "It’s taxing.")
dialogStr("Męcząca praca.")


dialogId("puc-v-fuska1", "font_big", "It’s quite demanding.")
dialogStr("Dość wymagające zadanie.")


dialogId("puc-v-fuska2", "font_big", "It was a lot of work.")
dialogStr("Się napracowaliśmy.")


dialogId("puc-m-stalo", "font_small", "But it paid off, didn’t it?")
dialogStr("Ale było warto, czyż nie?")


dialogId("puc-m-obraz", "font_small", "Just imagine it was some precious painting and we have saved it!")
dialogStr("Wyobraź sobie, że to był cenny obraz, a my go uratowaliśmy.")


dialogId("puc-v-nesmysl", "font_big", "What  nonsense!")
dialogStr("Też wymyśliłaś.")

