
dialogId("puc-m-koukej", "font_small", "Look what we can find on such a dump.")
dialogStr("Voyons ce que nous pouvons trouver dans un tel dépotoir.")


dialogId("puc-v-podivej", "font_big", "It’s interesting what kind of stuff somebody will throw out.")
dialogStr("Il est intéressant de voir quelle camelote peut être jetée par les gens.")


dialogId("puc-v-videl", "font_big", "I am sure I have seen this woman somewhere.")
dialogStr("Je suis sûr que j'ai vu cette femme quelque part.")


dialogId("puc-m-oblicej", "font_small", "You are probably wrong. It’s a completely plain face.")
dialogStr("Tu te trompes probablement. C'est un visage plutôt quelconque.")


dialogId("puc-m-pld0", "font_small", "Look at that thing.")
dialogStr("Regarde cet objet.")


dialogId("puc-m-pld1", "font_small", "Look at that pld. What a monster.")
dialogStr("Regarde cette chose. Quel monstre.")


dialogId("puc-m-hele", "font_small", "Oh, my, this is repulsive.")
dialogStr("Oh, c'est répugnant.")


dialogId("puc-m-slizka", "font_small", "Repulsive, slimy, dirty and in the way.")
dialogStr("Répugnant, glaireux, sale et en travers du chemin.")


dialogId("puc-v-fuska0", "font_big", "It’s taxing.")
dialogStr("C'est fatigant.")


dialogId("puc-v-fuska1", "font_big", "It’s quite demanding.")
dialogStr("C'est trop exiger.")


dialogId("puc-v-fuska2", "font_big", "It was a lot of work.")
dialogStr("C'est beaucoup de boulot.")


dialogId("puc-m-stalo", "font_small", "But it paid off, didn’t it?")
dialogStr("Mais c'est payant, tu ne trouves pas ?")


dialogId("puc-m-obraz", "font_small", "Just imagine it was some precious painting and we have saved it!")
dialogStr("Imagine simplement que c'est un précieux tableau et que nous l'avons sauvé.")


dialogId("puc-v-nesmysl", "font_big", "What  nonsense!")
dialogStr("N'importe quoi !")

