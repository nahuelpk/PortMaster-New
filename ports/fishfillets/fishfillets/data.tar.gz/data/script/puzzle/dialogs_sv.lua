
dialogId("puc-m-koukej", "font_small", "Look what we can find on such a dump.")
dialogStr("Titta vad vi kan hitta på en sådan här tipp!")


dialogId("puc-v-podivej", "font_big", "It’s interesting what kind of stuff somebody will throw out.")
dialogStr("Det är otroligt vad mycket grejer som folk slänger bort.")


dialogId("puc-v-videl", "font_big", "I am sure I have seen this woman somewhere.")
dialogStr("Jag är säker på att jag har sett kvinnan förut.")


dialogId("puc-m-oblicej", "font_small", "You are probably wrong. It’s a completely plain face.")
dialogStr("Du har antagligen fel. Det är ett så alldagligt ansikte.")


dialogId("puc-m-pld0", "font_small", "Look at that thing.")
dialogStr("Titta på den där saken.")


dialogId("puc-m-pld1", "font_small", "Look at that pld. What a monster.")
dialogStr("Titta på den där. Vilket monster!")


dialogId("puc-m-hele", "font_small", "Oh, my, this is repulsive.")
dialogStr("Usch, den är äcklig.")


dialogId("puc-m-slizka", "font_small", "Repulsive, slimy, dirty and in the way.")
dialogStr("Äcklig, slemmig, smutsig och ivägen.")


dialogId("puc-v-fuska0", "font_big", "It’s taxing.")
dialogStr("Det är jobbigt.")


dialogId("puc-v-fuska1", "font_big", "It’s quite demanding.")
dialogStr("Det är rätt så tungt.")


dialogId("puc-v-fuska2", "font_big", "It was a lot of work.")
dialogStr("Det är mycket arbete.")


dialogId("puc-m-stalo", "font_small", "But it paid off, didn’t it?")
dialogStr("Men det betalade sig, eller hur?")


dialogId("puc-m-obraz", "font_small", "Just imagine it was some precious painting and we have saved it!")
dialogStr("Tänk dig, det var en rätt så dyr målning och vi räddade den!")


dialogId("puc-v-nesmysl", "font_big", "What  nonsense!")
dialogStr("Struntprat!")

