
dialogId("puc-m-koukej", "font_small", "Look what we can find on such a dump.")
dialogStr("Koukej, co se na takovém smetišti najde.")


dialogId("puc-v-podivej", "font_big", "It’s interesting what kind of stuff somebody will throw out.")
dialogStr("Podívej, co ti lidi všechno nevyhodí.")


dialogId("puc-v-videl", "font_big", "I am sure I have seen this woman somewhere.")
dialogStr("Tu ženskou už jsem někde viděl.")


dialogId("puc-m-oblicej", "font_small", "You are probably wrong. It’s a completely plain face.")
dialogStr("To se ti jen zdá, je to úplně tuctový obličej.")


dialogId("puc-m-pld0", "font_small", "Look at that thing.")
dialogStr("Podívej na tu věc.")


dialogId("puc-m-pld1", "font_small", "Look at that pld. What a monster.")
dialogStr("Podívej se na toho plda. To je ale potvora.")


dialogId("puc-m-hele", "font_small", "Oh, my, this is repulsive.")
dialogStr("Hele, to je ale nechutnost.")


dialogId("puc-m-slizka", "font_small", "Repulsive, slimy, dirty and in the way.")
dialogStr("Ošklivá, slizká, špinavá a navíc hrozně zavazí.")


dialogId("puc-v-fuska0", "font_big", "It’s taxing.")
dialogStr("To je ale fuška.")


dialogId("puc-v-fuska1", "font_big", "It’s quite demanding.")
dialogStr("Je to poněkud pracné.")


dialogId("puc-v-fuska2", "font_big", "It was a lot of work.")
dialogStr("To byla ale hokna.")


dialogId("puc-m-stalo", "font_small", "But it paid off, didn’t it?")
dialogStr("Ale stálo to za to, ne?")


dialogId("puc-m-obraz", "font_small", "Just imagine it was some precious painting and we have saved it!")
dialogStr("Představ si, že by to byl třeba nějaký vzácný obraz a my ho zachránili!")


dialogId("puc-v-nesmysl", "font_big", "What  nonsense!")
dialogStr("Nesmysl!")

