
dialogId("puc-m-koukej", "font_small", "Look what we can find on such a dump.")
dialogStr("Mira lo que podemos encontrar en un vertedero como este.")


dialogId("puc-v-podivej", "font_big", "It’s interesting what kind of stuff somebody will throw out.")
dialogStr("Es interesante la clase de cosas que la gente tira.")


dialogId("puc-v-videl", "font_big", "I am sure I have seen this woman somewhere.")
dialogStr("Estoy seguro de haber visto a esta mujer en alguna parte.")


dialogId("puc-m-oblicej", "font_small", "You are probably wrong. It’s a completely plain face.")
dialogStr("Estás probablemente equivocado, es una cara completamente discreta.")


dialogId("puc-m-pld0", "font_small", "Look at that thing.")
dialogStr("Mira esa cosa.")


dialogId("puc-m-pld1", "font_small", "Look at that pld. What a monster.")
dialogStr("Mira esa cosa, que monstruo.")


dialogId("puc-m-hele", "font_small", "Oh, my, this is repulsive.")
dialogStr("Oh, pero que repulsivo es.")


dialogId("puc-m-slizka", "font_small", "Repulsive, slimy, dirty and in the way.")
dialogStr("Repulsivo, fangoso, sucio y está en nuestro camino.")


dialogId("puc-v-fuska0", "font_big", "It’s taxing.")
dialogStr("Es cansador.")


dialogId("puc-v-fuska1", "font_big", "It’s quite demanding.")
dialogStr("Es muy absorbente.")


dialogId("puc-v-fuska2", "font_big", "It was a lot of work.")
dialogStr("Fué un montón de trabajo.")


dialogId("puc-m-stalo", "font_small", "But it paid off, didn’t it?")
dialogStr("Pero es pagado, ¿Cierto?")


dialogId("puc-m-obraz", "font_small", "Just imagine it was some precious painting and we have saved it!")
dialogStr("¡Solo imagina que fué alguna pintura preciosa y la hemos salvado!")


dialogId("puc-v-nesmysl", "font_big", "What  nonsense!")
dialogStr("Que cosa sin sentido.")

