
dialogId("bl-m-zvlastni0", "font_small", "Now this is a strange room.")
dialogStr("Ça c'est une pièce bizarre.")


dialogId("bl-v-zvlastni1", "font_big", "This is a very unusual room.")
dialogStr("C'est vraiment une pièce inhabituelle.")


dialogId("bl-m-funkce", "font_small", "The position of assistant deputy design coordinator was introduced because of this level. So that its author got his own credit.")
dialogStr("Le poste d'assistant pour la coordination du design a été créé à cause de ce niveau. Ainsi l'auteur a son propre mérite.")


dialogId("bl-v-pozadi", "font_big", "Enough about the game background. Let’s get to work.")
dialogStr("Ca Suffit avec l'équipe du jeu et maintenant bossons un peu.")


dialogId("bl-m-koral0", "font_small", "This is a very strange coral.")
dialogStr("Quel étrange corail.")


dialogId("bl-v-koral1", "font_big", "This is a very peculiar coral.")
dialogStr("C'est un corail très particulier.")


dialogId("bl-m-visi", "font_small", "And what does it hang on?")
dialogStr("Et à quoi est-il suspendu ?")


dialogId("bl-v-nevim0", "font_big", "I don’t know. But we have to get it down anyway.")
dialogStr("Je ne sais pas. Mais nous devons le faire tomber de toute façon.")


dialogId("bl-v-nevim1", "font_big", "I don’t know. Do we have to put it down?")
dialogStr("Je ne sais pas. Est-ce que nous devons le faire tomber ?")


dialogId("bl-m-tvar", "font_small", "How could that coral acquire such a bizarre shape?")
dialogStr("Comment le corail a-t-il pu prendre une forme si bizarre.")


dialogId("bl-v-pestovany", "font_big", "It is carefully grown for the logical games players.")
dialogStr("On l'a soigneusement fait pousser pour les jeux de logique.")


dialogId("bl-v-proc", "font_big", "Why do you want to put that coral down, anyway?")
dialogStr("Pourquoi veux-tu faire tomber ce corail, après tout ?")


dialogId("bl-m-zeptej", "font_small", "I have no idea. Ask the player.")
dialogStr("Aucune idée. Demande au joueur.")


dialogId("bl-m-snecku0", "font_small", "Shalimuddy, shalimuddy, put your horns out...")
dialogStr("Escargot content, escargot heureux, sors tes cornes...")


dialogId("bl-v-dost0", "font_big", "Stop it! As if you don’t know that no object will move if we don’t push it first!")
dialogStr("Arrête ça ! Comme si tu ne savais pas qu'aucun objet ne bouge si nous ne l'avons pas poussé avant !")


dialogId("bl-m-snecku1", "font_small", "But I can try, can’t I? Shalimuddy, Shalimuddy...")
dialogStr("Mais je peux essayer, non ? Escargot content, escargot heureux...")


dialogId("bl-v-dost1", "font_big", "Stop it! It makes my scales itch!")
dialogStr("Arrête ! Ça me hérisse les écailles.")


dialogId("bl-m-snecku2", "font_small", "Don’t listen then. Shalimuddy, shalimuddy, put your...")
dialogStr("N'écoute pas alors. Escargot content, escargot heureux, sors tes...")


dialogId("bl-v-dost2", "font_big", "Stop it! Or I’ll drop that coral on your head!")
dialogStr("Arrête ça ! Ou je te lâche ce corail sur la tête !")

