
dialogId("bl-m-zvlastni0", "font_small", "Now this is a strange room.")
dialogStr("Esta si que es una habitación extraña.")


dialogId("bl-v-zvlastni1", "font_big", "This is a very unusual room.")
dialogStr("Esta es una habitación muy inusual.")


dialogId("bl-m-funkce", "font_small", "The position of assistant deputy design coordinator was introduced because of this level. So that its author got his own credit.")
dialogStr("El puesto de asistente de coordinación de diseño fué introducido debido a este nivel. Así que su autor obtuvo su propio crédito.")


dialogId("bl-v-pozadi", "font_big", "Enough about the game background. Let’s get to work.")
dialogStr("Ya basta de hablar sobre el juego. Vamos a trabajar.")


dialogId("bl-m-koral0", "font_small", "This is a very strange coral.")
dialogStr("Este es un coral muy extraño.")


dialogId("bl-v-koral1", "font_big", "This is a very peculiar coral.")
dialogStr("Este es un coral muy peculiar.")


dialogId("bl-m-visi", "font_small", "And what does it hang on?")
dialogStr("¿Y de donde cuelga?")


dialogId("bl-v-nevim0", "font_big", "I don’t know. But we have to get it down anyway.")
dialogStr("No lo sé. Pero tenemos que bajarlo de todas maneras.")


dialogId("bl-v-nevim1", "font_big", "I don’t know. Do we have to put it down?")
dialogStr("No lo sé. ¿Tenemos que ponerlo abajo?")


dialogId("bl-m-tvar", "font_small", "How could that coral acquire such a bizarre shape?")
dialogStr("¿Cómo es que ese coral adquirió una forma tan bizarra?")


dialogId("bl-v-pestovany", "font_big", "It is carefully grown for the logical games players.")
dialogStr("Está cuidadosamente crecido para los juegos de lógica.")


dialogId("bl-v-proc", "font_big", "Why do you want to put that coral down, anyway?")
dialogStr("¿Porqué quieres poner ese coral abajo, de cualquier forma?")


dialogId("bl-m-zeptej", "font_small", "I have no idea. Ask the player.")
dialogStr("No tengo idea. Pregúntale al jugador.")


dialogId("bl-m-snecku0", "font_small", "Shalimuddy, shalimuddy, put your horns out...")
dialogStr("Caracol, caracol, saca tu cachito al sol...")


dialogId("bl-v-dost0", "font_big", "Stop it! As if you don’t know that no object will move if we don’t push it first!")
dialogStr("¡Para! ¡Como si tu no supieras que ningún objeto se moverá si nosotros no lo empujamos primero!")


dialogId("bl-m-snecku1", "font_small", "But I can try, can’t I? Shalimuddy, Shalimuddy...")
dialogStr("Pero puedo intentarlo, ¿Cierto? Caracol, caracol...")


dialogId("bl-v-dost1", "font_big", "Stop it! It makes my scales itch!")
dialogStr("¡Detente! Que se me erizan las escamas.")


dialogId("bl-m-snecku2", "font_small", "Don’t listen then. Shalimuddy, shalimuddy, put your...")
dialogStr("No escuches entonces. Caracol, caracol, saca tu...")


dialogId("bl-v-dost2", "font_big", "Stop it! Or I’ll drop that coral on your head!")
dialogStr("¡Basta! ¡O te voy a tirar ese coral en la cabeza!")

