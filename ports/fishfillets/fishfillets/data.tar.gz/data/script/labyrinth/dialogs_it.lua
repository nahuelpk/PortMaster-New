
dialogId("bl-m-zvlastni0", "font_small", "Now this is a strange room.")
dialogStr("Ecco, questa è proprio una strana stanza.")


dialogId("bl-v-zvlastni1", "font_big", "This is a very unusual room.")
dialogStr("Proprio una strana stanza.")


dialogId("bl-m-funkce", "font_small", "The position of assistant deputy design coordinator was introduced because of this level. So that its author got his own credit.")
dialogStr("La posizione di assistente coordinatore addetto alla progettazione è stata introdotta in virtù di questo livello. Così il suo autore ha avuto il dovuto riconoscimento.")


dialogId("bl-v-pozadi", "font_big", "Enough about the game background. Let’s get to work.")
dialogStr("A posto con i retroscena del gioco e mettiamoci all'opera.")


dialogId("bl-m-koral0", "font_small", "This is a very strange coral.")
dialogStr("Questo è proprio uno strano corallo.")


dialogId("bl-v-koral1", "font_big", "This is a very peculiar coral.")
dialogStr("Che corallo particolare.")


dialogId("bl-m-visi", "font_small", "And what does it hang on?")
dialogStr("A cosa è appeso?")


dialogId("bl-v-nevim0", "font_big", "I don’t know. But we have to get it down anyway.")
dialogStr("Non lo so. Ma dobbiamo tirarlo giù.")


dialogId("bl-v-nevim1", "font_big", "I don’t know. Do we have to put it down?")
dialogStr("Non lo so. Dici che dovremmo tirarlo giù?")


dialogId("bl-m-tvar", "font_small", "How could that coral acquire such a bizarre shape?")
dialogStr("Come può aver acquisito una forma così bizzarra questo corallo?")


dialogId("bl-v-pestovany", "font_big", "It is carefully grown for the logical games players.")
dialogStr("E’ stato accuratamente coltivato per i solutori di rompicapi.")


dialogId("bl-v-proc", "font_big", "Why do you want to put that coral down, anyway?")
dialogStr("Ma perché lo vuoi tirare giù, dopotutto?")


dialogId("bl-m-zeptej", "font_small", "I have no idea. Ask the player.")
dialogStr("Non ne ho idea. Chiedilo al giocatore.")


dialogId("bl-m-snecku0", "font_small", "Shalimuddy, shalimuddy, put your horns out...")
dialogStr("Lumachì, lumacà, le tue corna metti là...")


dialogId("bl-v-dost0", "font_big", "Stop it! As if you don’t know that no object will move if we don’t push it first!")
dialogStr("Smettila! Come se non sapessi che nessun oggetto si muove se noi non lo spingiamo prima!")


dialogId("bl-m-snecku1", "font_small", "But I can try, can’t I? Shalimuddy, Shalimuddy...")
dialogStr("Ma perché non posso provare? Lumachì lumacà...")


dialogId("bl-v-dost1", "font_big", "Stop it! It makes my scales itch!")
dialogStr("Basta! Mi viene l'orticaria alle scaglie!")


dialogId("bl-m-snecku2", "font_small", "Don’t listen then. Shalimuddy, shalimuddy, put your...")
dialogStr("Allora non ascoltare. Lumachì lumacà, le tue corna...")


dialogId("bl-v-dost2", "font_big", "Stop it! Or I’ll drop that coral on your head!")
dialogStr("Smettila! O ti tiro quel corallo in testa!")

