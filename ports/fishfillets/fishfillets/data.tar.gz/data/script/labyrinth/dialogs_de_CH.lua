
dialogId("bl-v-nevim0", "font_big", "I don’t know. But we have to get it down anyway.")
dialogStr("Ich weiss nicht. Jedenfalls müssen wir sie da runterkriegen.")


dialogId("bl-v-nevim1", "font_big", "I don’t know. Do we have to put it down?")
dialogStr("Ich weiss nicht. Müssen wir sie da runterholen?")


dialogId("bl-v-dost0", "font_big", "Stop it! As if you don’t know that no object will move if we don’t push it first!")
dialogStr("Hör auf! Du weisst doch, dass sich Gegenstände nur bewegen, wenn wir sie schieben!")


dialogId("bl-v-dost2", "font_big", "Stop it! Or I’ll drop that coral on your head!")
dialogStr("Hör auf!!! Oder ich schmeiss dir die Koralle auf den Kopf!")

