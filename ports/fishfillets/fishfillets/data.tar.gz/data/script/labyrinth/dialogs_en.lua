
dialogId("bl-m-zvlastni0", "font_small", "Now this is a strange room.")

dialogId("bl-v-zvlastni1", "font_big", "This is a very unusual room.")

dialogId("bl-m-funkce", "font_small", "The position of assistant deputy design coordinator was introduced because of this level. So that its author got his own credit.")

dialogId("bl-v-pozadi", "font_big", "Enough about the game background. Let’s get to work.")

dialogId("bl-m-koral0", "font_small", "This is a very strange coral.")

dialogId("bl-v-koral1", "font_big", "This is a very peculiar coral.")

dialogId("bl-m-visi", "font_small", "And what does it hang on?")

dialogId("bl-v-nevim0", "font_big", "I don’t know. But we have to get it down anyway.")

dialogId("bl-v-nevim1", "font_big", "I don’t know. Do we have to put it down?")

dialogId("bl-m-tvar", "font_small", "How could that coral acquire such a bizarre shape?")

dialogId("bl-v-pestovany", "font_big", "It is carefully grown for the logical games players.")

dialogId("bl-v-proc", "font_big", "Why do you want to put that coral down, anyway?")

dialogId("bl-m-zeptej", "font_small", "I have no idea. Ask the player.")

dialogId("bl-m-snecku0", "font_small", "Shalimuddy, shalimuddy, put your horns out...")

dialogId("bl-v-dost0", "font_big", "Stop it! As if you don’t know that no object will move if we don’t push it first!")

dialogId("bl-m-snecku1", "font_small", "But I can try, can’t I? Shalimuddy, Shalimuddy...")

dialogId("bl-v-dost1", "font_big", "Stop it! It makes my scales itch!")

dialogId("bl-m-snecku2", "font_small", "Don’t listen then. Shalimuddy, shalimuddy, put your...")

dialogId("bl-v-dost2", "font_big", "Stop it! Or I’ll drop that coral on your head!")
