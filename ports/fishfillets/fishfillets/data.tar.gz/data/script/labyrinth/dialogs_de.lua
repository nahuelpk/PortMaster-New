
dialogId("bl-m-zvlastni0", "font_small", "Now this is a strange room.")
dialogStr("Das ist ja ein komischer Raum.")


dialogId("bl-v-zvlastni1", "font_big", "This is a very unusual room.")
dialogStr("Das ist ein ziemlich ungewöhnlicher Raum.")


dialogId("bl-m-funkce", "font_small", "The position of assistant deputy design coordinator was introduced because of this level. So that its author got his own credit.")
dialogStr("Die Stelle des Assistentenstellvertreters des Entwurfskoordinators wurde aufgrund dieser Ebene eingeführt. Damit wurde der Verfasser geehrt.")


dialogId("bl-v-pozadi", "font_big", "Enough about the game background. Let’s get to work.")
dialogStr("Genug zum Hintergrund des Spiels und ran an die Arbeit.")


dialogId("bl-m-koral0", "font_small", "This is a very strange coral.")
dialogStr("Das ist eine ziemlich seltsame Koralle.")


dialogId("bl-v-koral1", "font_big", "This is a very peculiar coral.")
dialogStr("Das ist eine sehr ungewöhnliche Koralle.")


dialogId("bl-m-visi", "font_small", "And what does it hang on?")
dialogStr("Wo hängt die denn dran?")


dialogId("bl-v-nevim0", "font_big", "I don’t know. But we have to get it down anyway.")
dialogStr("Ich weiß nicht. Jedenfalls müssen wir sie da runterkriegen.")


dialogId("bl-v-nevim1", "font_big", "I don’t know. Do we have to put it down?")
dialogStr("Ich weiß nicht. Müssen wir sie da runterholen?")


dialogId("bl-m-tvar", "font_small", "How could that coral acquire such a bizarre shape?")
dialogStr("Wie konnte diese Koralle solch eine bizarre Form annehmen?")


dialogId("bl-v-pestovany", "font_big", "It is carefully grown for the logical games players.")
dialogStr("Sie ist sorgfältig für die Logikspieler gewachsen.")


dialogId("bl-v-proc", "font_big", "Why do you want to put that coral down, anyway?")
dialogStr("Warum willst du die Koralle überhaupt runterholen?")


dialogId("bl-m-zeptej", "font_small", "I have no idea. Ask the player.")
dialogStr("Keine Ahnung. Frag den Spieler.")


dialogId("bl-m-snecku0", "font_small", "Shalimuddy, shalimuddy, put your horns out...")
dialogStr("Schnecklein, Schnecklein komm heraus...")


dialogId("bl-v-dost0", "font_big", "Stop it! As if you don’t know that no object will move if we don’t push it first!")
dialogStr("Hör auf! Du weißt doch, dass sich Gegenstände nur bewegen, wenn wir sie schieben!")


dialogId("bl-m-snecku1", "font_small", "But I can try, can’t I? Shalimuddy, Shalimuddy...")
dialogStr("Aber ich kann es doch versuchen, oder? Schnecklein, Schnecklein...")


dialogId("bl-v-dost1", "font_big", "Stop it! It makes my scales itch!")
dialogStr("Hör auf!! Da sträuben sich mir ja die Schuppen!")


dialogId("bl-m-snecku2", "font_small", "Don’t listen then. Shalimuddy, shalimuddy, put your...")
dialogStr("Dann hör nicht zu. Schnecklein, Schnecklein, komm...")


dialogId("bl-v-dost2", "font_big", "Stop it! Or I’ll drop that coral on your head!")
dialogStr("Hör auf!!! Oder ich schmeiß dir die Koralle auf den Kopf!")

