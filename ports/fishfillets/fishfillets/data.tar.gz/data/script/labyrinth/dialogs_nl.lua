
dialogId("bl-m-zvlastni0", "font_small", "Now this is a strange room.")
dialogStr("Dit is een rare ruimte.")


dialogId("bl-v-zvlastni1", "font_big", "This is a very unusual room.")
dialogStr("Dit is een ongewone ruimte.")


dialogId("bl-m-funkce", "font_small", "The position of assistant deputy design coordinator was introduced because of this level. So that its author got his own credit.")
dialogStr("De positie van assistent vice-designcoordinator is in het leven geroepen vanwege dit veld. Zodat de auteur ervan z'n naam in de aftiteling kreeg.")


dialogId("bl-v-pozadi", "font_big", "Enough about the game background. Let’s get to work.")
dialogStr("Genoeg achtergrondinformatie. Aan het werk.")


dialogId("bl-m-koral0", "font_small", "This is a very strange coral.")
dialogStr("Dat is een raar stuk koraal.")


dialogId("bl-v-koral1", "font_big", "This is a very peculiar coral.")
dialogStr("Dat is een vreemd stuk koraal.")


dialogId("bl-m-visi", "font_small", "And what does it hang on?")
dialogStr("En waar zit het aan vast?")


dialogId("bl-v-nevim0", "font_big", "I don’t know. But we have to get it down anyway.")
dialogStr("Ik heb geen idee. Maar we moeten het wel los zien te krijgen.")


dialogId("bl-v-nevim1", "font_big", "I don’t know. Do we have to put it down?")
dialogStr("Ik weet het niet. Moeten we het los maken?")


dialogId("bl-m-tvar", "font_small", "How could that coral acquire such a bizarre shape?")
dialogStr("Hoe heeft dat koraal zo vreemd kunnen groeien?")


dialogId("bl-v-pestovany", "font_big", "It is carefully grown for the logical games players.")
dialogStr("Het is zorgvuldig bijgestuurd voor de logicaspelletjesspelers.")


dialogId("bl-v-proc", "font_big", "Why do you want to put that coral down, anyway?")
dialogStr("Waarom wil je dat stuk koraal eigenlijk los maken?")


dialogId("bl-m-zeptej", "font_small", "I have no idea. Ask the player.")
dialogStr("Geen idee. Vraag het aan de speler.")


dialogId("bl-m-snecku0", "font_small", "Shalimuddy, shalimuddy, put your horns out...")
dialogStr("Slakje, slakje, kom eruit...")


dialogId("bl-v-dost0", "font_big", "Stop it! As if you don’t know that no object will move if we don’t push it first!")
dialogStr("Hou op! Alsof je niet weet dat dingen hier niet bewegen tenzij wij ertegen duwen!")


dialogId("bl-m-snecku1", "font_small", "But I can try, can’t I? Shalimuddy, Shalimuddy...")
dialogStr("Maar ik kan het toch proberen. Slakje, slakje...")


dialogId("bl-v-dost1", "font_big", "Stop it! It makes my scales itch!")
dialogStr("Hou je mond! Mijn schubben jeuken ervan!")


dialogId("bl-m-snecku2", "font_small", "Don’t listen then. Shalimuddy, shalimuddy, put your...")
dialogStr("Luister dan gewoon niet. Slakje, slakje, kom...")


dialogId("bl-v-dost2", "font_big", "Stop it! Or I’ll drop that coral on your head!")
dialogStr("Kop dicht!!! Of ik laat dit stuk koraal op je harses vallen!")


