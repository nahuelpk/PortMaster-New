
dialogId("bl-m-zvlastni0", "font_small", "Now this is a strange room.")
dialogStr("To dopiero dziwne pomieszczenie.")


dialogId("bl-v-zvlastni1", "font_big", "This is a very unusual room.")
dialogStr("To dość niezwykłe pomieszczenie.")


dialogId("bl-m-funkce", "font_small", "The position of assistant deputy design coordinator was introduced because of this level. So that its author got his own credit.")
dialogStr("Funkcja asystenta zastępcy koordynatora projektowego została stworzona specjalnie po to, żeby autor tego poziomu miał swoje miejsce na liście twórców gry.")


dialogId("bl-v-pozadi", "font_big", "Enough about the game background. Let’s get to work.")
dialogStr("To tyle o historii gry. Bierzmy się do pracy.")


dialogId("bl-m-koral0", "font_small", "This is a very strange coral.")
dialogStr("To bardzo dziwny koral.")


dialogId("bl-v-koral1", "font_big", "This is a very peculiar coral.")
dialogStr("Osobliwy koral.")


dialogId("bl-m-visi", "font_small", "And what does it hang on?")
dialogStr("A na czym on wisi?")


dialogId("bl-v-nevim0", "font_big", "I don’t know. But we have to get it down anyway.")
dialogStr("Nie wiem. Ale i tak musimy go ściągnąć na dół.")


dialogId("bl-v-nevim1", "font_big", "I don’t know. Do we have to put it down?")
dialogStr("Nie wiem. Mamy go stamtąd ściągnąć?")


dialogId("bl-m-tvar", "font_small", "How could that coral acquire such a bizarre shape?")
dialogStr("Jakim cudem ten koral urósł w taki dziwaczny kształt?")


dialogId("bl-v-pestovany", "font_big", "It is carefully grown for the logical games players.")
dialogStr("Był specjalnie hodowany na potrzeby gier logicznych.")


dialogId("bl-v-proc", "font_big", "Why do you want to put that coral down, anyway?")
dialogStr("Po co w ogóle chcesz ściągnąć ten koral?")


dialogId("bl-m-zeptej", "font_small", "I have no idea. Ask the player.")
dialogStr("Nie mam pojęcia. Zapytaj gracza.")


dialogId("bl-m-snecku0", "font_small", "Shalimuddy, shalimuddy, put your horns out...")
dialogStr("Ślimak, ślimak, wystaw rogi. Dam ci...")


dialogId("bl-v-dost0", "font_big", "Stop it! As if you don’t know that no object will move if we don’t push it first!")
dialogStr("Daj spokój! Dobrze wiesz, że nic się samo nie poruszy, póki tego nie popchniemy.")


dialogId("bl-m-snecku1", "font_small", "But I can try, can’t I? Shalimuddy, Shalimuddy...")
dialogStr("Zawsze można spróbować. Ślimak, ślimak...")


dialogId("bl-v-dost1", "font_big", "Stop it! It makes my scales itch!")
dialogStr("Przestań!! Gdy to słyszę, swędzą mnie łuski.")


dialogId("bl-m-snecku2", "font_small", "Don’t listen then. Shalimuddy, shalimuddy, put your...")
dialogStr("To nie słuchaj. Ślimak, ślimak, wystaw...")


dialogId("bl-v-dost2", "font_big", "Stop it! Or I’ll drop that coral on your head!")
dialogStr("Uspokój się!!! Bo zrzucę ci na głowę ten koral!")

