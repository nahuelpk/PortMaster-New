
dialogId("bl-m-zvlastni0", "font_small", "Now this is a strange room.")
dialogStr("Tohle je zvláštní místnost.")


dialogId("bl-v-zvlastni1", "font_big", "This is a very unusual room.")
dialogStr("Toto je velmi neobvyklá místnost.")


dialogId("bl-m-funkce", "font_small", "The position of assistant deputy design coordinator was introduced because of this level. So that its author got his own credit.")
dialogStr("Kvůli této místnosti byla zřízena funkce asistenta zástupce vedoucího designu, aby se její autor také dostal do titulků.")


dialogId("bl-v-pozadi", "font_big", "Enough about the game background. Let’s get to work.")
dialogStr("Dosti již o pozadí hry a vzhůru do řešení.")


dialogId("bl-m-koral0", "font_small", "This is a very strange coral.")
dialogStr("To je velmi divný korál.")


dialogId("bl-v-koral1", "font_big", "This is a very peculiar coral.")
dialogStr("To je velmi členitý korál.")


dialogId("bl-m-visi", "font_small", "And what does it hang on?")
dialogStr("A na čem to visí?")


dialogId("bl-v-nevim0", "font_big", "I don’t know. But we have to get it down anyway.")
dialogStr("To nevím. Ale stejně to musíme sundat.")


dialogId("bl-v-nevim1", "font_big", "I don’t know. Do we have to put it down?")
dialogStr("To nevím. A musíme to určitě sundávat?")


dialogId("bl-m-tvar", "font_small", "How could that coral acquire such a bizarre shape?")
dialogStr("Jak mohl ten korál narůst do tak bizarního tvaru?")


dialogId("bl-v-pestovany", "font_big", "It is carefully grown for the logical games players.")
dialogStr("Je uměle pěstovaný pro hráče logických her.")


dialogId("bl-v-proc", "font_big", "Why do you want to put that coral down, anyway?")
dialogStr("Proč chceš vlastně ten korál sundávat?")


dialogId("bl-m-zeptej", "font_small", "I have no idea. Ask the player.")
dialogStr("To já nevím. Zeptej se hráče.")


dialogId("bl-m-snecku0", "font_small", "Shalimuddy, shalimuddy, put your horns out...")
dialogStr("Šnečku, šnečku, vystrč růžky, dám ti...")


dialogId("bl-v-dost0", "font_big", "Stop it! As if you don’t know that no object will move if we don’t push it first!")
dialogStr("Nech toho! Dobře víš, že tady se žádný předmět nepohne, když do něho nestrčíme.")


dialogId("bl-m-snecku1", "font_small", "But I can try, can’t I? Shalimuddy, Shalimuddy...")
dialogStr("Ale zkusit to snad můžu! Šnečku, šnečku...")


dialogId("bl-v-dost1", "font_big", "Stop it! It makes my scales itch!")
dialogStr("Nech toho!! Když to slyším, vypadávají mi šupiny.")


dialogId("bl-m-snecku2", "font_small", "Don’t listen then. Shalimuddy, shalimuddy, put your...")
dialogStr("Tak neposlouchej. Šnečku, šnečku, vystrč...")


dialogId("bl-v-dost2", "font_big", "Stop it! Or I’ll drop that coral on your head!")
dialogStr("Nech toho!!! Nebo na tebe ten korál hodím!")

