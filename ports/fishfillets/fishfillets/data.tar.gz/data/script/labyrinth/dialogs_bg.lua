dialogId("bl-m-zvlastni0", "font_small", "Now this is a strange room.")
dialogStr("Това се казва странна стая.")

dialogId("bl-v-zvlastni1", "font_big", "This is a very unusual room.")
dialogStr("Тази стая е доста необичайна.")

dialogId("bl-m-funkce", "font_small", "The position of assistant deputy design coordinator was introduced because of this level. So that its author got his own credit.")
dialogStr("Постът асистент заместник координатор по дизайна бил измислен специално заради това ниво. Така авторът получил специално признание..")

dialogId("bl-v-pozadi", "font_big", "Enough about the game background. Let’s get to work.")
dialogStr("Стига толкова за историята на играта. Да се залавяме за работа.")

dialogId("bl-m-koral0", "font_small", "This is a very strange coral.")
dialogStr("Този корал е много странен.")

dialogId("bl-v-koral1", "font_big", "This is a very peculiar coral.")
dialogStr("Много специфичен корал.")

dialogId("bl-m-visi", "font_small", "And what does it hang on?")
dialogStr("И на какво виси?")

dialogId("bl-v-nevim0", "font_big", "I don’t know. But we have to get it down anyway.")
dialogStr("Не знам, но трябва да го откачим някак.")

dialogId("bl-v-nevim1", "font_big", "I don’t know. Do we have to put it down?")
dialogStr("Не знам. Трябва ли да го свалим долу?")

dialogId("bl-m-tvar", "font_small", "How could that coral acquire such a bizarre shape?")
dialogStr("Как може корал да придобие ролкова странна форма?")

dialogId("bl-v-pestovany", "font_big", "It is carefully grown for the logical games players.")
dialogStr("Отгледан е специално за играчите на игри-ребуси.")

dialogId("bl-v-proc", "font_big", "Why do you want to put that coral down, anyway?")
dialogStr("Всъщност защо искаш да свалим корала долу?")

dialogId("bl-m-zeptej", "font_small", "I have no idea. Ask the player.")
dialogStr("Нямам представа. Питай играча.")

dialogId("bl-m-snecku0", "font_small", "Shalimuddy, shalimuddy, put your horns out...")
dialogStr("Охлювче, бохлювче, покажи си рогцата...")

dialogId("bl-v-dost0", "font_big", "Stop it! As if you don’t know that no object will move if we don’t push it first!")
dialogStr("Спри! Все едно не знаеш, че нищо в играта не се мести само — трябва първо да го бутнем!")

dialogId("bl-m-snecku1", "font_small", "But I can try, can’t I? Shalimuddy, Shalimuddy...")
dialogStr("Мога да опитам, нали? Охлювче, бохлювче...")

dialogId("bl-v-dost1", "font_big", "Stop it! It makes my scales itch!")
dialogStr("Стига! Люспите ме засърбяха!")

dialogId("bl-m-snecku2", "font_small", "Don’t listen then. Shalimuddy, shalimuddy, put your...")
dialogStr("Тогава не слушай. Охлювче, бохлювче, покажи си...")

dialogId("bl-v-dost2", "font_big", "Stop it! Or I’ll drop that coral on your head!")
dialogStr("Престани! Ще пусна този корал на главата ти!")

