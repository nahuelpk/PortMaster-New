
dialogId("bl-m-zvlastni0", "font_small", "Now this is a strange room.")
dialogStr("Det här är ett konstigt rum.")


dialogId("bl-v-zvlastni1", "font_big", "This is a very unusual room.")
dialogStr("Det här är ett mycket ovanligt rum.")


dialogId("bl-m-funkce", "font_small", "The position of assistant deputy design coordinator was introduced because of this level. So that its author got his own credit.")
dialogStr("Titeln assisterande vise designkoordinator introducerades tack vare den här nivån. Så att dess skapare skulle kunna bli nämnd.")


dialogId("bl-v-pozadi", "font_big", "Enough about the game background. Let’s get to work.")
dialogStr("Tillräckligt om bakgrunden. Dags att sätta igång.")


dialogId("bl-m-koral0", "font_small", "This is a very strange coral.")
dialogStr("Det här är en mycket konstig korall.")


dialogId("bl-v-koral1", "font_big", "This is a very peculiar coral.")
dialogStr("Det är en väldigt egen korall.")


dialogId("bl-m-visi", "font_small", "And what does it hang on?")
dialogStr("Och vad hänger den på?")


dialogId("bl-v-nevim0", "font_big", "I don’t know. But we have to get it down anyway.")
dialogStr("Jag vet inte. Men vi måste få ner den på något sätt.")


dialogId("bl-v-nevim1", "font_big", "I don’t know. Do we have to put it down?")
dialogStr("Jag vet inte. Behöver vi knuffa ner den?")


dialogId("bl-m-tvar", "font_small", "How could that coral acquire such a bizarre shape?")
dialogStr("Hur kan en korall få en så bisarr form ?")


dialogId("bl-v-pestovany", "font_big", "It is carefully grown for the logical games players.")
dialogStr("Den har försiktigt växt fram från de logiska spelarna.")


dialogId("bl-v-proc", "font_big", "Why do you want to put that coral down, anyway?")
dialogStr("Varför vill du knuffa ner korallen, förresten?")


dialogId("bl-m-zeptej", "font_small", "I have no idea. Ask the player.")
dialogStr("Jag har ingen aning fråga spelaren.")


dialogId("bl-m-snecku0", "font_small", "Shalimuddy, shalimuddy, put your horns out...")
dialogStr("Buller i, buller i bock, hur många horn står upp..")


dialogId("bl-v-dost0", "font_big", "Stop it! As if you don’t know that no object will move if we don’t push it first!")
dialogStr("Sluta! Som om du inte visste att inga objekt kommer att röra på sig innan vi först skjuter på!")


dialogId("bl-m-snecku1", "font_small", "But I can try, can’t I? Shalimuddy, Shalimuddy...")
dialogStr("Men jag kan ju alltid försöka, eller hur? Buller i, buller i...")


dialogId("bl-v-dost1", "font_big", "Stop it! It makes my scales itch!")
dialogStr("Sluta! Det får mina fjäll att börja klia!")


dialogId("bl-m-snecku2", "font_small", "Don’t listen then. Shalimuddy, shalimuddy, put your...")
dialogStr("Sluta lyssna då. Buller i, buller i bock...")


dialogId("bl-v-dost2", "font_big", "Stop it! Or I’ll drop that coral on your head!")
dialogStr("Sluta! Eller så kommer jag att släppa korallen i huvudet på dig!")

