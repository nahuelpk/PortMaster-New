
dialogId("poc-m-lezt0", "font_small", "That’s another fine mess.")
dialogStr("Kam jsme to zase vlezli?")


dialogId("poc-m-lezt1", "font_small", "What kind of place is this?")
dialogStr("A co je zase tohle?")


dialogId("poc-m-lezt2", "font_small", "Wow, what a place!")
dialogStr("To je teda místo.")


dialogId("poc-v-kam0", "font_big", "Where can man - I mean fish - get by climbing into a toilet?")
dialogStr("Kam tak člověk - chci říci ryba - může vlézt záchodem?")


dialogId("poc-v-kam1", "font_big", "It looks like a cozy little dump.")
dialogStr("Vypadá to na malé úhledné smetiště.")


dialogId("poc-v-kam2", "font_big", "Look, what kind of things people have flushed down the toilet.")
dialogStr("Podívej, co ty lidi nenaházeli do záchodu.")


dialogId("poc-v-kam3", "font_big", "I thought it would be worse when I was climbing in.")
dialogStr("Když jsem sem lezl, tak jsem to čekal horší.")


dialogId("poc-v-nenajde", "font_big", "You can find many strange things in such a dump.")
dialogStr("Co všechno se na takovém smetišti nenajde.")


dialogId("poc-m-myslis", "font_small", "Do you think this is the computer that’s at stake in this game?")
dialogStr("Myslíš, že tohle je ten počítač, o který se tu hraje?")


dialogId("poc-v-multimed", "font_big", "Surely not! This is no powerful multimedia computer. This is but an XT machine with a twelve inch display.")
dialogStr("No dovol! Tohle přece není výkoný multimediální počítač. To je XTéčko s dvanáctipalcovým monitorem.")


dialogId("poc-v-vyresil", "font_big", "The one who solves, I mean who has solved this, will receive, I mean will have received, MMX based machine with a 3Dfx card, plenty of RAM, a huge hard disk...")
dialogStr("Ten, kdo první vyřeší, chci říci vyřešil, všechny zbývající levely, vyhraje, chci říci vyhrál, počítač s technologií MMX, 3Dfx kartou, spoustou paměti, obřím diskem...")


dialogId("poc-m-kcemu", "font_small", "And what is it for? I for one know plenty of games almost as good as this one that could easily run on this XT machine.")
dialogStr("No a k čemu to je? Já třeba znám spoustu her, skroro stejně dobrých, jako je tahle, a ty by klidně běžely i na tomhle XTéčku.")


dialogId("poc-v-pssst", "font_big", "Shhhh!")
dialogStr("Pssst!")


dialogId("poc-v-napad", "font_big", "Hey, look, just an idea: Could this be the computer we are looking for?")
dialogStr("Hele, jen takový nápad: Co když je to ten počítač, který máme hledat?")


dialogId("poc-m-mohlby", "font_small", "This could be it.")
dialogStr("To by mohl být on.")


dialogId("poc-v-stahni", "font_big", "So what are we waiting for? Put that suspicious data on the diskette and off we go.")
dialogStr("Tak na co čekáme? Stáhni na disketu ta podezřelá data a můžeme jít.")


dialogId("poc-m-ukryta", "font_small", "It won’t be as easy as that. The data is surely going to be hidden somewhere. We have to go in.")
dialogStr("To nebude tak jednoduché. Data v něm budou určitě dobře ukryta. Budu se muset dostat dovnitř.")


dialogId("poc-v-dira", "font_big", "And what about getting in through that opening?")
dialogStr("Co tam zkusit vlézt třeba támhletou dírou?")


dialogId("poc-m-mechanika", "font_small", "That is a floppy disk drive.")
dialogStr("To je disketová mechanika.")


dialogId("poc-m-zezadu", "font_small", "I have to get to the back of it.")
dialogStr("Musím se k němu dostat zezadu.")


dialogId("poc-m-vyvrtka", "font_small", "Put down that corkscrew and come to help me.")
dialogStr("Polož tu vývrtku a pojď mi pomoct.")


dialogId("poc-m-kram", "font_small", "Oh my, what a sloppy machine. So big, so heavy and surely so slow.")
dialogStr("To je ale odporný krám. Velký, těžký a určitě strašně pomalý.")


dialogId("poc-v-mono", "font_big", "And moreover only mono.")
dialogStr("A navíc mono.")

