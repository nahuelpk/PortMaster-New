
dialogId("poc-m-lezt0", "font_small", "That’s another fine mess.")
dialogStr("Еще один забавный беспорядок.")

dialogId("poc-m-lezt1", "font_small", "What kind of place is this?")
dialogStr("Что это за место?")

dialogId("poc-m-lezt2", "font_small", "Wow, what a place!")
dialogStr("Какое странное место!")

dialogId("poc-v-kam0", "font_big", "Where can man - I mean fish - get by climbing into a toilet?")
dialogStr("А как человек... то есть, рыба, находящаяся в этой комнате, сможет добраться до туалета?")

dialogId("poc-v-kam1", "font_big", "It looks like a cozy little dump.")
dialogStr("Выглядит как маленькая уютная свалка.")

dialogId("poc-v-kam2", "font_big", "Look, what kind of things people have flushed down the toilet.")
dialogStr("Смотри, какие странные вещи люди спускают в унитаз.")

dialogId("poc-v-kam3", "font_big", "I thought it would be worse when I was climbing in.")
dialogStr("Я думал, что здесь будет хуже, когда забирался внутрь.")

dialogId("poc-v-nenajde", "font_big", "You can find many strange things in such a dump.")
dialogStr("В такой свалке можно найти много интересных вещей.")

dialogId("poc-m-myslis", "font_small", "Do you think this is the computer that’s at stake in this game?")
dialogStr("Как ты думаешь, это тот компьютер, который нам нужно было найти?")

dialogId("poc-v-multimed", "font_big", "Surely not! This is no powerful multimedia computer. This is but an XT machine with a twelve inch display.")
dialogStr("Конечно нет! Это не мощный мультимедийный компьютер, а всего лишь XT-машинка с двенадцатидюймовым экраном.")

dialogId("poc-v-vyresil", "font_big", "The one who solves, I mean who has solved this, will receive, I mean will have received, MMX based machine with a 3Dfx card, plenty of RAM, a huge hard disk...")
dialogStr("Тот, кто пройдет этот уровень первым (вернее, тот, кто уже прошел), получит (то есть, получил) новый MMX-компьютер с ускорителем 3Dfx, кучей оперативной памяти и огромным жёстким диском...")

dialogId("poc-m-kcemu", "font_small", "And what is it for? I for one know plenty of games almost as good as this one that could easily run on this XT machine.")
dialogStr("А зачем он нужен? Я знаю много игр, которые ничуть не хуже, чем эта, но будут спокойно работать и на XT-машине.")

dialogId("poc-v-pssst", "font_big", "Shhhh!")
dialogStr("Тссс!")

dialogId("poc-v-napad", "font_big", "Hey, look, just an idea: Could this be the computer we are looking for?")
dialogStr("Слушай, а это может быть тем компьютером, который мы ищем?")

dialogId("poc-m-mohlby", "font_small", "This could be it.")
dialogStr("Кто знает, возможно.")

dialogId("poc-v-stahni", "font_big", "So what are we waiting for? Put that suspicious data on the diskette and off we go.")
dialogStr("Тогда чего мы ждём? Перепиши нужную информацию на дискету и поплыли отсюда.")

dialogId("poc-m-ukryta", "font_small", "It won’t be as easy as that. The data is surely going to be hidden somewhere. We have to go in.")
dialogStr("Всё не может быть так просто, данные должны быть спрятаны. Нам нужно идти дальше.")

dialogId("poc-v-dira", "font_big", "And what about getting in through that opening?")
dialogStr("Как насчет того, чтобы пролезть в то отверстие?")

dialogId("poc-m-mechanika", "font_small", "That is a floppy disk drive.")
dialogStr("Это флоппи-дисковод.")

dialogId("poc-m-zezadu", "font_small", "I have to get to the back of it.")
dialogStr("Мне нужно попасть за него.")

dialogId("poc-m-vyvrtka", "font_small", "Put down that corkscrew and come to help me.")
dialogStr("Брось штопор и помоги мне.")

dialogId("poc-m-kram", "font_small", "Oh my, what a sloppy machine. So big, so heavy and surely so slow.")
dialogStr("Боже, какая неопрятная машина. Такая большая, тяжёлая и, наверняка, очень медленная.")

dialogId("poc-v-mono", "font_big", "And moreover only mono.")
dialogStr("И к тому же, без стереозвука.")

