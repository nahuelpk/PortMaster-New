
dialogId("poc-m-lezt0", "font_small", "That’s another fine mess.")
dialogStr("Was für eine Sauerei!")


dialogId("poc-m-lezt1", "font_small", "What kind of place is this?")
dialogStr("Wo sind wir hier?")


dialogId("poc-m-lezt2", "font_small", "Wow, what a place!")
dialogStr("Boa, wie sieht’s hier denn aus?")


dialogId("poc-v-kam0", "font_big", "Where can man - I mean fish - get by climbing into a toilet?")
dialogStr("Wohin kommt man, äh - ich meine Fisch, wenn er in eine Toilette klettert?")


dialogId("poc-v-kam1", "font_big", "It looks like a cozy little dump.")
dialogStr("Sieht wie ein hübscher kleiner Müllplatz aus.")


dialogId("poc-v-kam2", "font_big", "Look, what kind of things people have flushed down the toilet.")
dialogStr("Sieh nur, was die Leute so die Toilette runterspülen!")


dialogId("poc-v-kam3", "font_big", "I thought it would be worse when I was climbing in.")
dialogStr("Beim Reinklettern dachte ich, es wäre schlimmer.")


dialogId("poc-v-nenajde", "font_big", "You can find many strange things in such a dump.")
dialogStr("Man kann viele seltsame Dinge auf so einer Müllkippe finden.")


dialogId("poc-m-myslis", "font_small", "Do you think this is the computer that’s at stake in this game?")
dialogStr("Denkst du, dass es in diesem Spiel um diesen Rechner geht?")


dialogId("poc-v-multimed", "font_big", "Surely not! This is no powerful multimedia computer. This is but an XT machine with a twelve inch display.")
dialogStr("Bestimmt nicht! Das ist kein leistungsstarker Multimedia-Rechner. Das ist nur eine XT-Maschine mit 12-Zoll Bildschirm.")


dialogId("poc-v-vyresil", "font_big", "The one who solves, I mean who has solved this, will receive, I mean will have received, MMX based machine with a 3Dfx card, plenty of RAM, a huge hard disk...")
dialogStr("Diejenigen, die das Spiel lösen, ich meine gelöst haben, bekommen, äh haben schon einen MMX-Rechner bekommen mit 3D-Karte, massig Arbeitsspeicher, riesiger Festplatte...")


dialogId("poc-m-kcemu", "font_small", "And what is it for? I for one know plenty of games almost as good as this one that could easily run on this XT machine.")
dialogStr("Und wozu? Ich kenne viele Spiele, fast so gut wie dieses, die problemlos auf dieser XT-Maschine laufen würden.")


dialogId("poc-v-pssst", "font_big", "Shhhh!")
dialogStr("Pssst!")


dialogId("poc-v-napad", "font_big", "Hey, look, just an idea: Could this be the computer we are looking for?")
dialogStr("Hah, nur so eine Idee: Könnte das der Rechner sein, nach dem wir suchen?")


dialogId("poc-m-mohlby", "font_small", "This could be it.")
dialogStr("Das könnte er sein.")


dialogId("poc-v-stahni", "font_big", "So what are we waiting for? Put that suspicious data on the diskette and off we go.")
dialogStr("Worauf warten wir? Speicher die verdächtigen Daten auf Diskette und weg hier!")


dialogId("poc-m-ukryta", "font_small", "It won’t be as easy as that. The data is surely going to be hidden somewhere. We have to go in.")
dialogStr("So leicht wird das nicht sein. Die Daten sind sicherlich irgendwo versteckt. Wir müssen reingehen.")


dialogId("poc-v-dira", "font_big", "And what about getting in through that opening?")
dialogStr("Wollen wir es durch diese Öffnung probieren?")


dialogId("poc-m-mechanika", "font_small", "That is a floppy disk drive.")
dialogStr("Das ist das Diskettenlaufwerk.")


dialogId("poc-m-zezadu", "font_small", "I have to get to the back of it.")
dialogStr("Ich muss auf die Rückseite.")


dialogId("poc-m-vyvrtka", "font_small", "Put down that corkscrew and come to help me.")
dialogStr("Lass den Korkenzieher los und hilf mir!")


dialogId("poc-m-kram", "font_small", "Oh my, what a sloppy machine. So big, so heavy and surely so slow.")
dialogStr("Oh je, was für eine Kiste. Groß, schwer und bestimmt langsam.")


dialogId("poc-v-mono", "font_big", "And moreover only mono.")
dialogStr("Und außerdem nur Mono.")

