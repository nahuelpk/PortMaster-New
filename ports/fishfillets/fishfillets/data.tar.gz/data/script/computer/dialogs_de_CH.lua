
dialogId("poc-m-kram", "font_small", "Oh my, what a sloppy machine. So big, so heavy and surely so slow.")
dialogStr("Oh je, was für eine Kiste. Gross, schwer und bestimmt langsam.")


dialogId("poc-v-mono", "font_big", "And moreover only mono.")
dialogStr("Und ausserdem nur Mono.")

