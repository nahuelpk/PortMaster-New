
dialogId("poc-m-lezt0", "font_small", "That’s another fine mess.")
dialogStr("Vilken röra!")


dialogId("poc-m-lezt1", "font_small", "What kind of place is this?")
dialogStr("Var är vi nu?")


dialogId("poc-m-lezt2", "font_small", "Wow, what a place!")
dialogStr("Wow, vilket ställe?")


dialogId("poc-v-kam0", "font_big", "Where can man - I mean fish - get by climbing into a toilet?")
dialogStr("Var kan man - jag menar fiskar - komma om man klättrar ner i en toalett?")


dialogId("poc-v-kam1", "font_big", "It looks like a cozy little dump.")
dialogStr("Ser ut som en trevlig liten tipp.")


dialogId("poc-v-kam2", "font_big", "Look, what kind of things people have flushed down the toilet.")
dialogStr("Titta vilka prylar som en del människor spolar ner i toaletten!")


dialogId("poc-v-kam3", "font_big", "I thought it would be worse when I was climbing in.")
dialogStr("Jag trodde att det skulle bli värre när jag klev i.")


dialogId("poc-v-nenajde", "font_big", "You can find many strange things in such a dump.")
dialogStr("Man kan hitta många konstiga saker i en sådan här tipp.")


dialogId("poc-m-myslis", "font_small", "Do you think this is the computer that’s at stake in this game?")
dialogStr("Tror du att det är den här datorn som det här spelet handlar om?")


dialogId("poc-v-multimed", "font_big", "Surely not! This is no powerful multimedia computer. This is but an XT machine with a twelve inch display.")
dialogStr("Absolut inte! Det här är inte en kraftfull multimediadator. Det här är en XT men en tolv tums skärm")


dialogId("poc-v-vyresil", "font_big", "The one who solves, I mean who has solved this, will receive, I mean will have received, MMX based machine with a 3Dfx card, plenty of RAM, a huge hard disk...")
dialogStr("Den som löser, jag menar den som har löst det här, kommer att få, jag menar har fått, en MMX baserad dator med ett 3Dfx kort, massor av ram, en gigantisk hårddisk...")


dialogId("poc-m-kcemu", "font_small", "And what is it for? I for one know plenty of games almost as good as this one that could easily run on this XT machine.")
dialogStr("Varför? Jag känner till många spel som är lika bra som detta och kan lätt köras på den här XT maskinen.")


dialogId("poc-v-pssst", "font_big", "Shhhh!")
dialogStr("Schhh!")


dialogId("poc-v-napad", "font_big", "Hey, look, just an idea: Could this be the computer we are looking for?")
dialogStr("Hallå, hörru, en idé: kan det här vara datorn som vi letar efter?")


dialogId("poc-m-mohlby", "font_small", "This could be it.")
dialogStr("Det kan vara den.")


dialogId("poc-v-stahni", "font_big", "So what are we waiting for? Put that suspicious data on the diskette and off we go.")
dialogStr("Vad väntar vi på? Ställ datorn på disketten så drar vi!")


dialogId("poc-m-ukryta", "font_small", "It won’t be as easy as that. The data is surely going to be hidden somewhere. We have to go in.")
dialogStr("Det kan inte vara så enkelt. Informationen kommer säkert att var gömd någonstans. Vi måste ta oss in.")


dialogId("poc-v-dira", "font_big", "And what about getting in through that opening?")
dialogStr("Kan vi kanske ta oss in genom öppningen?")


dialogId("poc-m-mechanika", "font_small", "That is a floppy disk drive.")
dialogStr("Det här är en diskettstation.")


dialogId("poc-m-zezadu", "font_small", "I have to get to the back of it.")
dialogStr("Jag behöver komma bakom det.")


dialogId("poc-m-vyvrtka", "font_small", "Put down that corkscrew and come to help me.")
dialogStr("Släpp korkskruven och kom och hjälp mig istället!")


dialogId("poc-m-kram", "font_small", "Oh my, what a sloppy machine. So big, so heavy and surely so slow.")
dialogStr("Gud, vilken slö maskin. Så stor, så tung och säkert sååå långsam.")


dialogId("poc-v-mono", "font_big", "And moreover only mono.")
dialogStr("Och dessutom bara mono.")

