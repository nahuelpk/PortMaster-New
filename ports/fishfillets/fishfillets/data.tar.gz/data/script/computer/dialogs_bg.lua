dialogId("poc-m-lezt0", "font_small", "That’s another fine mess.")
dialogStr("Още една приятна бъркотия.")

dialogId("poc-m-lezt1", "font_small", "What kind of place is this?")
dialogStr("Що за място е това?")

dialogId("poc-m-lezt2", "font_small", "Wow, what a place!")
dialogStr("Леле какво място!")

dialogId("poc-v-kam0", "font_big", "Where can man - I mean fish - get by climbing into a toilet?")
dialogStr("Ето къде можел човек, т.е. риба, да отиде като се гмурне в тоалетната.")

dialogId("poc-v-kam1", "font_big", "It looks like a cozy little dump.")
dialogStr("Прилича на уютно малко сметище.")

dialogId("poc-v-kam2", "font_big", "Look, what kind of things people have flushed down the toilet.")
dialogStr("Гледай какви неща изхвърлят хората в тоалетната.")

dialogId("poc-v-kam3", "font_big", "I thought it would be worse when I was climbing in.")
dialogStr("Мислех, че ще бъде по-зле като скочих вътре.")

dialogId("poc-v-nenajde", "font_big", "You can find many strange things in such a dump.")
dialogStr("В боклучарник като този могат да се намерят много странни неща.")

dialogId("poc-m-myslis", "font_small", "Do you think this is the computer that’s at stake in this game?")
dialogStr("Мислиш ли, че този компютър е наградата в играта?")

dialogId("poc-v-multimed", "font_big", "Surely not! This is no powerful multimedia computer. This is but an XT machine with a twelve inch display.")
dialogStr("Със сигурност не! Това не е мощен мултимедиен компютър. Това е XT машина с 12-инчов екран.")

dialogId("poc-v-vyresil", "font_big", "The one who solves, I mean who has solved this, will receive, I mean will have received, MMX based machine with a 3Dfx card, plenty of RAM, a huge hard disk...")
dialogStr("Който реши, т.е. би решил ще получи, т.е. би получил MMX-базирана машина с 3Dfx карта, много памет, голям диск...")

dialogId("poc-m-kcemu", "font_small", "And what is it for? I for one know plenty of games almost as good as this one that could easily run on this XT machine.")
dialogStr("И за какво? Аз със сигурност знам доста игри, почти толкова добри, колкото тази, които могат да се играят на тази XT машина.")

dialogId("poc-v-pssst", "font_big", "Shhhh!")
dialogStr("Шшшт!")

dialogId("poc-v-napad", "font_big", "Hey, look, just an idea: Could this be the computer we are looking for?")
dialogStr("Имам идея: дали това не е компютърът, който търсим?")

dialogId("poc-m-mohlby", "font_small", "This could be it.")
dialogStr("Може и да е този.")

dialogId("poc-v-stahni", "font_big", "So what are we waiting for? Put that suspicious data on the diskette and off we go.")
dialogStr("Какво чакаме тогава? Слагай тези подозрителни данни на дискетата и да изчезваме.")

dialogId("poc-m-ukryta", "font_small", "It won’t be as easy as that. The data is surely going to be hidden somewhere. We have to go in.")
dialogStr("Няма да е толкова лесно. Данните със сигурност са скрити някъде. Трябва да влезем.")

dialogId("poc-v-dira", "font_big", "And what about getting in through that opening?")
dialogStr("Какво ще кажеш да минем през онзи отвор?")

dialogId("poc-m-mechanika", "font_small", "That is a floppy disk drive.")
dialogStr("Това е флопидисково устройство.")

dialogId("poc-m-zezadu", "font_small", "I have to get to the back of it.")
dialogStr("Трябва да стигна до задната му страна.")

dialogId("poc-m-vyvrtka", "font_small", "Put down that corkscrew and come to help me.")
dialogStr("Остави този тирбушон и ела да ми помогнеш.")

dialogId("poc-m-kram", "font_small", "Oh my, what a sloppy machine. So big, so heavy and surely so slow.")
dialogStr("Леле, колко мръсна машина. Голяма, тежка и със сигурност бавна.")

dialogId("poc-v-mono", "font_big", "And moreover only mono.")
dialogStr("И на всичкото отгоре моно.")

