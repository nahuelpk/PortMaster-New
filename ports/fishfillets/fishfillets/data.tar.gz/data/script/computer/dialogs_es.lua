
dialogId("poc-m-lezt0", "font_small", "That’s another fine mess.")
dialogStr("Ese es otro fino lío.")


dialogId("poc-m-lezt1", "font_small", "What kind of place is this?")
dialogStr("¿Que clase de lugar es éste?")


dialogId("poc-m-lezt2", "font_small", "Wow, what a place!")
dialogStr("Oh, qué lugar.")


dialogId("poc-v-kam0", "font_big", "Where can man - I mean fish - get by climbing into a toilet?")
dialogStr("¿Por donde pueden las personas - quiero decir los peces - llegar subiendo a un retrete?")


dialogId("poc-v-kam1", "font_big", "It looks like a cozy little dump.")
dialogStr("Luce como un pequeño y acogedor vertedero.")


dialogId("poc-v-kam2", "font_big", "Look, what kind of things people have flushed down the toilet.")
dialogStr("Mira, que clase de cosas ha tirado la gente por el retrete.")


dialogId("poc-v-kam3", "font_big", "I thought it would be worse when I was climbing in.")
dialogStr("Pensé que sería peor cuando estuviera subiendo.")


dialogId("poc-v-nenajde", "font_big", "You can find many strange things in such a dump.")
dialogStr("Puedes encontrar muchas cosas extrañas en un basurero de esta clase.")


dialogId("poc-m-myslis", "font_small", "Do you think this is the computer that’s at stake in this game?")
dialogStr("¿Tu crees que este es el computador que fué mencionado en este juego?")


dialogId("poc-v-multimed", "font_big", "Surely not! This is no powerful multimedia computer. This is but an XT machine with a twelve inch display.")
dialogStr("¡Seguramente que no! Este no es un poderoso computador multimedia. Este no es nada más que una máquina XT con una pantalla de doce pulgadas.")


dialogId("poc-v-vyresil", "font_big", "The one who solves, I mean who has solved this, will receive, I mean will have received, MMX based machine with a 3Dfx card, plenty of RAM, a huge hard disk...")
dialogStr("El que lo resuelva, digo el que lo ha resuelto, recibirá, quiero decir habrá recibido, una máquina MMX con una tarjeta 3Dfx, mucha RAM, un disco duro inmenso...")


dialogId("poc-m-kcemu", "font_small", "And what is it for? I for one know plenty of games almost as good as this one that could easily run on this XT machine.")
dialogStr("Y para qué sirve? Yo conozco multitud de juegos casi tan buenos como éste que fácilmente podrían funcionar en esta máquina XT.")


dialogId("poc-v-pssst", "font_big", "Shhhh!")
dialogStr("¡Shhht!")


dialogId("poc-v-napad", "font_big", "Hey, look, just an idea: Could this be the computer we are looking for?")
dialogStr("Oye, mira, una idea: ¿Podría ser éste el computador que andamos buscando?")


dialogId("poc-m-mohlby", "font_small", "This could be it.")
dialogStr("Este podría ser.")


dialogId("poc-v-stahni", "font_big", "So what are we waiting for? Put that suspicious data on the diskette and off we go.")
dialogStr("¿Entonces qué esperamos? Pon esos datos sospechosos en el diskette y vámonos.")


dialogId("poc-m-ukryta", "font_small", "It won’t be as easy as that. The data is surely going to be hidden somewhere. We have to go in.")
dialogStr("No será tan fácil como eso. Los datos seguramente van a estar escondidos en alguna parte. Tenemos que entrar.")


dialogId("poc-v-dira", "font_big", "And what about getting in through that opening?")
dialogStr("¿Y que tal si entramos por esa abertura?")


dialogId("poc-m-mechanika", "font_small", "That is a floppy disk drive.")
dialogStr("Esa es un lector de diskettes.")


dialogId("poc-m-zezadu", "font_small", "I have to get to the back of it.")
dialogStr("Tengo que llegar hasta la parte de atrás.")


dialogId("poc-m-vyvrtka", "font_small", "Put down that corkscrew and come to help me.")
dialogStr("Baja ese sacacorchos y ven a ayudarme.")


dialogId("poc-m-kram", "font_small", "Oh my, what a sloppy machine. So big, so heavy and surely so slow.")
dialogStr("Oh, que máquina tan torpe. Tan grande, tan pesada y seguramente tan lenta.")


dialogId("poc-v-mono", "font_big", "And moreover only mono.")
dialogStr("Y para colmo es sólo mono.")

