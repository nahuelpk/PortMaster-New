
dialogId("poc-m-lezt0", "font_small", "That’s another fine mess.")
dialogStr("Wat een rommel!")


dialogId("poc-m-lezt1", "font_small", "What kind of place is this?")
dialogStr("Waar zijn we beland?")


dialogId("poc-m-lezt2", "font_small", "Wow, what a place!")
dialogStr("Wow, wat een rare boel!")


dialogId("poc-v-kam0", "font_big", "Where can man - I mean fish - get by climbing into a toilet?")
dialogStr("Waar kan een mens - uh, een vis - terechtkomen door een WC in te zwemmen?")


dialogId("poc-v-kam1", "font_big", "It looks like a cozy little dump.")
dialogStr("Het ziet er wel gezellig uit.")


dialogId("poc-v-kam2", "font_big", "Look, what kind of things people have flushed down the toilet.")
dialogStr("Moet je zien wat mensen allemaal door de WC spoelen.")


dialogId("poc-v-kam3", "font_big", "I thought it would be worse when I was climbing in.")
dialogStr("Toen we naar binnen zwommen was ik bang dat het een stuk erger zou zijn.")


dialogId("poc-v-nenajde", "font_big", "You can find many strange things in such a dump.")
dialogStr("Er liggen hier vast allemaal vreemde dingen.")


dialogId("poc-m-myslis", "font_small", "Do you think this is the computer that’s at stake in this game?")
dialogStr("Denk je dat dit de computer is die op het spel staat?")


dialogId("poc-v-multimed", "font_big", "Surely not! This is no powerful multimedia computer. This is but an XT machine with a twelve inch display.")
dialogStr("Vast niet! Dit is geen krachtige multimediacomputer. Dit is een ouwe XT met een 12 inch schermpje.")


dialogId("poc-v-vyresil", "font_big", "The one who solves, I mean who has solved this, will receive, I mean will have received, MMX based machine with a 3Dfx card, plenty of RAM, a huge hard disk...")
dialogStr("Degene die dit spel op zal lossen, ik bedoel opgelost heeft, die ontvangt een patsbak met 3Dfx videokaart, heel veel werkgeheugen en een enorme harde schijf, uh zal hebben ontvangen...")


dialogId("poc-m-kcemu", "font_small", "And what is it for? I for one know plenty of games almost as good as this one that could easily run on this XT machine.")
dialogStr("Maar waar is het goed voor? Ik ken genoeg spelletjes die bijna net zo goed zijn als dit spel en die je makkelijk op zo'n XT kunt spelen.")


dialogId("poc-v-pssst", "font_big", "Shhhh!")
dialogStr("Ssssst!")


dialogId("poc-v-napad", "font_big", "Hey, look, just an idea: Could this be the computer we are looking for?")
dialogStr("Ik heb een ideetje: zou dit de computer zijn waar we naar op zoek zijn?")


dialogId("poc-m-mohlby", "font_small", "This could be it.")
dialogStr("Het zou kunnen.")


dialogId("poc-v-stahni", "font_big", "So what are we waiting for? Put that suspicious data on the diskette and off we go.")
dialogStr("Waar wachten we nog op? Zet de verdachte bestanden op de diskette en dan kunnen we er weer vandoor.")


dialogId("poc-m-ukryta", "font_small", "It won’t be as easy as that. The data is surely going to be hidden somewhere. We have to go in.")
dialogStr("Zo eenvoudig is het niet. Die bestanden zijn vast goed verstopt. We moeten naarbinnen zwemmen.")


dialogId("poc-v-dira", "font_big", "And what about getting in through that opening?")
dialogStr("Zullen we die opening proberen?")


dialogId("poc-m-mechanika", "font_small", "That is a floppy disk drive.")
dialogStr("Dat is een floppenhapper.")


dialogId("poc-m-zezadu", "font_small", "I have to get to the back of it.")
dialogStr("Ik moet achter dat ding zien te komen.")


dialogId("poc-m-vyvrtka", "font_small", "Put down that corkscrew and come to help me.")
dialogStr("Laat die kurkentrekker vallen en help me!")


dialogId("poc-m-kram", "font_small", "Oh my, what a sloppy machine. So big, so heavy and surely so slow.")
dialogStr("O jee, wat een vreselijke krakbak. Zo groot, zo zwaar en natuurlijk ontzettend langzaam.")


dialogId("poc-v-mono", "font_big", "And moreover only mono.")
dialogStr("En monochroom.")

