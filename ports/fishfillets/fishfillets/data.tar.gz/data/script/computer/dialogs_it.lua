
dialogId("poc-m-lezt0", "font_small", "That’s another fine mess.")
dialogStr("Ecco un altro bel casino.")


dialogId("poc-m-lezt1", "font_small", "What kind of place is this?")
dialogStr("Che posto è mai questo?")


dialogId("poc-m-lezt2", "font_small", "Wow, what a place!")
dialogStr("Uao, che posto.")


dialogId("poc-v-kam0", "font_big", "Where can man - I mean fish - get by climbing into a toilet?")
dialogStr("Dove può arrivare l'uomo - pardon, il pesce - percorrendo un gabinetto?")


dialogId("poc-v-kam1", "font_big", "It looks like a cozy little dump.")
dialogStr("Sembra una piccolo buco confortevole.")


dialogId("poc-v-kam2", "font_big", "Look, what kind of things people have flushed down the toilet.")
dialogStr("Guarda che razza di roba la gente getta nel gabinetto.")


dialogId("poc-v-kam3", "font_big", "I thought it would be worse when I was climbing in.")
dialogStr("Pensavo sarebbe stato peggio, all'inizio.")


dialogId("poc-v-nenajde", "font_big", "You can find many strange things in such a dump.")
dialogStr("Puoi trovare un sacco di cose in un buco simile.")


dialogId("poc-m-myslis", "font_small", "Do you think this is the computer that’s at stake in this game?")
dialogStr("Pensi che sia questo il computer in palio in questo gioco?")


dialogId("poc-v-multimed", "font_big", "Surely not! This is no powerful multimedia computer. This is but an XT machine with a twelve inch display.")
dialogStr("Certo che no! Questo non è un potente computer multimediale. E’ soltanto una macchina XT con monitor da dodici pollici.")


dialogId("poc-v-vyresil", "font_big", "The one who solves, I mean who has solved this, will receive, I mean will have received, MMX based machine with a 3Dfx card, plenty of RAM, a huge hard disk...")
dialogStr("Chi risolverà, volevo dire ha risolto, riceverà, volevo dire ha ricevuto, una macchina MMX con scheda 3Dfx, un sacco RAM, hard-disk enorme...")


dialogId("poc-m-kcemu", "font_small", "And what is it for? I for one know plenty of games almost as good as this one that could easily run on this XT machine.")
dialogStr("E perché mai? Io conosco un sacco di giochi buoni quasi quanto questo che possono girare su questo XT.")


dialogId("poc-v-pssst", "font_big", "Shhhh!")
dialogStr("Sssst!")


dialogId("poc-v-napad", "font_big", "Hey, look, just an idea: Could this be the computer we are looking for?")
dialogStr("Ehi, senti, giusto un'idea: potrebbe essere questo il computer che cerchiamo?")


dialogId("poc-m-mohlby", "font_small", "This could be it.")
dialogStr("Potrebbe essere.")


dialogId("poc-v-stahni", "font_big", "So what are we waiting for? Put that suspicious data on the diskette and off we go.")
dialogStr("E allora, che aspettiamo? metti i dati sospetti sul dischetto e andiamocene.")


dialogId("poc-m-ukryta", "font_small", "It won’t be as easy as that. The data is surely going to be hidden somewhere. We have to go in.")
dialogStr("Non sarà così tanto facile. I dati saranno sicuramente nascosti da qualche parte. Dovremo andare dentro.")


dialogId("poc-v-dira", "font_big", "And what about getting in through that opening?")
dialogStr("Perché non entriamo da quell'apertura?")


dialogId("poc-m-mechanika", "font_small", "That is a floppy disk drive.")
dialogStr("Quello è un lettore floppy.")


dialogId("poc-m-zezadu", "font_small", "I have to get to the back of it.")
dialogStr("Devo accedere alla parte posteriore.")


dialogId("poc-m-vyvrtka", "font_small", "Put down that corkscrew and come to help me.")
dialogStr("Metti giù quel cavatappi e vieni ad aiutarmi.")


dialogId("poc-m-kram", "font_small", "Oh my, what a sloppy machine. So big, so heavy and surely so slow.")
dialogStr("Oh... che trappola! Così grande, pesante e sicuramente lenta.")


dialogId("poc-v-mono", "font_big", "And moreover only mono.")
dialogStr("E perdipiù monocromatica.")

