
dialogId("poc-m-lezt0", "font_small", "That’s another fine mess.")
dialogStr("Gdzieśmy się znowu wpakowali?")


dialogId("poc-m-lezt1", "font_small", "What kind of place is this?")
dialogStr("A to co za miejsce?")


dialogId("poc-m-lezt2", "font_small", "Wow, what a place!")
dialogStr("To dopiero ciekawe miejsce.")


dialogId("poc-v-kam0", "font_big", "Where can man - I mean fish - get by climbing into a toilet?")
dialogStr("A gdzie się spodziewałaś znaleźć po wpłynięciu do kolzetu?")


dialogId("poc-v-kam1", "font_big", "It looks like a cozy little dump.")
dialogStr("Wygląda mi to na małe, przytulne śmietnisko.")


dialogId("poc-v-kam2", "font_big", "Look, what kind of things people have flushed down the toilet.")
dialogStr("Zobacz, jakie rzeczy ludzie z wodą spuszczają.")


dialogId("poc-v-kam3", "font_big", "I thought it would be worse when I was climbing in.")
dialogStr("Przeciskając się tu, spodziewałem się gorszego widoku.")


dialogId("poc-v-nenajde", "font_big", "You can find many strange things in such a dump.")
dialogStr("Ciekawe rzeczy można znaleźć na takim wysypisku.")


dialogId("poc-m-myslis", "font_small", "Do you think this is the computer that’s at stake in this game?")
dialogStr("Myślisz, że to ten komputer jest nagrodą w tej grze?")


dialogId("poc-v-multimed", "font_big", "Surely not! This is no powerful multimedia computer. This is but an XT machine with a twelve inch display.")
dialogStr("Na pewno nie! Przecież to nie jest wypasiony komputer multimedialny, tylko jakiś marny XT z dwunastocalowym monitorem.")


dialogId("poc-v-vyresil", "font_big", "The one who solves, I mean who has solved this, will receive, I mean will have received, MMX based machine with a 3Dfx card, plenty of RAM, a huge hard disk...")
dialogStr("Ten, kto pierwszy rozwiąże, to znaczy rozwiązał, wszystkie poziomy, dostanie, to znaczy dostał, komputer oparty na technologii MMX, z kartą 3Dfx, mnóstwem pamięci, wielkim dyskiem twardym...")


dialogId("poc-m-kcemu", "font_small", "And what is it for? I for one know plenty of games almost as good as this one that could easily run on this XT machine.")
dialogStr("I na co to komu? Znam mnóstwo gier, niemal tak dobrych jak ta, które spokojnie dają się uruchomić na tym starym XTeku.")


dialogId("poc-v-pssst", "font_big", "Shhhh!")
dialogStr("Ćśśśś!")


dialogId("poc-v-napad", "font_big", "Hey, look, just an idea: Could this be the computer we are looking for?")
dialogStr("Tak sobie myślę... czy to przypadkiem nie ten komputer, którego szukamy?")


dialogId("poc-m-mohlby", "font_small", "This could be it.")
dialogStr("To całkiem możliwe.")


dialogId("poc-v-stahni", "font_big", "So what are we waiting for? Put that suspicious data on the diskette and off we go.")
dialogStr("No to na co czekamy? Wgraj te podejrzane dane i spływamy stąd.")


dialogId("poc-m-ukryta", "font_small", "It won’t be as easy as that. The data is surely going to be hidden somewhere. We have to go in.")
dialogStr("To nie będzie takie proste. Te dane są z pewnością gdzieś ukryte. Musimy dostać się do środka.")


dialogId("poc-v-dira", "font_big", "And what about getting in through that opening?")
dialogStr("No to mykaj przez tę szparę.")


dialogId("poc-m-mechanika", "font_small", "That is a floppy disk drive.")
dialogStr("To jest stacja dysków.")


dialogId("poc-m-zezadu", "font_small", "I have to get to the back of it.")
dialogStr("Muszę tam wpłynąć od tyłu.")


dialogId("poc-m-vyvrtka", "font_small", "Put down that corkscrew and come to help me.")
dialogStr("Zepchnij tu ten korkociąg i chodź mi pomóc.")


dialogId("poc-m-kram", "font_small", "Oh my, what a sloppy machine. So big, so heavy and surely so slow.")
dialogStr("Co za niezręczna machina. Wielka, ciężka i z pewnością powolna.")


dialogId("poc-v-mono", "font_big", "And moreover only mono.")
dialogStr("I tylko mono.")

