
dialogId("bot-m-vidis", "font_small", "Can you see that seahorse?")
dialogStr("Puedes ver ese caballo de mar?")


dialogId("bot-v-uveznen0", "font_big", "It is blocked by amphoras.")
dialogStr("Está bloqueado por ánforas.")


dialogId("bot-v-uveznen1", "font_big", "It got itself drunk among the amphoras.")
dialogStr("Se emborrachó en medio de las ánforas.")


dialogId("bot-m-zajem", "font_small", "I wonder if there is anything left in them.")
dialogStr("Me pregunto si queda algo ahí.")


dialogId("bot-v-podivat", "font_big", "You probably have to go check for yourself.")
dialogStr("Probablemente tienes que ir a comprobarlo por tí mismo.")


dialogId("bot-m-vidim", "font_small", "Finally, I can see some new kind of skull.")
dialogStr("Finalmente, puedo ver un nuevo tipo de cráneo.")


dialogId("bot-v-vsim", "font_big", "Did you notice that totem? It is the Mexican god Shelloxuatl.")
dialogStr("¿Viste ese tótem? Es el dios Mexicano Conchacoatl.")


dialogId("bot-m-vypada", "font_small", "It looks like it.")
dialogStr("Se le parece.")


dialogId("bot-m-padaji", "font_small", "These amphores fall unbearably slow.")
dialogStr("Esas ánforas caen insoportablemente lento.")


dialogId("bot-v-vsak0", "font_big", "Well, you are not a bear, after all.")
dialogStr("Bueno, no eres un oso, después de todo.")


dialogId("bot-v-vsak1", "font_big", "Don’t forget that we are under water.")
dialogStr("No olvides que estamos bajo el agua.")


dialogId("bot-m-ble", "font_small", "Yuck. The authors could have spared us that animation.")
dialogStr("Puaj. Los autores nos podrían haber ahorrado esa animación.")


dialogId("bot-v-totem", "font_big", "This totem looks good to me.")
dialogStr("Me parece que ese tótem se ve bien.")


dialogId("bot-v-lebka", "font_big", "That skull seems to radiate something strange.")
dialogStr("Esa calavera parece irradiar algo extraño.")


dialogId("bot-m-zivy", "font_small", "Is it alive or is it some kind of spell?")
dialogStr("¿Está vivo o es alguna clase de encantamiento?")

