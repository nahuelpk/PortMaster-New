
dialogId("bot-m-vidis", "font_small", "Can you see that seahorse?")
dialogStr("Vois-tu cet hippocampe ?")


dialogId("bot-v-uveznen0", "font_big", "It is blocked by amphoras.")
dialogStr("Il est bloqué par des amphores.")


dialogId("bot-v-uveznen1", "font_big", "It got itself drunk among the amphoras.")
dialogStr("Il s'est saoulé au milieu des amphores.")


dialogId("bot-m-zajem", "font_small", "I wonder if there is anything left in them.")
dialogStr("Je me demande s'il a laissé quelque chose dedans.")


dialogId("bot-v-podivat", "font_big", "You probably have to go check for yourself.")
dialogStr("Tu vas devoir vérifier par toi même.")


dialogId("bot-m-vidim", "font_small", "Finally, I can see some new kind of skull.")
dialogStr("Je peux enfin voir un nouveau type de crâne.")


dialogId("bot-v-vsim", "font_big", "Did you notice that totem? It is the Mexican god Shelloxuatl.")
dialogStr("Tu as remarqué ce totem ? C'est le dieu mexicain Shelloxuatl.")


dialogId("bot-m-vypada", "font_small", "It looks like it.")
dialogStr("Ça y ressemble.")


dialogId("bot-m-padaji", "font_small", "These amphores fall unbearably slow.")
dialogStr("La chute de ces amphores est insupportablement lente.")


dialogId("bot-v-vsak0", "font_big", "Well, you are not a bear, after all.")
dialogStr("Et bien, tu n'es pas un ours après tout.")


dialogId("bot-v-vsak1", "font_big", "Don’t forget that we are under water.")
dialogStr("N'oublie pas que nous sommes sous l'eau.")


dialogId("bot-m-ble", "font_small", "Yuck. The authors could have spared us that animation.")
dialogStr("Argh. Les auteurs auraient put nous épargner cette animation.")


dialogId("bot-v-totem", "font_big", "This totem looks good to me.")
dialogStr("Ce totem me semble bien.")


dialogId("bot-v-lebka", "font_big", "That skull seems to radiate something strange.")
dialogStr("Ce crâne semble irradier quelque chose d'étrange.")


dialogId("bot-m-zivy", "font_small", "Is it alive or is it some kind of spell?")
dialogStr("Est-il vivant ou est-ce une sorte de magie ?")

