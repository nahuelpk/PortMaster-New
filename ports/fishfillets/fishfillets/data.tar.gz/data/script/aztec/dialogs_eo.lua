-- FIXME adascor
dialogId("bot-m-vidis", "font_small", "Can you see that seahorse?")
dialogStr("Ĉu vi vidas tiun hipokampon?")

dialogId("bot-v-uveznen0", "font_big", "It is blocked by amphoras.")
dialogStr("Ĝi kojnumigas per kruĉojn.")

dialogId("bot-v-uveznen1", "font_big", "It got itself drunk among the amphoras.")
dialogStr("Li sensoifiĝi el la tiuj ĉi kruĉoj.")

dialogId("bot-m-zajem", "font_small", "I wonder if there is anything left in them.")
dialogStr("Mi interesas, ĉu rezervis io en ĝi.")

dialogId("bot-v-podivat", "font_big", "You probably have to go check for yourself.")
dialogStr("Iru kontrolu.")

dialogId("bot-m-vidim", "font_small", "Finally, I can see some new kind of skull.")
dialogStr("Ankaŭ mi vidas ian novan vidon de kranio.")

dialogId("bot-v-vsim", "font_big", "Did you notice that totem? It is the Mexican god Shelloxuatl.")
dialogStr("Ĉu vi vidas tiun totemon? Ĝi estas Meksika dio Ŝiukoatl.")

dialogId("bot-m-vypada", "font_small", "It looks like it.")
dialogStr("Jes, simile en vero.")

dialogId("bot-m-padaji", "font_small", "These amphores fall unbearably slow.")
dialogStr("Tiuj ĉi vazoj falas netolereble malrapide.")

dialogId("bot-v-vsak0", "font_big", "Well, you are not a bear, after all.")
dialogStr("Vi atendas. Leĝo de Arhimed estas nepetegata.")

dialogId("bot-v-vsak1", "font_big", "Don’t forget that we are under water.")
dialogStr("Ne forgesu, ke ni estas sub najado.")

dialogId("bot-m-ble", "font_small", "Yuck. The authors could have spared us that animation.")
dialogStr("Aŭtoroj povus ankaŭ savas nin de tiu ĉi animacio.")

dialogId("bot-v-totem", "font_big", "This totem looks good to me.")
dialogStr("Sed la tiun totemon mi plaĉas.")

dialogId("bot-v-lebka", "font_big", "That skull seems to radiate something strange.")
dialogStr("Tiu kranio iel strange lumiĝas.")

dialogId("bot-m-zivy", "font_small", "Is it alive or is it some kind of spell?")
dialogStr("Ĉu ĝi estas viva aŭ tio ĉi estas io magia?")

