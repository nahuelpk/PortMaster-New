
dialogId("bot-m-vidis", "font_small", "Can you see that seahorse?")
dialogStr("Zie je dat zeepaardje?")


dialogId("bot-v-uveznen0", "font_big", "It is blocked by amphoras.")
dialogStr("Het is helemaal ingebouwd in die stapel amforen.")


dialogId("bot-v-uveznen1", "font_big", "It got itself drunk among the amphoras.")
dialogStr("Het heeft zich bezat tussen de amforen.")


dialogId("bot-m-zajem", "font_small", "I wonder if there is anything left in them.")
dialogStr("Ik vraag me af of er nog iets in zit.")


dialogId("bot-v-podivat", "font_big", "You probably have to go check for yourself.")
dialogStr("Dat zul je waarschijnlijk zelf moeten uitzoeken.")


dialogId("bot-m-vidim", "font_small", "Finally, I can see some new kind of skull.")
dialogStr("Eindelijk, ik zie één of ander nieuw type schedel.")


dialogId("bot-v-vsim", "font_big", "Did you notice that totem? It is the Mexican god Shelloxuatl.")
dialogStr("Heb je die totem gezien? Dat is de mexikaanse god Skelpoxuatl.")


dialogId("bot-m-vypada", "font_small", "It looks like it.")
dialogStr("Daar lijkt het wel op.")


dialogId("bot-m-padaji", "font_small", "These amphores fall unbearably slow.")
dialogStr("Deze amforen vallen onmenselijk langzaam.")


dialogId("bot-v-vsak0", "font_big", "Well, you are not a bear, after all.")
dialogStr("Nou en, je bent toch geen mens.")


dialogId("bot-v-vsak1", "font_big", "Don’t forget that we are under water.")
dialogStr("Vergeet niet dat we onderwater zijn.")


dialogId("bot-m-ble", "font_small", "Yuck. The authors could have spared us that animation.")
dialogStr("Bah. Die animatie hadden de makers ons kunnen besparen.")


dialogId("bot-v-totem", "font_big", "This totem looks good to me.")
dialogStr("Deze totem heeft wel wat.")


dialogId("bot-v-lebka", "font_big", "That skull seems to radiate something strange.")
dialogStr("Die schedel heeft een rare uitstraling.")


dialogId("bot-m-zivy", "font_small", "Is it alive or is it some kind of spell?")
dialogStr("Leeft hij of is het iets met magie, ofzo?")

