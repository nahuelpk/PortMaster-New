
dialogId("bot-m-vidis", "font_small", "Can you see that seahorse?")
dialogStr("Видишь того морского конька?")

dialogId("bot-v-uveznen0", "font_big", "It is blocked by amphoras.")
dialogStr("Он заблокирован кувшинами.")

dialogId("bot-v-uveznen1", "font_big", "It got itself drunk among the amphoras.")
dialogStr("Он напился из этих кувшинов.")

dialogId("bot-m-zajem", "font_small", "I wonder if there is anything left in them.")
dialogStr("Интересно, осталось ли что-нибудь в них.")

dialogId("bot-v-podivat", "font_big", "You probably have to go check for yourself.")
dialogStr("Пойди проверь.")

dialogId("bot-m-vidim", "font_small", "Finally, I can see some new kind of skull.")
dialogStr("А ещё я вижу какой-то новый вид черепа.")

dialogId("bot-v-vsim", "font_big", "Did you notice that totem? It is the Mexican god Shelloxuatl.")
dialogStr("Видишь тот тотем? Это мексиканский бог Шиукоатль.")

dialogId("bot-m-vypada", "font_small", "It looks like it.")
dialogStr("Да, похоже на правду.")

dialogId("bot-m-padaji", "font_small", "These amphores fall unbearably slow.")
dialogStr("Эти сосуды падают невыносимо медленно.")

dialogId("bot-v-vsak0", "font_big", "Well, you are not a bear, after all.")
dialogStr("Ничего, подождешь. Закон Архимеда неумолим.")

dialogId("bot-v-vsak1", "font_big", "Don’t forget that we are under water.")
dialogStr("Не забывай, что мы под водой.")

dialogId("bot-m-ble", "font_small", "Yuck. The authors could have spared us that animation.")
dialogStr("Да ну, авторы игры могли бы и избавить нас от этой анимации.")

dialogId("bot-v-totem", "font_big", "This totem looks good to me.")
dialogStr("А этот тотем мне нравится.")

dialogId("bot-v-lebka", "font_big", "That skull seems to radiate something strange.")
dialogStr("Тот череп как-то странно светится.")

dialogId("bot-m-zivy", "font_small", "Is it alive or is it some kind of spell?")
dialogStr("Он живой или это что-то вроде магии?")

