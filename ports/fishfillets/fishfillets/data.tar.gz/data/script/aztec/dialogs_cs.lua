
dialogId("bot-m-vidis", "font_small", "Can you see that seahorse?")
dialogStr("Vidíš toho koníka?")


dialogId("bot-v-uveznen0", "font_big", "It is blocked by amphoras.")
dialogStr("Je uvězněný mezi amforami.")


dialogId("bot-v-uveznen1", "font_big", "It got itself drunk among the amphoras.")
dialogStr("Opíjel se mezi amforami.")


dialogId("bot-m-zajem", "font_small", "I wonder if there is anything left in them.")
dialogStr("Zajímalo by mě, jestli v nich ještě něco je.")


dialogId("bot-v-podivat", "font_big", "You probably have to go check for yourself.")
dialogStr("Asi se stejně budeš muset jít podívat.")


dialogId("bot-m-vidim", "font_small", "Finally, I can see some new kind of skull.")
dialogStr("Konečně vidím nějakou novou lebku.")


dialogId("bot-v-vsim", "font_big", "Did you notice that totem? It is the Mexican god Shelloxuatl.")
dialogStr("Všimla sis toho totemu? To je mexický bůh Škleboxuatl.")


dialogId("bot-m-vypada", "font_small", "It looks like it.")
dialogStr("Vypadá na to.")


dialogId("bot-m-padaji", "font_small", "These amphores fall unbearably slow.")
dialogStr("Ty amfory padají nelidsky pomalu.")


dialogId("bot-v-vsak0", "font_big", "Well, you are not a bear, after all.")
dialogStr("Však také nejsi člověk.")


dialogId("bot-v-vsak1", "font_big", "Don’t forget that we are under water.")
dialogStr("Však jsme také pod vodou.")


dialogId("bot-m-ble", "font_small", "Yuck. The authors could have spared us that animation.")
dialogStr("Blé... Tuhle animaci si autoři mohli odpustit.")


dialogId("bot-v-totem", "font_big", "This totem looks good to me.")
dialogStr("Mně se ten totem líbí.")


dialogId("bot-v-lebka", "font_big", "That skull seems to radiate something strange.")
dialogStr("Z té lebky vyzařuje něco tajemného.")


dialogId("bot-m-zivy", "font_small", "Is it alive or is it some kind of spell?")
dialogStr("Je to živý, nebo je to kouzlo?")

