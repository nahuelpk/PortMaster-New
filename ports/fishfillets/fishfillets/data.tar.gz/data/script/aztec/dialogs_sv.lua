
dialogId("bot-m-vidis", "font_small", "Can you see that seahorse?")
dialogStr("Kan du se sjöhästen?")


dialogId("bot-v-uveznen0", "font_big", "It is blocked by amphoras.")
dialogStr("Den är instängd bland amfororna.")


dialogId("bot-v-uveznen1", "font_big", "It got itself drunk among the amphoras.")
dialogStr("Den blev på fyllan bland amfororna.")


dialogId("bot-m-zajem", "font_small", "I wonder if there is anything left in them.")
dialogStr("Jag undrar om det finns något kvar i dem.")


dialogId("bot-v-podivat", "font_big", "You probably have to go check for yourself.")
dialogStr("Du behöver nog låta dig undersökas.")


dialogId("bot-m-vidim", "font_small", "Finally, I can see some new kind of skull.")
dialogStr("Till slut, jag ser en ny sorts skalle.")


dialogId("bot-v-vsim", "font_big", "Did you notice that totem? It is the Mexican god Shelloxuatl.")
dialogStr("Har du sett den där totemen? Det är den mexikanska guden Skaloxalt.")


dialogId("bot-m-vypada", "font_small", "It looks like it.")
dialogStr("Det ser så ut.")


dialogId("bot-m-padaji", "font_small", "These amphores fall unbearably slow.")
dialogStr("Amfororna faller så olidligt långsamt.")


dialogId("bot-v-vsak0", "font_big", "Well, you are not a bear, after all.")
dialogStr("Tja, om det inte finns någon öl så.")


dialogId("bot-v-vsak1", "font_big", "Don’t forget that we are under water.")
dialogStr("Glöm inte bort att vi är under vattnet.")


dialogId("bot-m-ble", "font_small", "Yuck. The authors could have spared us that animation.")
dialogStr("Usch. Författarna kunde väl ha låtit oss slippa den där animationen.")


dialogId("bot-v-totem", "font_big", "This totem looks good to me.")
dialogStr("Den där totemen ser god ut.")


dialogId("bot-v-lebka", "font_big", "That skull seems to radiate something strange.")
dialogStr("Skallen verkar utstråla något skumt.")


dialogId("bot-m-zivy", "font_small", "Is it alive or is it some kind of spell?")
dialogStr("Lever den eller är det en förtrollning?")

