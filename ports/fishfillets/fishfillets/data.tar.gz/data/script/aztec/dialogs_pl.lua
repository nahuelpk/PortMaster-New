
dialogId("bot-m-vidis", "font_small", "Can you see that seahorse?")
dialogStr("Widzisz tego konika?")


dialogId("bot-v-uveznen0", "font_big", "It is blocked by amphoras.")
dialogStr("Jest uwięziony między amforami.")


dialogId("bot-v-uveznen1", "font_big", "It got itself drunk among the amphoras.")
dialogStr("Upił się wśród amfor.")


dialogId("bot-m-zajem", "font_small", "I wonder if there is anything left in them.")
dialogStr("Ciekawe, czy coś w nich zostało.")


dialogId("bot-v-podivat", "font_big", "You probably have to go check for yourself.")
dialogStr("Będziesz musiała sama sprawdzić.")


dialogId("bot-m-vidim", "font_small", "Finally, I can see some new kind of skull.")
dialogStr("Wreszcie widzę jakąś nową czaszkę.")


dialogId("bot-v-vsim", "font_big", "Did you notice that totem? It is the Mexican god Shelloxuatl.")
dialogStr("Widzisz ten totem? To meksykański bóg Muszloxuatl.")


dialogId("bot-m-vypada", "font_small", "It looks like it.")
dialogStr("Na to wygląda.")


dialogId("bot-m-padaji", "font_small", "These amphores fall unbearably slow.")
dialogStr("Te amfory opadają niewiarygodnie wolno.")


dialogId("bot-v-vsak0", "font_big", "Well, you are not a bear, after all.")
dialogStr("Wszak nie jesteś niedźwiedziem.")


dialogId("bot-v-vsak1", "font_big", "Don’t forget that we are under water.")
dialogStr("Jesteśmy przecież pod wodą.")


dialogId("bot-m-ble", "font_small", "Yuck. The authors could have spared us that animation.")
dialogStr("Ble... Autorzy mogli nam oszczędzić tej animacji.")


dialogId("bot-v-totem", "font_big", "This totem looks good to me.")
dialogStr("Mnie się ten totem podoba.")


dialogId("bot-v-lebka", "font_big", "That skull seems to radiate something strange.")
dialogStr("Coś dziwnego wydobywa się z tej czaszki.")


dialogId("bot-m-zivy", "font_small", "Is it alive or is it some kind of spell?")
dialogStr("Jest żywa, czy może to jakaś klątwa?")

