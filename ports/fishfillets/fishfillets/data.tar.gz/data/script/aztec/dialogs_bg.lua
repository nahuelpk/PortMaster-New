dialogId("bot-m-vidis", "font_small", "Can you see that seahorse?")
dialogStr("Виждаш ли онова морско конче?")

dialogId("bot-v-uveznen0", "font_big", "It is blocked by amphoras.")
dialogStr("Заклещено е между амфорите.")

dialogId("bot-v-uveznen1", "font_big", "It got itself drunk among the amphoras.")
dialogStr("Насвяткало се е сред амфорите.")

dialogId("bot-m-zajem", "font_small", "I wonder if there is anything left in them.")
dialogStr("Чудя се дали в тях е останало нещо.")

dialogId("bot-v-podivat", "font_big", "You probably have to go check for yourself.")
dialogStr("Ще се наложи сама да провериш.")

dialogId("bot-m-vidim", "font_small", "Finally, I can see some new kind of skull.")
dialogStr("Най-сетне! Нов вид череп.")

dialogId("bot-v-vsim", "font_big", "Did you notice that totem? It is the Mexican god Shelloxuatl.")
dialogStr("Забеляза ли онзи тотем? Това е мексиканският бог Мидоксуатл.")

dialogId("bot-m-vypada", "font_small", "It looks like it.")
dialogStr("На това прилича.")

dialogId("bot-m-padaji", "font_small", "These amphores fall unbearably slow.")
dialogStr("Тези амфори падат ужасно бавно.")

dialogId("bot-v-vsak0", "font_big", "Well, you are not a bear, after all.")
dialogStr("Все пак и ти нямаш нос.")

dialogId("bot-v-vsak1", "font_big", "Don’t forget that we are under water.")
dialogStr("Не забравяй, че сме под водата.")

dialogId("bot-m-ble", "font_small", "Yuck. The authors could have spared us that animation.")
dialogStr("Гадост. Авторите можеха да ни спестят точно тази анимация.")

dialogId("bot-v-totem", "font_big", "This totem looks good to me.")
dialogStr("Този тотем ми изглежда добър.")

dialogId("bot-v-lebka", "font_big", "That skull seems to radiate something strange.")
dialogStr("Този череп май излъчва нещо странно.")

dialogId("bot-m-zivy", "font_small", "Is it alive or is it some kind of spell?")
dialogStr("Живо ли е или е магия?")

dialogId("bot-x-smich", "", "")
dialogStr("")

dialogId("bot-x-gr0", "", "")
dialogStr("")

dialogId("bot-x-gr1", "", "")
dialogStr("")

