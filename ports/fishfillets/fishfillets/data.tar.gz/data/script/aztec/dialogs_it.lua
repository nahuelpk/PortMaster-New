
dialogId("bot-m-vidis", "font_small", "Can you see that seahorse?")
dialogStr("Vedi quel cavalluccio marino?")


dialogId("bot-v-uveznen0", "font_big", "It is blocked by amphoras.")
dialogStr("E’ incastrato tra le anfore.")


dialogId("bot-v-uveznen1", "font_big", "It got itself drunk among the amphoras.")
dialogStr("Si è ubriacato tra le anfore.")


dialogId("bot-m-zajem", "font_small", "I wonder if there is anything left in them.")
dialogStr("Chissà se c'è rimasto qualcosa.")


dialogId("bot-v-podivat", "font_big", "You probably have to go check for yourself.")
dialogStr("Direi che dovrai andare a scoprirlo da te.")


dialogId("bot-m-vidim", "font_small", "Finally, I can see some new kind of skull.")
dialogStr("Finalmente, qualche nuovo tipo di teschio.")


dialogId("bot-v-vsim", "font_big", "Did you notice that totem? It is the Mexican god Shelloxuatl.")
dialogStr("Hai notato quel totem? Si tratta dell divinità messicana Shelloxuatl.")


dialogId("bot-m-vypada", "font_small", "It looks like it.")
dialogStr("Così sembra.")


dialogId("bot-m-padaji", "font_small", "These amphores fall unbearably slow.")
dialogStr("Queste anfore cadono insopportabilmente lente.")


dialogId("bot-v-vsak0", "font_big", "Well, you are not a bear, after all.")
dialogStr("Beh, tu dovrai sopportare, invece.")


dialogId("bot-v-vsak1", "font_big", "Don’t forget that we are under water.")
dialogStr("Non dimenticare che ci troviamo sott'acqua.")


dialogId("bot-m-ble", "font_small", "Yuck. The authors could have spared us that animation.")
dialogStr("Ack. Gli autori potevano risparmiarci quell'animazione.")


dialogId("bot-v-totem", "font_big", "This totem looks good to me.")
dialogStr("Quel totem mi sembra a posto.")


dialogId("bot-v-lebka", "font_big", "That skull seems to radiate something strange.")
dialogStr("Quel teschio sembra emanare qualcosa di strano.")


dialogId("bot-m-zivy", "font_small", "Is it alive or is it some kind of spell?")
dialogStr("E’ vivo o si tratterà di una qualche incantesimo?")

