-- FIXME
dialogId("v-upozornit", "font_big", "The player should know that the cylinders are linked with the cars of the same color")
dialogStr("Игрок должен знать, что баллоны связаны с машинами одним цветом.")

dialogId("m-silou", "font_small", "BY AN INVISIBLE POWER!!")
dialogStr("НЕВИДИМОЙ СИЛОЙ!!")

dialogId("m-hraje", "font_small", "Somebody is playing games with us -- the cars are moved. Or do you do it? Or do I? I am begining to be afraid.")
dialogStr("Тот, кто играет с нами - машины перемещаются. Или ты это делаешь? Или я? Мне становится страшно.")

dialogId("v-ffneni", "font_big", "I wonder if fish fillets is a good game to solve this room.")
dialogStr("Я интересуюсь, если fish fillets - хорошая игра, реши очередную головоломку.") ---???

dialogId("m-myslis", "font_small", "What do you mean it?")
dialogStr("Что ты думаешь об этом?")

dialogId("v-zopakuje", "font_big", "The player should learn to solve it somewhere else and he should only repeat it here.")
dialogStr("Игрок должен узнать где-нибудь, как решить, и потом только повторить это.")

dialogId("m-obdivovat", "font_small", "On the contary, if the player solves it only here, I will admire him secretly.")
dialogStr("Если игрок решит это только здесь, я буду им тайно восхищаться.")

dialogId("m-vysunout", "font_small", "We should get out the red car.")
dialogStr("Мы должны выйти из красной машины.")

dialogId("v-chytra", "font_big", "Don’t be clever when somebody else already is.")
dialogStr("Не умничай, когда кто-то уже есть.")

dialogId("v-codelas", "font_big", "What are you doing? You aren’t out yet.")
dialogStr("Что ты делаешь? Ты еще не ушел.")
