dialogId("v-upozornit", "font_big", "The player should know that the cylinders are linked with the cars of the same color")
dialogStr(
"Spelaren borde veta att cylindrarna är länkade till bilarna av samma färg.")

dialogId("m-silou", "font_small", "BY AN INVISIBLE POWER!!")
dialogStr("AV EN OSYNLIG KRAFT!!")

dialogId("m-hraje", "font_small", "Somebody is playing games with us -- the cars are moved. Or do you do it? Or do I? I am begining to be afraid.")
dialogStr(
"Någon skämtar med oss -- bilarna rör på sig. Eller gjorde du det? Eller jag? Jag börjar att bli rädd.")

dialogId("v-ffneni", "font_big", "I wonder if fish fillets is a good game to solve this room.")
dialogStr(
"Jag undrar om fish fillets är ett bra spel att lösa detta rum i.")

dialogId("m-myslis", "font_small", "What do you mean it?")
dialogStr("Hur menar du?")

dialogId("v-zopakuje", "font_big", "The player should learn to solve it somewhere else and he should only repeat it here.")
dialogStr(
"Spelaren borde lära sig att lösa det någon annanstans och han borde bara upprepa det här.")

dialogId("m-obdivovat", "font_small", "On the contary, if the player solves it only here, I will admire him secretly.")
dialogStr(
"Tvärt om, om spelaren löser det bara här kommer jag att beundra honom i hemlighet.")

dialogId("m-vysunout", "font_small", "We should get out the red car.")
dialogStr("Vi borde få bort den röda bilen.")

dialogId("v-chytra", "font_big", "Don’t be clever when somebody else already is.")
dialogStr("Försök inte att var smart när någon annan redan löst det.")

dialogId("v-codelas", "font_big", "What are you doing? You aren’t out yet.")
dialogStr("Vad gör du? Du är inte ute än.")
