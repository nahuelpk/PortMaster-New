dialogId("v-upozornit", "font_big", "The player should know that the cylinders are linked with the cars of the same color")

dialogId("m-silou", "font_small", "BY AN INVISIBLE POWER!!")

dialogId("m-hraje", "font_small", "Somebody is playing games with us -- the cars are moved. Or do you do it? Or do I? I am begining to be afraid.")

dialogId("v-ffneni", "font_big", "I wonder if fish fillets is a good game to solve this room.")

dialogId("m-myslis", "font_small", "What do you mean it?")

dialogId("v-zopakuje", "font_big", "The player should learn to solve it somewhere else and he should only repeat it here.")

dialogId("m-obdivovat", "font_small", "On the contary, if the player solves it only here, I will admire him secretly.")

dialogId("m-vysunout", "font_small", "We should get out the red car.")

dialogId("v-chytra", "font_big", "Don’t be clever when somebody else already is.")

dialogId("v-codelas", "font_big", "What are you doing? You aren’t out yet.")
