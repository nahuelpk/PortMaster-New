dialogId("v-upozornit", "font_big", "The player should know that the cylinders are linked with the cars of the same color")
dialogStr("De speler moet weten dat de cylinders aan de auto's met dezelfde kleur vast zitten.")

dialogId("m-silou", "font_small", "BY AN INVISIBLE POWER!!")
dialogStr("Met een onzichtbare koppeling!")

dialogId("m-hraje", "font_small", "Somebody is playing games with us -- the cars are moved. Or do you do it? Or do I? I am begining to be afraid.")
dialogStr("Iemand is ons aan het plagen -- de auto's zijn verplaatst. Of doe jij het? Of ik? Ik krijg hier de kriebels van.")

dialogId("v-ffneni", "font_big", "I wonder if fish fillets is a good game to solve this room.")
dialogStr("Ik vraag me af of fish fillets een goed spel is om dit veld in op te lossen.")

dialogId("m-myslis", "font_small", "What do you mean it?")
dialogStr("Hoe bedoel je?")

dialogId("v-zopakuje", "font_big", "The player should learn to solve it somewhere else and he should only repeat it here.")
dialogStr("De speler zou moeten leren om het ergens anders op te lossen, en dan hier te herhalen.")

dialogId("m-obdivovat", "font_small", "On the contary, if the player solves it only here, I will admire him secretly.")
dialogStr("Juist niet. Als de speler het alleen hier oplost, dan zal ik hem of haar stiekem meer respecteren.")

dialogId("m-vysunout", "font_small", "We should get out the red car.")
dialogStr("We zouden die rode auto hier weg moeten werken.")

dialogId("v-chytra", "font_big", "Don’t be clever when somebody else already is.")
dialogStr("Doe niet zo slim als iemand anders dat al is.")

dialogId("v-codelas", "font_big", "What are you doing? You aren’t out yet.")
dialogStr("Waar ben je mee bezig? Je bent hier nog lang niet uit.")
