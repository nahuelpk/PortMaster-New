dialogId("v-upozornit", "font_big", "The player should know that the cylinders are linked with the cars of the same color")
dialogStr(
"Pro začátek je dobré hráče upozornit, že ty válce jsou spojeny s autíčky stejné barvy")

dialogId("m-silou", "font_small", "BY AN INVISIBLE POWER!!")
dialogStr("NEVIDITELNOU SILOU!!")

dialogId("m-hraje", "font_small", "Somebody is playing games with us -- the cars are moved. Or do you do it? Or do I? I am begining to be afraid.")
dialogStr(
"Asi si s námi někdo pěkně hraje, když posouvá ta autíčka. Nebo to snad děláš ty? nebo snad já? Začínám se trochu bát.")

dialogId("v-ffneni", "font_big", "I wonder if fish fillets is a good game to solve this room.")
dialogStr(
"Domnívám se, že fish fillets není vhodná hra k řešení této místnosti.")

dialogId("m-myslis", "font_small", "What do you mean it?")
dialogStr("Jak to myslíš?")

dialogId("v-zopakuje", "font_big", "The player should learn to solve it somewhere else and he should only repeat it here.")
dialogStr(
"Hráč se to nejspíš naučí vyhrát někde jinde a tady už to jen zopakuje.")

dialogId("m-obdivovat", "font_small", "On the contary, if the player solves it only here, I will admire him secretly.")
dialogStr(
"Náhodou, když bude řešit pouze tady, budu ho pak tajně obdivovat.")

dialogId("m-vysunout", "font_small", "We should get out the red car.")
dialogStr("Asi bychom měli vysunout ven to červené autíčko.")

dialogId("v-chytra", "font_big", "Don’t be clever when somebody else already is.")
dialogStr("Nebuď chytrá, od toho tu máme někoho jiného.")

dialogId("v-codelas", "font_big", "What are you doing? You aren’t out yet.")
dialogStr("Co děláš? Ještě nejsi venku.")
