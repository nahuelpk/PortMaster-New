dialogId("v-upozornit", "font_big", "The player should know that the cylinders are linked with the cars of the same color")
dialogStr("Der Spieler sollte wissen, dass die Zylinder mit den Autos gleicher Farbe verbunden sind.")

dialogId("m-silou", "font_small", "BY AN INVISIBLE POWER!!")
dialogStr("DURCH EINE UNSICHTBARE KRAFT!")

dialogId("m-hraje", "font_small", "Somebody is playing games with us -- the cars are moved. Or do you do it? Or do I? I am begining to be afraid.")
dialogStr("Jemand spielt mit uns -- die Autos bewegen sich. Oder bist du das? Oder ich? Ich bekomme Angst.")

dialogId("v-ffneni", "font_big", "I wonder if fish fillets is a good game to solve this room.")
dialogStr("Ich frage mich gerade, ob Fish Fillets ein gutes Spiel ist, um diese Ebene zu lösen.")

dialogId("m-myslis", "font_small", "What do you mean it?")
dialogStr("Was meinst du damit?")

dialogId("v-zopakuje", "font_big", "The player should learn to solve it somewhere else and he should only repeat it here.")
dialogStr("Der Spieler sollte es erst woanders lösen und dann hier wiederholen.")

dialogId("m-obdivovat", "font_small", "On the contary, if the player solves it only here, I will admire him secretly.")
dialogStr("Im Gegenteil! Wenn der Spieler es nur hier löst, werde ich ihn heimlich bewundern.")

dialogId("m-vysunout", "font_small", "We should get out the red car.")
dialogStr("Wir sollten das rote Auto herausbekommen.")

dialogId("v-chytra", "font_big", "Don’t be clever when somebody else already is.")
dialogStr("Tu nicht so schlau, wenn die anderen es schon sind.")

dialogId("v-codelas", "font_big", "What are you doing? You aren’t out yet.")
dialogStr("Was tust du? Du bist noch nicht draußen.")
