dialogId("v-upozornit", "font_big", "The player should know that the cylinders are linked with the cars of the same color")
dialogStr("Трябва да знаете, че цилиндрите и колите от един и същ цвят са свързани")

dialogId("m-silou", "font_small", "BY AN INVISIBLE POWER!!")
dialogStr("ОТ НЕВИДИМА СИЛА!!")

dialogId("m-hraje", "font_small", "Somebody is playing games with us -- the cars are moved. Or do you do it? Or do I? I am begining to be afraid.")
dialogStr("Някой си играе с нас — колите се местят. Ти ли беше? Или аз? Започвам да се плаша.")

dialogId("v-ffneni", "font_big", "I wonder if fish fillets is a good game to solve this room.")
dialogStr("Чудя се дали „Рибни филета“ е подходяща игра за решаване на този ребус.")

dialogId("m-myslis", "font_small", "What do you mean it?")
dialogStr("Какво имаш предвид?")

dialogId("v-zopakuje", "font_big", "The player should learn to solve it somewhere else and he should only repeat it here.")
dialogStr("Играчите би трябвало да се научат да го решават другаде и просто да повторят решението тук.")

dialogId("m-obdivovat", "font_small", "On the contary, if the player solves it only here, I will admire him secretly.")
dialogStr("От друга страна, успелите да го решат тук заслужават сппециална похвала.")

dialogId("m-vysunout", "font_small", "We should get out the red car.")
dialogStr("Трябва да измъкнем червената кола.")

dialogId("v-chytra", "font_big", "Don’t be clever when somebody else already is.")
dialogStr("Не се прави на умница.")

dialogId("v-codelas", "font_big", "What are you doing? You aren’t out yet.")
dialogStr("v-codelas", "font_big", "Какво правиш? Още не сме се измъкнали.")
